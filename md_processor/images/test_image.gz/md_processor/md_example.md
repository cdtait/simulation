
# Market Data Example

### Quick Notebook example of using panadas and ploting

Load the data from the csv and plot mid price with buy/sell trades


    %matplotlib inline


    import pandas as pd
    import matplotlib.pyplot as plt
    import numpy as np
    
    pd.options.display.max_columns=40
    pd.options.display.max_rows=1000


    path = 'data/md-test-2.C-M.csv'
    book_data = pd.read_csv(path, index_col=False,header=None,nrows=50000,skiprows=10)


    ask_trade_prices = book_data[book_data.iloc[:,1]=='S'].iloc[:,3]
    bid_trade_prices = book_data[book_data.iloc[:,1]=='B'].iloc[:,3]


    book=book_data[book_data.iloc[:,1]=='U']
    book['mid_price']=(book.iloc[:,6]+book.values[:,7])/2.0


    plt.figure(figsize=(10,5))
    book['mid_price'].plot(color='g')
    plt.scatter(ask_trade_prices.index,ask_trade_prices.values,color='r',s=5)
    plt.scatter(bid_trade_prices.index,bid_trade_prices.values,color='b',s=5)




    <matplotlib.collections.PathCollection at 0x7677210>




![png](md_example_files/md_example_8_1.png)



    
