
import sys
import zmq


#  Socket to talk to server
context = zmq.Context()
subscriber = context.socket(zmq.SUB)
subscriber.connect("tcp://localhost:5556")
subscriber.setsockopt(zmq.SUBSCRIBE, b'')

subscriber.bind("tcp://*:5555")

while True:
    line = subscriber.recv_string()
    print("%s" %  line)

# We never get here but clean up anyhow
subscriber.close()
context.term()
