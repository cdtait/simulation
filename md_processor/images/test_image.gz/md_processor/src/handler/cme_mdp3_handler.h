
#ifndef cme_mdp3_handler_h
#define cme_mdp3_handler_h

#include <iostream>

#include "common/xml/xml_config.h"
#include "common/logging/logging_util.h"

#include "md_types.h"
#include "md_parsers.h"
#include "md_books.h"
#include "md_publishers.h"

#include "mktdata/MessageHeader.hpp"
#include "mktdata/SnapshotFullRefresh38.hpp"
#include "mktdata/MDIncrementalRefreshBook32.hpp"
#include "mktdata/MDIncrementalRefreshTrade36.hpp"
#include "mktdata/MDIncrementalRefreshVolume37.hpp"
#include "mktdata/MDIncrementalRefreshTradeSummary42.hpp"
#include "mktdata/MDInstrumentDefinitionFuture27.hpp"
#include "mktdata/MDInstrumentDefinitionOption41.hpp"
#include "mktdata/MDInstrumentDefinitionSpread29.hpp"

#include "converter/cme_conversions.h"

using namespace mktdata;

constexpr uint32_t MsgSeqNumOffset=sizeof(uint32_t);
constexpr uint32_t SendingTimeOffset=sizeof(uint64_t);
constexpr uint32_t MsgSizeOffset=sizeof(uint16_t);

constexpr sbe_uint32_t NUMLEVELS=5;

#include "formatters/cme_event_print_formatter.h"

/**
   *  @brief Implementation of the md handler
   *
   *  Controls the print publisher and message processing which
   *  is sent to the order book
   *
   */
template <typename Parser,typename BookContainer,typename Publisher>
class cme_mdp3_handler {
	typedef stream_state<BookContainer> StreamState;
	typedef std::shared_ptr<StreamState> StreamStatePtr;
	typedef std::map<CntrId, StreamStatePtr> StreamStateMapType;
	typedef std::map<CntrId, InstrumentId> CntrId2InstrumentId;
	typedef std::map<InstrumentId, CntrId> InstrumentId2CntrId;
	typedef std::set<InstrumentId> SymbolList;

public:
	cme_mdp3_handler(xml_config & config) : _logger(Logger::getLogger("cme_mdp3_handler")) {
		std::vector<std::string> symbols = config.stringVector("//engine/md/cme/@symbols", 0);
		std::copy(symbols.begin(), symbols.end(), std::inserter(interestedSymbols,interestedSymbols.end()));
	}

    void stop() {
        publisher->stop();
    }

    void start(PublishType publishType) {
    	publisher=std::make_unique<Publisher>(publishType);
    }

    /**
     * Get the event and determines which methods on order
     * book is suitable for the event type
     *
     * If the publisher is enabled then we can offer the
     * data events for publishing
     *
     * @param iter
     */
    void process_message(char_token_time_stream && tokens) {
    	char_token_time_stream::iterator message_iter = tokens.begin();
		auto end = tokens.end();
		auto length = std::distance(message_iter,end);

		uint32_t offset = 0;

		uint32_t * msgSeqNumPtr=reinterpret_cast<uint32_t *>(message_iter+offset);
		offset += MsgSeqNumOffset;
		uint64_t * sendingTimePtr=reinterpret_cast<uint64_t *>(message_iter+offset);
		offset += SendingTimeOffset;

		//printPacketHeader(std::cout,*msgSeqNum,*sendingTime);
		try {
		while (offset < length-1) {
			MessageHeader hdr;
			const int messageHeaderVersion = 0;
			uint16_t* msgSize = reinterpret_cast<uint16_t *>(message_iter+offset);
			hdr.wrap(message_iter,offset+MsgSizeOffset,messageHeaderVersion, length);
			std::cout << *msgSeqNumPtr << "," << hdr.templateId() << "," << *sendingTimePtr << "\n";

			//printMessageHeader(std::cout,hdr);

			if (hdr.templateId()==SnapshotFullRefresh38::sbeTemplateId()) {
				SnapshotFullRefresh38 snapshotFullRefresh38;
				snapshotFullRefresh38.wrapForDecode(message_iter,
						offset+MsgSizeOffset+hdr.size(),
						hdr.blockLength(),
						hdr.version(),
						length);
				process_snapshot_message(snapshotFullRefresh38,*msgSeqNumPtr,*sendingTimePtr);
			}
			else if (hdr.templateId()==MDIncrementalRefreshBook32::sbeTemplateId()) {
				MDIncrementalRefreshBook32 mdIncrementalRefreshBook32;
				mdIncrementalRefreshBook32.wrapForDecode(message_iter,
						offset+MsgSizeOffset+hdr.size(),
						hdr.blockLength(),
						hdr.version(),
						length);
				/*
				if (*msgSeqNum==12040232||*msgSeqNum==12040233) {
					std::cout << to_xml_string(mdIncrementalRefreshBook32) << std::endl;
				}
				*/
				process_incremental_message(mdIncrementalRefreshBook32,*msgSeqNumPtr,*sendingTimePtr);
			}
			else if (hdr.templateId()==MDIncrementalRefreshTrade36::sbeTemplateId()) {
				MDIncrementalRefreshTrade36 mdIncrementalRefreshTrade36;
				mdIncrementalRefreshTrade36.wrapForDecode(message_iter,
						offset+MsgSizeOffset+hdr.size(),
						hdr.blockLength(),
						hdr.version(),
						length);
				process_trade_message(mdIncrementalRefreshTrade36,*msgSeqNumPtr,*sendingTimePtr);
			}
			else if (hdr.templateId()==MDIncrementalRefreshTradeSummary42::sbeTemplateId()) {
				MDIncrementalRefreshTradeSummary42 mdIncrementalRefreshTradeSummary42;
				mdIncrementalRefreshTradeSummary42.wrapForDecode(message_iter,
						offset+MsgSizeOffset+hdr.size(),
						hdr.blockLength(),
						hdr.version(),
						length);
				/*
				if (*msgSeqNum==12040232||*msgSeqNum==12040233) {
					std::cout << to_xml_string(mdIncrementalRefreshTradeSummary42) << std::endl;
				}
				*/
				process_trade_message(mdIncrementalRefreshTradeSummary42,*msgSeqNumPtr,*sendingTimePtr);
			}
			else if (hdr.templateId()==MDInstrumentDefinitionFuture27::sbeTemplateId()) {
				MDInstrumentDefinitionFuture27 mdInstrumentDefinitionFuture27;
				mdInstrumentDefinitionFuture27.wrapForDecode(message_iter,
									offset+MsgSizeOffset+hdr.size(),
									hdr.blockLength(),
									hdr.version(),
									length);
				process_instrument_definition_future_message(mdInstrumentDefinitionFuture27,*msgSeqNumPtr,*sendingTimePtr);
			}
			else if (hdr.templateId()==MDInstrumentDefinitionOption41::sbeTemplateId()) {
			}
			else if (hdr.templateId()==MDInstrumentDefinitionSpread29::sbeTemplateId()) {
			}
			else if (hdr.templateId()==MDIncrementalRefreshVolume37::sbeTemplateId()) {
				MDIncrementalRefreshVolume37 mdIncrementalRefreshVolume37;
				mdIncrementalRefreshVolume37.wrapForDecode(message_iter,
									offset+MsgSizeOffset+hdr.size(),
									hdr.blockLength(),
									hdr.version(),
									length);
				process_trade_volume_message(mdIncrementalRefreshVolume37,*msgSeqNumPtr,*sendingTimePtr);
				/*
				if (*msgSeqNum==12040232||*msgSeqNum==12040233) {
					std::cout << to_xml_string(mdIncrementalRefreshVolume37) << std::endl;
				}
				*/
			}
			else {

			}
			offset+=*msgSize;
		}
		}
		catch(std::exception &e) {
			std::cerr << e.what();
			std::cout << "Exception:" << *msgSeqNumPtr << "," << "," << *sendingTimePtr << "\n";
		}
    }

    /**
     * Offers the book data off for publishing
     */
    void publishOrderBook(BookContainer & ob) {
    	if (publisher.get()) {
    		//print_book(std::cout,ob);
    		//print_book_csv(std::cout,ob);
    		//publisher->offer(book_data(ob));
    	}
     }

    /**
      * Prints the stats onto the stream given
      * @param ostr output stream
      */
     void printStats(std::ostream &ostr) {
         stats().print(ostr);
     }

 	void process_instrument_definition_future_message(
 			MDInstrumentDefinitionFuture27& mdInstrumentDefinitionFuture27,
 			uint32_t msgSeqNum,
			uint64_t sendingTime) {
		// Add a subscription to an interested product, unless we have already
		std::string symbol = mdInstrumentDefinitionFuture27.symbol();

		if (interestedSymbols.find(symbol) != interestedSymbols.end() &&
			instrumentId2CntrId.find(symbol) == instrumentId2CntrId.end()) {
			CntrId securityID = mdInstrumentDefinitionFuture27.securityID();

			//delim_value(std::cout,mdInstrumentDefinitionFuture27,msgSeqNum,sendingTime);

			MDInstrumentDefinitionFuture27::NoEvents & noEvents =
					mdInstrumentDefinitionFuture27.noEvents();

			while (noEvents.hasNext() ) {
				MDInstrumentDefinitionFuture27::NoEvents & noEventsEntry = noEvents.next();
				//std::cout << noEventsEntry.eventTime() << std::endl;
				//std::cout << noEventsEntry.eventType() << std::endl;
				noEventsEntry.eventTime();
				noEventsEntry.eventType();
			}

			MDInstrumentDefinitionFuture27::NoMDFeedTypes & noMDFeedTypes =
					mdInstrumentDefinitionFuture27.noMDFeedTypes();

	        //std::string feedType1 = std::string(noMDFeedTypes.mDFeedType(),noMDFeedTypes.mDFeedTypeLength());

	        //std::cout << feedType1 << std::endl;
	        //std::cout << (uint32_t)noMDFeedTypes.marketDepth() << std::endl;

			while (noMDFeedTypes.hasNext() ) {
				MDInstrumentDefinitionFuture27::NoMDFeedTypes & feedTypeEntry = noMDFeedTypes.next();

		        std::string feedType = std::string(feedTypeEntry.mDFeedType(),feedTypeEntry.mDFeedTypeLength());

		        //std::cout << feedType << std::endl;
		        //std::cout << (uint32_t)feedTypeEntry.marketDepth() << std::endl;

		        if (feedType == "GBX")
		        {
		            uint32_t marketDepth = feedTypeEntry.marketDepth();
		            stream_state_map[mdInstrumentDefinitionFuture27.securityID()] = std::make_shared<StreamState>(marketDepth);
		            StreamStatePtr ss = stream_state_map[mdInstrumentDefinitionFuture27.securityID()];
		            BookContainer & book = ss->getBook();
		            set_name(book,symbol,securityID);
					cntrId2InstrumentId[securityID] = symbol;
					instrumentId2CntrId[symbol] = securityID;
		        }
		    }
		}
 	}

	void process_snapshot_message(SnapshotFullRefresh38& snapshotFullRefresh38,
 			uint32_t msgSeqNum,
			uint64_t sendingTime) {
		CntrId securityID = snapshotFullRefresh38.securityID();

		typename StreamStateMapType::iterator mapIter = stream_state_map.find(securityID);

		if (mapIter != stream_state_map.end()) {
			//uint32_t lastMsgSeqNumProcessed = snapshotFullRefresh38.lastMsgSeqNumProcessed();
			uint32_t rptSeq = snapshotFullRefresh38.rptSeq();
			uint64_t transactTime = snapshotFullRefresh38.transactTime();
			//uint64_t lastUpdateTime = snapshotFullRefresh38.lastUpdateTime();
			//SecurityTradingStatus::Value mDSecurityTradingStatus = snapshotFullRefresh38.mDSecurityTradingStatus();

			StreamStatePtr ss = mapIter->second;
			typename StreamState::SyncState currentState = ss->getMdState();

			if (currentState == StreamState::NeedSnapshot) {
				BookContainer& book = ss->getBook();
				SnapshotFullRefresh38::NoMDEntries & noMDEntries =
						snapshotFullRefresh38.noMDEntries();

				while (noMDEntries.hasNext() ) {
					SnapshotFullRefresh38::NoMDEntries & mdEntry = noMDEntries.next();

					MDEntryType::Value mDEntryType = mdEntry.mDEntryType();
					int32_t mDPriceLevel = mdEntry.mDPriceLevel();
					PRICENULL& mDEntryPx = mdEntry.mDEntryPx();
					const price_t price(mDEntryPx.mantissa(),
									mDEntryPx.exponent());
					uint32_t quantity = mdEntry.mDEntrySize();
					uint32_t orders = mdEntry.numberOfOrders();

					 book_type_insert(book,mDPriceLevel,price,quantity,
							 orders,  mDEntryType,
							 rptSeq, transactTime,
					 		msgSeqNum, sendingTime);
				}

				ss->setMdState(StreamState::Synchronized);
				ss->setSeqNum(rptSeq);
				//source->removeStream(ss->getSnapshotStream());
			    publishOrderBook(book);
			}
		}
	}

     void process_incremental_message(MDIncrementalRefreshBook32& mdIncrementalRefreshBook32,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
    	 MDIncrementalRefreshBook32::NoMDEntries & noMDEntries = mdIncrementalRefreshBook32.noMDEntries();
    	 uint64_t transactTime = mdIncrementalRefreshBook32.transactTime();

    	 while(noMDEntries.hasNext()) {
			MDIncrementalRefreshBook32::NoMDEntries & mdEntry = noMDEntries.next();
			CntrId securityID=mdEntry.securityID();
			typename StreamStateMapType::iterator mapIter = stream_state_map.find(securityID);

			if (mapIter != stream_state_map.end()) {

				StreamStatePtr ss = mapIter->second;
				typename StreamState::SyncState currentState = ss->getMdState();
				uint32_t seqNum = mdEntry.rptSeq();


				if (currentState == StreamState::Synchronized) {
				     uint64_t currentSeqNum = ss->getSeqNum();
				     //uint32_t seqNum = mdEntry.rptSeq();

				     if (seqNum == (currentSeqNum + 1)) {
				        ss->setSeqNum(seqNum);
				        BookContainer& book = ss->getBook();
				        process_incremental_order_book_entry(book,mdEntry,
				        		transactTime, msgSeqNum,sendingTime);
						publishOrderBook(book);
				        //std::cout << securityID << "," << seqNum << std::endl;
				     } else if (seqNum > (currentSeqNum + 1)) {
				    	 //ss->setSeqNum(seqNum);
                         ss->setMdState(StreamState::NeedSnapshot);
                         BookContainer& book = ss->getBook();
                         //process_incremental_order_book_entry(book,mdEntry,
                         //				        		transactTime, msgSeqNum,sendingTime);
                     	 book_invalid(book);
                     	 //publishOrderBook(book);
                     	 //std::cout << securityID << "," << seqNum << std::endl;
                         //source->addStream(ss->getSnapshotStream());
                         LOG_WARN(_logger, "MDIncrementalRefreshBook32 refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "] " << msgSeqNum);
                     } else {
                         // If it is less than current it could be from other slower channel so ignore
                         LOG_TRACE(_logger, "Already seen RN:" << seqNum << " SN:" << currentSeqNum);
                     }
				}
			}
    	 }
     }

     void process_incremental_order_book_entry(BookContainer& book,
    		MDIncrementalRefreshBook32::NoMDEntries & mdEntry,
			uint64_t transactTime,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
    	 MDUpdateAction::Value updateAction = mdEntry.mDUpdateAction();
    	 uint32_t rptSeq = mdEntry.rptSeq();
    	 uint32_t mDPriceLevel=mdEntry.mDPriceLevel();
		 PRICENULL& mDEntryPx=mdEntry.mDEntryPx();
		 const price_t price(mDEntryPx.mantissa(),mDEntryPx.exponent());
		 uint32_t quantity=mdEntry.mDEntrySize();
		 uint32_t orders=mdEntry.numberOfOrders();
		 MDEntryTypeBook::Value mDEntryType=mdEntry.mDEntryType();

         switch (updateAction)
         {
             case MDUpdateAction::New:
             {
            	 book_type_insert(book,
            	 		mDPriceLevel, price, quantity,
            	 		orders, mDEntryType,
            	 		rptSeq, transactTime,
            	 		msgSeqNum, sendingTime);

                 break;
             }
             case MDUpdateAction::Change:
             {
				 book_type_change(book,
	            	 		mDPriceLevel, quantity,
	            	 		orders, mDEntryType,
	            	 		rptSeq, transactTime,
	            	 		msgSeqNum, sendingTime);
              break;
             }
             case MDUpdateAction::Delete:
             {
                 book_type_remove(book,
	            	 		mDPriceLevel, mDEntryType,
	            	 		rptSeq, transactTime,
	            	 		msgSeqNum, sendingTime);
                 break;
             }
             case MDUpdateAction::DeleteThru:
             {
                 book_type_removeThru(book,
	            	 		mDPriceLevel, mDEntryType,
	            	 		rptSeq, transactTime,
	            	 		msgSeqNum, sendingTime);
                 break;
             }
             case MDUpdateAction::DeleteFrom:
             {
                 book_type_removeFrom(book,
	            	 		mDPriceLevel, mDEntryType,
	            	 		rptSeq, transactTime,
	            	 		msgSeqNum, sendingTime);
                 break;
             }
             case MDUpdateAction::Overlay:
             {
    			 book_type_overlay(book,
             	 		mDPriceLevel, price, quantity,
             	 		orders, mDEntryType,
             	 		rptSeq, transactTime,
             	 		msgSeqNum, sendingTime);
                 break;
             }
             default:
             {
                 throw logic_error("Invalid order book update operation");
             }
         }
     }

     void process_trade_message(MDIncrementalRefreshTrade36& mdIncrementalRefreshTrade36,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
    	 uint64_t transactTime = mdIncrementalRefreshTrade36.transactTime();
    	 MDIncrementalRefreshTrade36::NoMDEntries & noMDEntries = mdIncrementalRefreshTrade36.noMDEntries();

    	 while(noMDEntries.hasNext()) {
      		MDIncrementalRefreshTrade36::NoMDEntries & mdEntry = noMDEntries.next();
      		CntrId securityID=mdEntry.securityID();
			typename StreamStateMapType::iterator mapIter = stream_state_map.find(securityID);

			if (mapIter != stream_state_map.end()) {

				StreamStatePtr ss = mapIter->second;
				typename StreamState::SyncState currentState = ss->getMdState();

			     uint64_t currentSeqNum = ss->getSeqNum();
			     uint32_t seqNum = mdEntry.rptSeq();

			     if (seqNum == (currentSeqNum + 1)) {
			        ss->setSeqNum(seqNum);
			        BookContainer& book = ss->getBook();
			        process_trade_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
					publishOrderBook(book);
			     } else if (seqNum > (currentSeqNum + 1)) {
			    	 //ss->setSeqNum(seqNum);
                     ss->setMdState(StreamState::NeedSnapshot);
                     BookContainer& book = ss->getBook();
                     //process_trade_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
                 	 book_invalid(book);
                 	 //publishOrderBook(book);
                     //source->addStream(ss->getSnapshotStream());
                     //LOG_WARN(_logger, "refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "]");
                     LOG_WARN(_logger, "MDIncrementalRefreshTrade36 refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "] " << msgSeqNum);
                 } else {
                     // If it is less than current it could be from other slower channel so ignore
                     LOG_TRACE(_logger, "Already seen RN:" << seqNum << " SN:" << currentSeqNum);
                 }
			}
      	 }
     }

     void process_trade_message(MDIncrementalRefreshTradeSummary42& mdIncrementalRefreshTradeSummary42,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
    	 uint64_t transactTime = mdIncrementalRefreshTradeSummary42.transactTime();
    	 MDIncrementalRefreshTradeSummary42::NoMDEntries & noMDEntries = mdIncrementalRefreshTradeSummary42.noMDEntries();

    	 while(noMDEntries.hasNext()) {
    		 MDIncrementalRefreshTradeSummary42::NoMDEntries & mdEntry = noMDEntries.next();
      		CntrId securityID=mdEntry.securityID();
			typename StreamStateMapType::iterator mapIter = stream_state_map.find(securityID);

			if (mapIter != stream_state_map.end()) {

				StreamStatePtr ss = mapIter->second;
				typename StreamState::SyncState currentState = ss->getMdState();

			     uint64_t currentSeqNum = ss->getSeqNum();
			     uint32_t seqNum = mdEntry.rptSeq();

			     if (seqNum == (currentSeqNum + 1)) {
			        ss->setSeqNum(seqNum);
			        BookContainer& book = ss->getBook();
			        process_trade_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
					publishOrderBook(book);
			     } else if (seqNum > (currentSeqNum + 1)) {
			    	 //ss->setSeqNum(seqNum);
                     ss->setMdState(StreamState::NeedSnapshot);
                     BookContainer& book = ss->getBook();
                     //process_trade_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
                 	 book_invalid(book);
                 	 //publishOrderBook(book);
                     //source->addStream(ss->getSnapshotStream());
                     //LOG_WARN(_logger, "refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "]");
                     LOG_WARN(_logger, "MDIncrementalRefreshTradeSummary42 refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "] " << msgSeqNum);
                 } else {
                     // If it is less than current it could be from other slower channel so ignore
                     LOG_TRACE(_logger, "Already seen RN:" << seqNum << " SN:" << currentSeqNum);
                 }
			}
      	 }

       	 MDIncrementalRefreshTradeSummary42::NoOrderIDEntries & noOrderIDEntries = mdIncrementalRefreshTradeSummary42.noOrderIDEntries();

       	 while(noOrderIDEntries.hasNext()) {
       	    MDIncrementalRefreshTradeSummary42::NoOrderIDEntries & noOrderIDEntry = noOrderIDEntries.next();
       	    noOrderIDEntry.orderID();
       	    noOrderIDEntry.lastQty();
       	}
     }

     void process_trade_entry(BookContainer& book,
    		MDIncrementalRefreshTrade36::NoMDEntries & mdEntry,
			uint64_t transactTime,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
		 PRICE& mDEntryPx=mdEntry.mDEntryPx();
		 const price_t price(mDEntryPx.mantissa(),mDEntryPx.exponent());
		 uint32_t quantity=mdEntry.mDEntrySize();
		 uint32_t orders=mdEntry.numberOfOrders();
		 AggressorSide::Value aggressorSide = mdEntry.aggressorSide();
		 int32_t numberOfOrders = mdEntry.numberOfOrders();
		 int32_t tradeID = mdEntry.tradeID();
		 uint32_t rptSeq = mdEntry.rptSeq();

		 trade_insert(book,
			 		price,  quantity,
			 		 orders,  aggressorSide,
			 		 numberOfOrders, tradeID,
			 		 rptSeq,  transactTime,
			 		 msgSeqNum,  sendingTime);
     }

     void process_trade_entry(BookContainer& book,
    		 MDIncrementalRefreshTradeSummary42::NoMDEntries & mdEntry,
			uint64_t transactTime,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
		 PRICE& mDEntryPx=mdEntry.mDEntryPx();
		 const price_t price(mDEntryPx.mantissa(),mDEntryPx.exponent());
		 uint32_t quantity=mdEntry.mDEntrySize();
		 uint32_t orders=mdEntry.numberOfOrders();
		 AggressorSide::Value aggressorSide = mdEntry.aggressorSide();
		 int32_t numberOfOrders = mdEntry.numberOfOrders();
		 uint32_t rptSeq = mdEntry.rptSeq();

		 trade_insert(book,
			 		price,  quantity,
			 		 orders,  aggressorSide,
			 		 numberOfOrders, 0,
			 		 rptSeq,  transactTime,
			 		 msgSeqNum,  sendingTime);
     }

     void process_trade_volume_message(MDIncrementalRefreshVolume37& mdIncrementalRefreshVolume37,
  			uint32_t msgSeqNum,
 			uint64_t sendingTime)
     {
    	 uint64_t transactTime = mdIncrementalRefreshVolume37.transactTime();
    	 MDIncrementalRefreshVolume37::NoMDEntries & noMDEntries = mdIncrementalRefreshVolume37.noMDEntries();

    	 while(noMDEntries.hasNext()) {
    		MDIncrementalRefreshVolume37::NoMDEntries & mdEntry = noMDEntries.next();
      		CntrId securityID=mdEntry.securityID();
			typename StreamStateMapType::iterator mapIter = stream_state_map.find(securityID);

			if (mapIter != stream_state_map.end()) {

				StreamStatePtr ss = mapIter->second;
				typename StreamState::SyncState currentState = ss->getMdState();

			     uint64_t currentSeqNum = ss->getSeqNum();
			     uint32_t seqNum = mdEntry.rptSeq();

			     if (seqNum == (currentSeqNum + 1)) {
			        ss->setSeqNum(seqNum);
			        BookContainer& book = ss->getBook();
			        process_trade_volume_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
					publishOrderBook(book);
			     } else if (seqNum > (currentSeqNum + 1)) {
			    	 //ss->setSeqNum(seqNum);
                     ss->setMdState(StreamState::NeedSnapshot);
                     BookContainer& book = ss->getBook();
                     //process_trade_volume_entry(book,mdEntry,transactTime,msgSeqNum,sendingTime);
                 	 book_invalid(book);
                 	 //publishOrderBook(book);
                     //source->addStream(ss->getSnapshotStream());
                     //LOG_WARN(_logger, "refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "]");
                     LOG_WARN(_logger, "MDIncrementalRefreshTradeSummary42 refresh detected out of sequence! [" << seqNum << " vs. " << currentSeqNum << "] " << msgSeqNum);
                 } else {
                     // If it is less than current it could be from other slower channel so ignore
                     LOG_TRACE(_logger, "Already seen RN:" << seqNum << " SN:" << currentSeqNum);
                 }
			}
      	 }
     }

     void process_trade_volume_entry(BookContainer& book,
    		 MDIncrementalRefreshVolume37::NoMDEntries & mdEntry,
 			uint64_t transactTime,
   			uint32_t msgSeqNum,
  			uint64_t sendingTime)
      {
 		 uint32_t quantity=mdEntry.mDEntrySize();
 		 uint32_t rptSeq = mdEntry.rptSeq();

 		 trade_volume(book, quantity,
 			 		 rptSeq,  transactTime,
 			 		 msgSeqNum,  sendingTime);
      }

   	 /*
     void processStatusMessage(Message* message)
     {

         status_ = message->getAsInt32(Fields::SecurityTradingStatus);

         printStatus();
     }

     void processOpeningPriceEntry(FieldSet& entry)
     {
         u32 openCloseSettlFlag = entry.getAsUInt32(Fields::OpenCloseSettlFlag);

         if (openCloseSettlFlag == 0)
             openingPrice_ = entry.getAsDecimal(Fields::MDEntryPx);
     }

     void processHighTradeEntry(FieldSet& entry)
     {
         highTradePrice_ = entry.getAsDecimal(Fields::MDEntryPx);
     }

     void processLowTradeEntry(FieldSet& entry)
     {
         lowTradePrice_ = entry.getAsDecimal(Fields::MDEntryPx);
     }

     void processHighBidEntry(FieldSet& entry)
     {
         highBidPrice_ = entry.getAsDecimal(Fields::MDEntryPx);
     }

     void processLowAskEntry(FieldSet& entry)
     {
         lowAskPrice_ = entry.getAsDecimal(Fields::MDEntryPx);
     }

     void processResetEntry(Cme::Mdp3::FieldSet& entry)
     {
         status_ = MDSecurityTradingStatus::Unknown;

         orderBook_->reset();

         if (impliedOrderBook_)
             impliedOrderBook_->reset();

         resetStatistics();
     }

     void validateOrderBook(const ::OrderBook& orderBook)
     {
         if (orderBook.bid().getDepth() > 1)
         {
             for (System::u32 index = 1; index < orderBook.bid().getDepth(); ++ index)
             {
                 const ::OrderBookLevel& orderBookLevel1 = orderBook.bid().getLevel(index);
                 const ::OrderBookLevel& orderBookLevel2 = orderBook.bid().getLevel(index + 1);

                 assert(orderBookLevel1.price > orderBookLevel2.price);
             }
         }

         if (orderBook.ask().getDepth() > 1)
         {
             for (System::u32 index = 1; index < orderBook.ask().getDepth(); ++ index)
             {
                 const ::OrderBookLevel& orderBookLevel1 = orderBook.ask().getLevel(index);
                 const ::OrderBookLevel& orderBookLevel2 = orderBook.ask().getLevel(index + 1);

                 assert(orderBookLevel1.price < orderBookLevel2.price);
             }
         }

         if (status_ == Cme::Mdp3::MDSecurityTradingStatus::ReadyToTrade)
         {
             if (orderBook.bid().getDepth() > 0 && orderBook.ask().getDepth())
             {
                 const ::OrderBookLevel& bidOrderBookLevel = orderBook.bid().getTopLevel();
                 const ::OrderBookLevel& askOrderBookLevel = orderBook.ask().getTopLevel();

                 assert(bidOrderBookLevel.price < askOrderBookLevel.price);
             }
         }
     }
*/
	private:
     	LoggerPtr _logger;
    	// The publisher which handles book data messages
    	std::unique_ptr<Publisher> publisher;
    	StreamStateMapType stream_state_map;
    	CntrId2InstrumentId cntrId2InstrumentId;
    	InstrumentId2CntrId instrumentId2CntrId;
    	SymbolList interestedSymbols;
};


#endif
