#include "book_hash.h"

/**
 *  @brief  Get a sorted map of bids
 *
 *  We return the sorted map by using the above sort
 *
 *  So not efficient but it needs to be analysed in use case.
 *
 */
 BookHash::SortedBids & BookHash::get_sorted_bids() {
	sortedBidLevels.clear();
	sorted_bid(*this,sortedBidLevels);
	return sortedBidLevels;
}

/**
 *  @brief  Get a sorted map of asks
 *
 *  We return the sorted map by using the above sort
 *
 *  So not efficient but it needs to be analysed in use case.
 *
 */
 BookHash::SortedAsks & BookHash::get_sorted_asks() {
	sortedAskLevels.clear();
	sorted_ask(*this,sortedAskLevels);
	return sortedAskLevels;
}


/**
 *  @brief  Get the top bid
 *  @return top bid price
 *
 *  As price levels are not sorted
 *  we need to sort first
 *
 */
PriceLevelKey BookHash::get_top_bid() {
	//auto sorted_bids = sorted_bid(*this);
	std::map<PriceLevelKey,BookHash::Orders,GreaterComp> sorted_bids;
	sorted_bid(*this,sorted_bids);

	auto top_bid = sorted_bids.begin();
	if (top_bid!=sorted_bids.end()) {
		return top_bid->first;
	}
	else {
		return PriceLevelKey();
	}
}

/**
 *  @brief  Get the top ask
 *  @return top bid price
 *
 *  As price levels are not sorted
 *  we need to sort first
 *
 */
PriceLevelKey BookHash::get_top_ask() {
	//auto sorted_asks = sorted_ask(*this);
	std::map<PriceLevelKey,BookHash::Orders,LessComp> sorted_asks;
	sorted_ask(*this,sorted_asks);
	auto top_ask = sorted_asks.begin();
	if (top_ask!=sorted_asks.end()) {
		return top_ask->first;
	}
	else {
		return PriceLevelKey();
	}
}

void BookHash::clear() {
	bidLevels.clear();
	askLevels.clear();
}
