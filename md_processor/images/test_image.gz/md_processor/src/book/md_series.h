
#ifndef md_series_h_
#define md_series_h_

#include "book/md_order_book4.h"

#include <iostream>
#include <fstream>
#include <cstring>

class md_series {
public:
	md_series(index_type sl, const char* sn, tick_size_t tickSize,unsigned int nl) :
	tick_index(-1), series_length(sl), tick_size(tickSize),number_of_tick_levels(nl) {
		strncpy(series_name, sn, SERIES_NAME_LEN);
		create();
	}

	virtual ~md_series() {
	   destroy();
	}

   virtual void create() {
	   if (number_of_tick_levels==5) {
		series = (md_order_book3**)new md_order_book4_5*[series_length];

		for (index_type i = 0; i < series_length; i++) {
			series[i] = new md_order_book4_5(series_name, tick_size);
			series[i]->initialize();
		}
	   }
	   else {
		series = (md_order_book3**)new md_order_book4_25*[series_length];

		for (index_type i = 0; i < series_length; i++) {
			series[i] = new md_order_book4_25(series_name, tick_size);
			series[i]->initialize();
		}
	   }

#ifdef __TOP_OF_BOOK__
	   if (number_of_tick_levels==6) {
		series = (md_order_book3**)new md_tick6*[series_length];

		for (index_type i = 0; i < series_length; i++) {
			series[i] = new md_tick6(series_name, tick_size);
			series[i]->initialize();
		}
	   }
	   else {
		series = (md_order_book3**)new md_tick26*[series_length];

		for (index_type i = 0; i < series_length; i++) {
			series[i] = new md_tick26(series_name, tick_size);
			series[i]->initialize();
		}
	   }
#endif
	}

	virtual void recreate(index_type numOrderBooks) {
	  destroy();
	  set_number(numOrderBooks);
	  create();
	  reset();
	}

	virtual void destroy() {
	   if (series != NULL) {
			for (uint32_t i = 0; i < series_length; i++) {
				if (series[i]) {
					delete series[i];
				}
			}

			delete[] series;
			series = NULL;
		}
	}

	virtual void reset() {
		tick_index = -1;

		// TODO is this too much of an overhead?
		for (uint32_t i = 0; i < series_length; i++) {
			if (series[i]) {
				series[i]->reset();
			}
		}
	}

	void set_number(index_type sl) {
		 series_length =  sl;
	}


	inline void modify_tick(OrderBookQuantity quantity, OrderBookNumber num, OrderBookSide side, OrderBookLevel level) {
		// Preconditions
		next_tick();
		series[tick_index]->modify_tick(quantity, num, side, level);
	}

	void delete_tick(OrderBookSide side, OrderBookLevel level) {
		// Preconditions
		next_tick();
		series[tick_index]->delete_tick(side, level);
	}

	inline void insert_ask(tick_price_t & price, OrderBookQuantity quantity, OrderBookNumber num, index_type i, OrderBookLevel level) {
		next_tick();
		if (i < series_length - 1 && level < number_of_tick_levels - 1) {
			series[i]->insert_tick(price, quantity, num, Side::ASK, level);
		}
	}

	inline void insert_bid(const tick_price_t & price, OrderBookQuantity quantity, OrderBookNumber num, index_type i, OrderBookLevel level) {
		next_tick();
		if (i < series_length - 1 && level < number_of_tick_levels - 1) {
			series[i]->insert_tick(price, quantity, num, Side::BID, level);
		}
	}

	inline md_order_book3 & get_tick(int i) {
		return (*series[i]);
	}

	inline md_order_book3 & previous_tick() {
		if (tick_index == 0) {
			return (*series[series_length - 1]);
		}
		else {
			return (*series[tick_index - 1]);
		}
	}

	inline md_order_book3 & current_tick() {
		return (*series[tick_index]);
	}

	inline md_order_book3 & next_tick(bool copy = true) {
		if (tick_index >= series_length - 1) {
			if (copy) {
				(*series[0]) = (*series[tick_index]);
			}
			tick_index = 0;

		} else {
			if (copy && tick_index >= 0) {
				(*series[tick_index + 1]) = (*series[tick_index]);
			}
			tick_index++;
		}

		return current_tick();
	}

	inline md_order_book3 & copy_tick(int i) {
		if (tick_index >= series_length - 1) {
			(*series[0]) = (*series[i]);
			tick_index = 0;
		} else {
			if (i >= 0) {
				(*series[tick_index + 1]) = (*series[i]);
			}
			tick_index++;
		}

		return current_tick();
	}

	inline const char * get_series_name() {
		return series_name;
	}

	inline index_type get_tick_index() {
		return tick_index;
	}

	inline index_type current_length() {
		return tick_index + 1;
	}

	inline void set_tick_size(tick_size_t tickSize) {
		tick_size = tickSize;
	}

	inline tick_size_t get_tick_size() {
		return tick_size;
	}

	inline OrderBookLevel get_number_of_tick_levels() {
		return number_of_tick_levels;
	}

	void operator++(int) {
		tick_index++;
	}

	void operator--(int) {
		tick_index--;
	}

   md_order_book3 **get_series() {
	   return series;
   }

public:
	series_name_t series_name;
	index_type tick_index;
	md_order_book4_25 ** series;
	index_type series_length;
	tick_size_t tick_size;
	unsigned int number_of_tick_levels;

	inline void inc_tick_index() {
		tick_index++;
	}
};

#endif /* md_series_h_ */
