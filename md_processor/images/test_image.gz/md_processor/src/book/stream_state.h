#ifndef MARKETDATASTATE_H_
#define MARKETDATASTATE_H_

#include <stdint.h>
#include <map>

#include "common/entities/entity_types.h"
#include "common/net/stream.h"

/**
 * @brief Holds the state for an incremental data stream.
 */
template<typename BookContainer>
class stream_state {
public:

	typedef unsigned int SyncState;

	const static SyncState NeedSnapshot=0;
	const static SyncState Synchronized=1;

	stream_state(uint32_t maxDepth) : _seqNum(0), _mdState(NeedSnapshot), _lastType('X'), book(maxDepth) { }

	virtual ~stream_state() { }

	inline SyncState getMdState() const {
		return _mdState;
	}

	inline uint32_t getSeqNum() const {
		   return _seqNum;
	}

	inline unsigned char getLastType() const {
		  return _lastType;
	  }

	 inline void setMdState(SyncState _mdState) {
		 this->_mdState = _mdState;
	 }

	 inline void setSeqNum(uint32_t seqNum) {
		 _seqNum = seqNum;
	 }

	 inline void setLastType(unsigned char lastType) {
		_lastType = lastType;
	 }

	 inline void setSnapshotStream(const stream & stream) {
		 _snapshotStream = stream;
	 }

	 stream & getSnapshotStream() {
		 return _snapshotStream;
	 }

	 void setDeltaStream(const stream & stream) {
		 _deltaStream = stream;
	 }

	 stream & getDeltaStream() {
		 return _deltaStream;
	 }

	 BookContainer & getBook() {
		 return book;
	 }

private:
	uint32_t _seqNum;
	SyncState _mdState;
	unsigned char _lastType;
	stream _snapshotStream;
	stream _deltaStream;
	BookContainer book;
};

//typedef std::map< CntrId, stream_state<BookContainer> *> book_context_map;

#endif /* MARKETDATASTATE_H_ */
