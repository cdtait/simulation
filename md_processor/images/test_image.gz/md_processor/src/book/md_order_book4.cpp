#include <book/md_order_book4.h>

//tick_price_t OutOfScope(-1,0);
