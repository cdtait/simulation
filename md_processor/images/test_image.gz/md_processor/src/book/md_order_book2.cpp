#include "book/md_order_book2.h"

using namespace std;

md_order_book_2_side::md_order_book_2_side(uint32_t maxDepth) :
    maxDepth_(maxDepth)
{
    if (maxDepth > 256)
        throw logic_error("Order book max depth is too large");

    index_ = new uint8_t[maxDepth];
    levels_ = new Level[maxDepth];
        
    freeLevel_ = 0;
    Level* levelPtr = levels_;
    Level* endLevelPtr = levels_ + maxDepth;

    while (levelPtr < endLevelPtr)
    {
        levelPtr->next_ = freeLevel_;
        freeLevel_ = levelPtr;

        ++ levelPtr;
    }

    depth_ = 0;    
}

md_order_book_2_side::md_order_book_2_side(const md_order_book_2_side& orderBookSide):
    maxDepth_(orderBookSide.maxDepth_),
    depth_(orderBookSide.depth_)
{  
    index_ = new uint8_t[maxDepth_];
    memcpy(index_, orderBookSide.index_, maxDepth_);

    levels_ = new Level[maxDepth_];
    memcpy(levels_, orderBookSide.levels_, maxDepth_ * sizeof(Level));
        
    freeLevel_ = 0;
    Level* freeLevel = orderBookSide.freeLevel_;        

    while (freeLevel)
    {
        Level* levelPtr = levels_ + (freeLevel - orderBookSide.levels_);
            
        levelPtr->next_ = freeLevel_;
        freeLevel_ = levelPtr;

        freeLevel = freeLevel->next_;
    }
}

md_order_book_2_side::~md_order_book_2_side()
{
    delete[] levels_;
    delete[] index_;
}

void md_order_book_2_side::insert(uint32_t level, const price_t& price, uint32_t quantity, uint32_t orders)
{
    if (unlikely(level < 1 || level > maxDepth_)) {
        throw logic_error("insert-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    Level* levelPtr;

    if (level > depth_)
    {
        uint8_t* depthIndexPtr = index_ + depth_;

        while (depthIndexPtr < indexPtr)
        {
            Level* depthLevelPtr = freeLevel_;
            freeLevel_ = freeLevel_->next_;

            *depthIndexPtr = static_cast<uint8_t>( depthLevelPtr - levels_ );
            memset(depthLevelPtr, 0, sizeof(Level));

            ++ depthIndexPtr;
        }

        levelPtr = freeLevel_;
        freeLevel_ = freeLevel_->next_;

        depth_ = level;
    }
    else if (depth_ < maxDepth_)
    {
        levelPtr = freeLevel_;
        freeLevel_ = freeLevel_->next_;

        uint32_t count = depth_ - level + 1;

        switch (count)
        {
        case 1:
            indexPtr[1] = indexPtr[0];
            break;

        case 2:
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        case 3:
            indexPtr[3] = indexPtr[2];
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        case 4:
            indexPtr[4] = indexPtr[3];
            indexPtr[3] = indexPtr[2];
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        default:
            memmove(indexPtr + 1, indexPtr, count);
        }

        ++ depth_;
    }
    else
    {
        uint8_t* lastIndexPtr = index_ + depth_ - 1;
        levelPtr = levels_ + *lastIndexPtr;

        uint32_t count = depth_ - level;

        switch (count)
        {
        case 0:
            break;

        case 1:
            indexPtr[1] = indexPtr[0];
            break;

        case 2:
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        case 3:
            indexPtr[3] = indexPtr[2];
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        case 4:
            indexPtr[4] = indexPtr[3];
            indexPtr[3] = indexPtr[2];
            indexPtr[2] = indexPtr[1];
            indexPtr[1] = indexPtr[0];
            break;

        default:
            memmove(indexPtr + 1, indexPtr, count);
        }
    }

    *indexPtr = static_cast<uint8_t>( levelPtr - levels_ );
    levelPtr->entry.price = price;
    levelPtr->entry.quantity = quantity;
    levelPtr->entry.orders = orders;
}

void md_order_book_2_side::change(uint32_t level, uint32_t quantity, uint32_t orders)
{
    if (unlikely(level < 1 || level > depth_)) {
        throw logic_error("change-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    Level* levelPtr = levels_ + *indexPtr;

    levelPtr->entry.quantity = quantity;
    levelPtr->entry.orders = orders;
}

void md_order_book_2_side::overlay(uint32_t level, const price_t& price, uint32_t quantity, uint32_t orders)
{
    if (unlikely(level < 1 || level > depth_)) {
        throw logic_error("overlay-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    Level* levelPtr = levels_ + *indexPtr;

    levelPtr->entry.price = price;
    levelPtr->entry.quantity = quantity;
    levelPtr->entry.orders = orders;
}

void md_order_book_2_side::remove(uint32_t level)
{
    if (unlikely(level < 1 || level > depth_)) {
        throw logic_error("remove-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    Level* levelPtr = levels_ + *indexPtr;

    uint32_t count = depth_ - level;

    switch (count)
    {
    case 0:
        break;

    case 1:
        indexPtr[0] = indexPtr[1];
        break;

    case 2:
        indexPtr[0] = indexPtr[1];
        indexPtr[1] = indexPtr[2];
        break;

    case 3:
        indexPtr[0] = indexPtr[1];
        indexPtr[1] = indexPtr[2];
        indexPtr[2] = indexPtr[3];
        break;

    case 4:
        indexPtr[0] = indexPtr[1];
        indexPtr[1] = indexPtr[2];
        indexPtr[2] = indexPtr[3];
        indexPtr[3] = indexPtr[4];
        break;

    default:
        memmove(indexPtr, indexPtr + 1, count);
    }    

    levelPtr->next_ = freeLevel_;
    freeLevel_ = levelPtr;

    -- depth_;
}

void md_order_book_2_side::removeFrom(uint32_t level)
{
    if (unlikely(level < 1 || level > depth_)) {
        throw logic_error("removeFrom-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    uint8_t* endIndexPtr = index_ + depth_;

    while (indexPtr < endIndexPtr)
    {
        Level* levelPtr = levels_ + *indexPtr;

        levelPtr->next_ = freeLevel_;
        freeLevel_ = levelPtr;

        ++ indexPtr;
    }

    depth_ = level - 1;
}

void md_order_book_2_side::removeThru(uint32_t level)
{
    if (unlikely(level < 1 || level > depth_)) {
        throw logic_error("removeThru-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_;
    uint8_t* endIndexPtr = index_ + level;

    while (indexPtr < endIndexPtr)
    {
        Level* levelPtr = levels_ + *indexPtr;

        levelPtr->next_ = freeLevel_;
        freeLevel_ = levelPtr;

        ++ indexPtr;
    }

    uint32_t count = depth_ - level;
    memmove(index_, indexPtr, count);

    depth_ -= level;
}

void md_order_book_2_side::removeAll()
{
    uint8_t* indexPtr = index_;
    uint8_t* endIndexPtr = index_ + depth_;

    while (indexPtr < endIndexPtr)
    {
        Level* levelPtr = levels_ + *indexPtr;

        levelPtr->next_ = freeLevel_;
        freeLevel_ = levelPtr;

        ++ indexPtr;
    }

    depth_ = 0;
}

void md_order_book_2_side::reset()
{
    removeAll();    
}

ostream& operator<<(ostream& stream, const md_order_book_2_side& orderBookSide)
{
    for (uint32_t levelIndex = 0; levelIndex < orderBookSide.depth_; ++ levelIndex)
    {
        uint8_t* indexPtr = orderBookSide.index_ + levelIndex;
        md_order_book_2_side::Level* levelPtr = orderBookSide.levels_ + *indexPtr;

        if (levelIndex)
            stream << " ";

        stream << levelPtr->entry.quantity << '@' << (double)levelPtr->entry.price;
    }

    return stream;
}

