#ifndef  order_book_state_h_
#define order_book_state_h_

#include <map>
#include "common/entities/entity_types.h"

struct order_book_state {
	md_series * _order_book_records;
	stream_state * _state;
};

#endif	/* order_book_state_h_ */
