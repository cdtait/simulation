#ifndef md_order_book3_h
#define md_order_book3_h

#include "cme_mdp3/mktdata/SecurityTradingStatus.hpp"

using namespace mktdata;

typedef struct  {
	int64_t mDEntryPx_mantissa;
	int32_t mDEntrySize;
	int32_t numberOfOrders;
} entry;

typedef struct {
	entry bid;
	entry ask;
} level;

template<int levels=5>
struct md_order_book3 {
	void set_event(Event event) {
		this->event=event;
	}

	void set_trade_id(int32_t tradeID) {
		this->trade_id=tradeID;
	}

	void set_trade_price(trade_price_t tradePrice) {
		this->trade_price=tradePrice;
	}

	void set_trade_quantity(TradeQuantity tradeQuantity) {
		this->trade_quantity=tradeQuantity;
	}

	void set_trade_side(TradeSide tradeSide) {
		this->trade_side=tradeSide;
	}

	void set_num_buyers(OrderBookNumber numBuyers) {
		this->num_buyers=numBuyers;
	}

	void set_num_sellers(OrderBookNumber numSellers) {
		this->num_sellers=numSellers;
	}

	void set_exchange_time(nano_time_t exchange_time) {
		this->transactTime=exchange_time;
	}

	void set_receive_time(nano_time_t receive_time) {
		this->lastUpdateTime=receive_time;
	}

	void set_aggressor_time(nano_time_t aggressor_time) {
		this->transactTime=aggressor_time;
	}

	void set_is_valid(bool is_valid) {
		this->mDSecurityTradingStatus=is_valid ? SecurityTradingStatus::ReadyToTrade : SecurityTradingStatus::UnknownorInvalid;
	}

	void set_packet_seqnum(uint32_t packet_seqnum) {
		this->lastMsgSeqNumProcessed=packet_seqnum;
	}

	void set_packet_time_stamp(uint32_t packet_time_stamp) {
		this->lastUpdateTime=packet_time_stamp;
	}

	void set_series_name(const std::string & name) {
		::strcpy(series_name, name.c_str());
	}

	void set_security_id(CntrId security_id) {
		this->securityID=security_id;
	}

	Event get_event() {
		return event;
	}

	int32_t get_trade_id() {
		return trade_id;
	}

	trade_price_t get_trade_price() {
		return trade_price;
	}

	TradeQuantity get_trade_quantity() {
		return trade_quantity;
	}

	TradeSide get_trade_side() {
		return trade_side;
	}

	OrderBookNumber get_num_buyers() {
		return num_buyers;
	}

	OrderBookNumber get_num_sellers() {
		return num_sellers;
	}

	nano_time_t get_exchange_time() {
		return transactTime;
	}

	nano_time_t get_receive_time() {
		return lastUpdateTime;
	}

	nano_time_t get_aggressor_time() {
		return transactTime;
	}

	bool get_is_valid() {
		return mDSecurityTradingStatus!=SecurityTradingStatus::UnknownorInvalid;
	}

	uint32_t get_packet_seqnum() {
		return this->lastMsgSeqNumProcessed;
	}

	uint32_t get_packet_time_stamp() {
		return this->lastUpdateTime;
	}

	std::string get_series_name() {
		return series_name;
	}

	CntrId get_security_id() {
		return this->securityID;
	}

	uint32_t lastMsgSeqNumProcessed{};
	uint32_t totNumReports{};
	CntrId securityID{};
	uint32_t rptSeq{};
	uint64_t transactTime{};
	uint64_t lastUpdateTime{};
	uint16_t tradeDate{};
	SecurityTradingStatus::Value mDSecurityTradingStatus{};
	level entries[levels];

	Event event{Event::Unknown};

	int32_t trade_id=0;
	trade_price_t trade_price{};
	TradeQuantity trade_quantity=0;
	TradeSide trade_side=Side::Unknown;
	OrderBookNumber num_buyers=0;
	OrderBookNumber num_sellers=0;

	series_name_t series_name{};
};

#endif
