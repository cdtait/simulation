#include "book_vector.h"

 BookVector::SortedBids & BookVector::get_sorted_bids() {
	sortedBidLevels.clear();
	sorted_bid(*this,sortedBidLevels);
	return sortedBidLevels;
}

 BookVector::SortedAsks & BookVector::get_sorted_asks() {
	sortedAskLevels.clear();
	sorted_ask(*this,sortedAskLevels);
	return sortedAskLevels;
}

void BookVector::clear() {
	bidLevels.clear();
	askLevels.clear();
}

#include "vectormath_exp.h"

// TODO Also floats and doubles if needed.

/**
 *  @brief  Vectorize the sum od quantities
 *  @param  vector of quantities
 *
 *  Using VCL as included in vectorclass sub dir
 *
 */
QuantityValueType vector_sum(std::vector<QuantityValueType> vec) {
	const int datasize = vec.size();
	decltype(vec.data()) data = vec.data();

	typedef VecType<QuantityValueType>  VecT;
	const int regularpart = datasize & (-VecT::size);

	// Vector load and sum
	VecT::value_type sum1(0), temp;

	int i;
	for (i = 0; i < regularpart; i += VecT::size) {
		temp.load(data+i);
		sum1 += temp;
	}

	QuantityValueType sum = horizontal_add(sum1);

	// Sum remaining element with do not fit a vector add
	// i.e if 13 elements and VecT::size is 8 then we
	// add the remaining 5 here
	for (; i < datasize; i++) {
		sum += vec.data()[i];
	}

	return sum;
}

auto sum(BookVector::Orders & orders) -> QuantityValueType {
	return vector_sum(orders.orders);
}
