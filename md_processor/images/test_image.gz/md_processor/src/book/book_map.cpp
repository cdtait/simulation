#include "book_map.h"


/**
 *  @brief  Get the top bid
 *  @return top bid price
 *
 *  As price levels are maintained in sort
 *  all we need to do is return the top
 *
 */
PriceLevelKey BookMap::get_top_bid() {
	auto top_bid = bidLevels.begin();
	if (top_bid!=bidLevels.end()) {
		return bidLevels.begin()->first;
	}
	else {
		return PriceLevelKey();
	}
}

/**
 *  @brief  Get the top ask
 *  @return top bid price
 *
 *  As price levels are maintained in sort
 *  all we need to do is return the top
 *
 */
PriceLevelKey BookMap::get_top_ask() {
	auto top_ask =  askLevels.begin();
	if (top_ask!=askLevels.end()) {
		return askLevels.begin()->first;
	}
	else {
		return PriceLevelKey();
	}
}

void BookMap::clear() {
	bidLevels.clear();
	askLevels.clear();
}
