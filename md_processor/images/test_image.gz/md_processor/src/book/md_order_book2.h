#ifndef md_order_book2_h
#define md_order_book2_h

#include <stdexcept>
#include <ostream>

#include "md_helper.h"
#include "common/entities/entity_types.h"

struct md_order_book_2_level
{
	price_t price;
	OrderBookQuantity quantity;
	OrderBookNumber orders;
};

class md_order_book_2_side
{
public:

    // Construction / destruction

	md_order_book_2_side(uint32_t maxDepth);
	md_order_book_2_side(const md_order_book_2_side& orderBookSide);

    ~md_order_book_2_side();

    // Attributes

    inline uint32_t getMaxDepth() const;

    // Levels

    inline uint32_t getDepth() const;

    inline const md_order_book_2_level& getTopLevel() const;

    inline const md_order_book_2_level& getBottomLevel() const;

    inline const md_order_book_2_level& getLevel(uint32_t level) const;

    void insert(uint32_t level, const price_t& price, uint32_t quantity, uint32_t orders);

    void change(uint32_t level, uint32_t quantity, uint32_t orders);

    void overlay(uint32_t level, const price_t& price, uint32_t quantity, uint32_t orders);

    void remove(uint32_t level);

    void removeFrom(uint32_t level);

    void removeThru(uint32_t level);

    void removeAll();

    // Resetting

    void reset();

private:

    friend std::ostream& operator<<(std::ostream& stream, const md_order_book_2_side& orderBookSide);

    //union Level
    struct Level
    {
    	md_order_book_2_level entry;
        Level* next_;
    };          

    uint32_t maxDepth_;
       
    uint32_t depth_;
    uint8_t* index_;
    Level* levels_;
    Level* freeLevel_;
};

inline uint32_t md_order_book_2_side::getMaxDepth() const
{
    return maxDepth_;
}

inline uint32_t md_order_book_2_side::getDepth() const
{
    return depth_;
}

inline const md_order_book_2_level& md_order_book_2_side::getTopLevel() const
{
    if (unlikely(!depth_))
        throw std::logic_error("Order book side is empty");

    Level* levelPtr = (levels_ + *index_);

    return levelPtr->entry;
}

inline const md_order_book_2_level& md_order_book_2_side::getBottomLevel() const
{
    if (unlikely(!depth_))
        throw std::logic_error("Order book side is empty");

    Level* levelPtr = levels_ + index_[depth_ - 1];

    return levelPtr->entry;
}

inline const md_order_book_2_level& md_order_book_2_side::getLevel(uint32_t level) const
{
    if (unlikely(level < 1 || level > depth_)) {
        throw std::logic_error("getLevel-Invalid order book price level " + std::to_string(level) + "," + std::to_string(depth_));
    }

    uint8_t* indexPtr = index_ + level - 1;
    Level* levelPtr = levels_ + *indexPtr;

    return levelPtr->entry;
}

std::ostream& operator<<(std::ostream& stream, const md_order_book_2_side& orderBookSide);

class md_order_book2
{
public:
    inline md_order_book2(uint32_t maxDepth);

    inline md_order_book_2_side& bid();
    inline const md_order_book_2_side& bid() const;

    inline md_order_book_2_side& ask();
    inline const md_order_book_2_side& ask() const;

    inline void reset();

	void set_event(Event event) {
		this->event=event;
	}

	void set_trade_id(int32_t tradeID) {
		this->tradeID=tradeID;
	}

	void set_trade_price(trade_price_t tradePrice) {
		this->tradePrice=tradePrice;
	}

	void set_trade_quantity(TradeQuantity tradeQuantity) {
		this->tradeQuantity=tradeQuantity;
	}

	void set_trade_side(TradeSide tradeSide) {
		this->tradeSide=tradeSide;
	}

	void set_num_buyers(OrderBookNumber numBuyers) {
		this->numBuyers=numBuyers;
	}

	void set_num_sellers(OrderBookNumber numSellers) {
		this->numSellers=numSellers;
	}

	void set_trade_volume(TradeVolume tradeVolume) {
		this->tradeVolume;
	}

	void set_exchange_time(nano_time_t exchange_time) {
		this->exchange_time=exchange_time;
	}

	void set_receive_time(nano_time_t receive_time) {
		this->receive_time=receive_time;
	}

	void set_aggressor_time(nano_time_t aggressor_time) {
		this->aggressor_time=aggressor_time;
	}

	void set_is_valid(bool is_valid) {
		this->is_valid=is_valid;
	}

	void set_packet_seqnum(uint32_t packet_seqnum) {
		this->packet_seqnum=packet_seqnum;
	}

	void set_packet_time_stamp(nano_time_t packet_time_stamp) {
		this->packet_time_stamp=packet_time_stamp;
	}

	void set_series_name(const std::string & name) {
		::strcpy(series_name, name.c_str());
	}

	void set_security_id(CntrId security_id) {
		this->security_id=security_id;
	}

	void set_rpt_seqnum(uint32_t rpt_seqnum) {
		this->rpt_seqnum=rpt_seqnum;
	}

	Event get_event() const {
		return event;
	}

	int32_t get_trade_id() const {
		return tradeID;
	}

	trade_price_t get_trade_price() const {
		return tradePrice;
	}

	TradeQuantity get_trade_quantity() const {
		return tradeQuantity;
	}

	TradeSide get_trade_side() const {
		return tradeSide;
	}

	OrderBookNumber get_num_buyers() const {
		return numBuyers;
	}

	OrderBookNumber get_num_sellers() const {
		return numSellers;
	}

	TradeVolume get_trade_volume() const {
		return tradeVolume;
	}

	nano_time_t get_exchange_time() const {
		return exchange_time;
	}

	nano_time_t get_receive_time() const {
		return receive_time;
	}

	nano_time_t get_aggressor_time() const {
		return aggressor_time;
	}

	bool get_is_valid() const {
		return is_valid;
	}

	uint32_t get_packet_seqnum() const {
		return packet_seqnum;
	}

	nano_time_t get_packet_time_stamp() const {
		return packet_time_stamp;
	}

	std::string get_series_name() const {
		return series_name;
	}

	CntrId get_security_id() const {
		return security_id;
	}

	uint32_t get_rpt_seqnum() const {
		return rpt_seqnum;
	}

private:
    md_order_book_2_side bidSide_;
    md_order_book_2_side askSide_;

	Event event{Event::Unknown};

	int32_t tradeID=0;
	trade_price_t tradePrice{};
	TradeQuantity tradeQuantity=0;
	TradeSide tradeSide=Side::Unknown;
	OrderBookNumber numBuyers=0;
	OrderBookNumber numSellers=0;
	TradeVolume tradeVolume=0;

	nano_time_t exchange_time=0;
	nano_time_t receive_time=0;
	nano_time_t aggressor_time=0;
	bool is_valid=false;
	uint32_t packet_seqnum=0;
	nano_time_t packet_time_stamp=0;
	series_name_t series_name{};
	CntrId security_id=0;
	uint32_t rpt_seqnum=0;
};

inline md_order_book2::md_order_book2(uint32_t maxDepth) :
    bidSide_(maxDepth),
    askSide_(maxDepth)
{
}

inline md_order_book_2_side& md_order_book2::bid()
{
    return bidSide_;
}

inline const md_order_book_2_side& md_order_book2::bid() const
{
    return bidSide_;
}

inline md_order_book_2_side& md_order_book2::ask()
{
    return askSide_;
}

inline const md_order_book_2_side& md_order_book2::ask() const
{
    return askSide_;
}

inline void md_order_book2::reset()
{
    bidSide_.reset();
    askSide_.reset();
}

#endif
