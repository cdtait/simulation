#ifndef md_order_book4_h
#define md_order_book4_h

#include "common/entities/entity_types.h"
#include "common/logging/logging_util.h"
#include "common/events/event.h"

#include <fstream>
#include <iostream>

static tick_price_t OutOfScope(-1,0);
            
/*
class md_order_book4_i {
public:
	virtual md_order_book4_i & operator =(const md_order_book4_i & copy) = 0;
	virtual void initialize()=0;
	virtual int bytes_size()=0;
	virtual void insert_tick(const tick_price_t & price, OrderBookQuantity quantity, OrderBookNumber num, OrderBookSide side, OrderBookLevel level)=0;
	virtual void modify_tick(SignedQuantity quantity, SignedQuantity num, OrderBookSide side, OrderBookLevel level) =0;
	virtual void delete_tick(OrderBookSide side, OrderBookLevel level)=0;

	virtual tick_price_t & get_bid_price(OrderBookLevel level)=0;
	virtual tick_price_t & get_ask_price(OrderBookLevel level)=0;
	virtual tick_price_t get_mid_price()=0;
	virtual OrderBookQuantity get_bid_quantity(OrderBookLevel level)=0;
	virtual OrderBookQuantity get_ask_quantity(OrderBookLevel level)=0;
	virtual OrderBookNumber get_bid_contributors(OrderBookLevel level)=0;
	virtual OrderBookNumber get_ask_contributors(OrderBookLevel level)=0;
	virtual tick_price_t & get_trade_price()=0;
	virtual OrderBookQuantity get_trade_quantity()=0;
	virtual TradeSide get_trade_side()=0;
	virtual OrderBookNumber get_trade_num_buyers()=0;
	virtual OrderBookNumber get_trade_num_sellers()=0;

	virtual void set_trade_price(tick_price_t & tradePrice)=0;
	virtual void set_trade_quantity(OrderBookQuantity tradeQuantity)=0;
	virtual void set_trade_side(OrderBookSide tradeSide)=0;
	virtual void set_trade_num_buyers(OrderBookNumber numBuyers)=0;
	virtual void set_trade_num_sellers(OrderBookNumber numSellers)=0;

	virtual void set_trading_type(MDType type)=0;
	virtual MDType get_trading_type()=0;
	virtual OrderBookLevel get_num_tick_levels()=0;
	virtual tick_size_t get_tick_size()=0;
	virtual micro_time_t get_exchange_time() const=0;
	virtual void set_exchange_time(micro_time_t et)=0;
	virtual micro_time_t get_receive_time() const=0;
	virtual void set_receive_time(micro_time_t _recvTime)=0;
	virtual micro_time_t get_timeof_aggressor() const=0;
	virtual void set_aggressor_time(micro_time_t aggressorTime)=0;

	virtual void set_packet_seqnum(uint32_t ps)=0;
	virtual void set_packet_seqnum_index(uint32_t ps)=0;
	virtual void set_packet_time_stamp(micro_time_t ts)=0;
	virtual void set_performance_indicator(uint32_t pi)=0;
	virtual void set_size_payload(int pi)=0;

	virtual uint32_t get_packet_seqnum()=0;
	virtual uint32_t get_packet_seqnum_index()=0;
	virtual micro_time_t get_packet_time_stamp()=0;
	virtual uint32_t get_performance_indicator()=0;
	virtual char get_trading_status()=0;
	virtual int get_size_payload()=0;

	virtual const char * get_series_name()=0;

	virtual bool is_tick_valid()=0;
	virtual void set_validity(bool valid)=0;

	virtual string to_string(int depth = 5)=0;

	virtual void dump(ostream & out, uint32_t depth = 5)=0;

	virtual void read(const string & stringRep, const bool & legacy=false)=0;
	virtual void write(ostream & out,OrderBookLevel depth)=0;
	virtual void reset()=0;

	virtual int compare(md_order_book4_i & ref)=0;

	virtual tick_price_t * get_prices()=0;
	virtual OrderBookQuantity * get_quantities()=0;
	virtual OrderBookNumber * get_contributors()=0;
};
*/

template <unsigned int number_of_tick_levels=25>
//class md_order_book4 : public md_order_book4_i {
class md_order_book4 {
public:

	md_order_book4(const char* sn, tick_size_t tickSize, OrderBookPlaces decimalPlaces = 4) :
	tradeNumBuyers(0),
	tradeNumSellers(0),
	filled_number_of_tick_levels(number_of_tick_levels),
	_type(NoType),
	_tradeId(0),
	_tradePrice(0,0),
	_tradeQuantity(0),
	_tradeSide(TradeSide::Unknown),
	_numBuyers(0),
	_numSellers(0),
	tick_size(tickSize),
	exchange_time(0),
	receive_time(0),
	aggressor_time(0),
	//_event(NULL),
	//logger(Logger::getLogger("common.entities.md_tick")),
	is_valid(true),
	packet_seqnum(0),
	packet_time_stamp(0),
	performance_indicator(0),
	trading_status('1'),
	packet_seqnum_index(0)
	{
		strncpy(series_name, sn, SERIES_NAME_LEN);
		initialize();


	}

	//virtual ~md_order_book4() { }

	md_order_book4(const md_order_book4 & copy) {
		tick_size = copy.tick_size;

		for (OrderBookLevel i = 0; i < 2 * number_of_tick_levels; i++) {
			_bidask[i] = copy._bidask[i];
			_bszasz[i] = copy._bszasz[i];
			_bnoano[i] = copy._bnoano[i];
		}

		_type = copy._type;

		exchange_time = copy.exchange_time;
		receive_time = copy.receive_time;

		is_valid = true;
	}

	md_order_book4 & operator =(const md_order_book4 & copy) {
		tick_size = copy.tick_size;

		for (OrderBookLevel i = 0; i < 2 * number_of_tick_levels; i++) {
			_bidask[i] = copy._bidask[i];
			_bszasz[i] = copy._bszasz[i];
			_bnoano[i] = copy._bnoano[i];
		}

		_type = copy._type;
		_tradePrice = copy._tradePrice;
		_tradeQuantity = copy._tradeQuantity;
		_tradeSide = copy._tradeSide;

		exchange_time = copy.exchange_time;
		receive_time = copy.receive_time;
		aggressor_time = copy.aggressor_time;

		is_valid = true;
		packet_seqnum = 0;
		packet_time_stamp = 0;
		performance_indicator = 0;
		trading_status = copy.trading_status;
		packet_seqnum_index=0;

		return *this;
	}

	/*
	inline md_order_book4 & operator =(const md_order_book4 & c) {
		md_order_book4 & copy = const_cast<md_order_book4 &>(c);

		tick_size = copy.get_tick_size();

		for (OrderBookLevel i = 0; i < number_of_tick_levels; i++) {
			_bidask[i].set_mantissa(copy.get_bid_price(i).get_mantissa());
			_bidask[i].set_exponent(copy.get_bid_price(i).get_exponent());

			_bidask[i+number_of_tick_levels].set_mantissa(copy.get_ask_price(i).get_mantissa());
			_bidask[i+number_of_tick_levels].set_exponent(copy.get_ask_price(i).get_exponent());

			_bszasz[i] = copy.get_bid_quantity(i);
			_bszasz[i+number_of_tick_levels] = copy.get_ask_quantity(i);

			_bnoano[i] = copy.get_bid_contributors(i);
			_bnoano[i+number_of_tick_levels] = copy.get_ask_contributors(i);
		}

		_type = copy.get_trading_type();
		_tradePrice = copy.get_trade_price();
		_tradeQuantity = copy.get_trade_quantity();
		_tradeSide = copy.get_trade_side();

		exchange_time = copy.get_exchange_time();
		receive_time = copy.get_receive_time();
		aggressor_time = copy.get_timeof_aggressor();

		is_valid = true;
		packet_seqnum = 0;
		packet_time_stamp = 0;
		performance_indicator = 0;
		trading_status = copy.get_trading_status();
		packet_seqnum_index=0;

		return *this;
	}
*/
/*
	md_tick_t & operator =(const md_tick_t & copy) {
		packet_seqnum = 0;
		packet_time_stamp = 0;
		performance_indicator = 0;

		memcpy((void *)&receive_time,(void *)&copy.receive_time,8);
		memcpy((void *)&series_name,(void *)&copy.series_name,SERIES_NAME_LEN);
		memcpy((void *)&filled_number_of_tick_levels,(void *)&copy.filled_number_of_tick_levels,4);
		memcpy((void *)&_type,(void *)&copy._type,4);
		memcpy((void *)&_tradePrice,(void *)&copy._tradePrice,sizeof(_tradePrice));
		memcpy((void *)&_tradeQuantity,(void *)&copy._tradeQuantity,4);
		memcpy((void *)&_tradeSide,(void *)&copy._tradeSide,4);
		memcpy((void *)&_numBuyers,(void *)&copy._numBuyers,4);
		memcpy((void *)&_numSellers,(void *)&copy._numSellers,4);
		memcpy((void *)&tick_size,(void *)&copy.tick_size,sizeof(tick_size));
		memcpy((void *)&exchange_time,(void *)&copy.exchange_time,8);
		memcpy((void *)&aggressor_time,(void *)&copy.aggressor_time,8);
		memcpy((void *)&is_valid,(void *)&copy.is_valid,1);
		memcpy((void *)_bnoano,(void *)copy._bnoano,2*number_of_tick_levels*4);
		memcpy((void *)_bszasz,(void *)copy._bszasz,2*number_of_tick_levels*4);
		memcpy((void *)_bidask,(void *)copy._bidask,2*number_of_tick_levels*sizeof(tick_price_t));
		return *this;
	}
*/

	void initialize() {
		for (OrderBookLevel i = 0; i < 2 * number_of_tick_levels; i++) {
			_bidask[i] = 0;
			_bszasz[i] = 0;
			_bnoano[i] = 0;
		}

		_tradeQuantity = 0;
		_tradePrice = 0;
		_tradeSide = TradeSide::Unknown;
		_numBuyers = 0;
		_numSellers = 0;

		_type = NoType;

		exchange_time = 0;
		receive_time = 0;
		aggressor_time = 0;

		is_valid = true;
		packet_seqnum = 0;
		packet_time_stamp = 0;
		performance_indicator = 0;
		trading_status = '1';
		packet_seqnum_index = 0;

		//_event = NULL;
	}

	int bytes_size() {
		return sizeof (md_order_book4);
	}

	inline void insert_tick(const tick_price_t & price, OrderBookQuantity quantity, OrderBookNumber num, OrderBookSide side, OrderBookLevel level) {
	   // LOG_TRACE(logger, "OrderBook add: price:" << price << " quantity:" << quantity << " number:" << num << " side:" << side << " level:" << level << "\n");

		if (side == OrderBookSide::Bid) {
			_bszasz[level] = quantity;
			_bidask[level].set_exponent(price.get_exponent());
			_bidask[level].set_mantissa(price.get_mantissa());
			_bnoano[level] = num;
		} else {
			_bszasz[level + number_of_tick_levels] = quantity;
			_bidask[level + number_of_tick_levels].set_exponent(price.get_exponent());
			_bidask[level + number_of_tick_levels].set_mantissa(price.get_mantissa());
			_bnoano[level + number_of_tick_levels] = num;
		}
	}

	inline void modify_tick(SignedQuantity quantity, SignedQuantity num, OrderBookSide side, OrderBookLevel level) {
		if (side == OrderBookSide::Bid) {
			_bszasz[level] += quantity;
			_bnoano[level] += num;
		} else {
			_bszasz[level + number_of_tick_levels] += quantity;
			_bnoano[level + number_of_tick_levels] += num;
		}
	}

	inline void delete_tick(OrderBookSide side, OrderBookLevel level) {
		if (side == OrderBookSide::Bid) {
			_bszasz[level] = EMPTY;
			_bidask[level] = EMPTY;
			_bnoano[level] = EMPTY;
		} else {
			_bszasz[level + number_of_tick_levels] = EMPTY;
			_bidask[level + number_of_tick_levels] = EMPTY;
			_bnoano[level + number_of_tick_levels] = EMPTY;
		}
	}

	inline tick_price_t & get_bid_price(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bidask[level];
		else
			return OutOfScope;
	}

	inline tick_price_t & get_ask_price(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bidask[level + number_of_tick_levels];
		else
			return OutOfScope;
	}

	inline tick_price_t get_mid_price() {
		return (get_bid_price(0) + get_ask_price(0)) * decimal_type::Half;
	}

	inline OrderBookQuantity get_bid_quantity(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bszasz[level];
		else
			return -1;
	}

	inline OrderBookQuantity get_ask_quantity(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bszasz[level + number_of_tick_levels];
		else
			return -1;
	}

	inline OrderBookNumber get_bid_contributors(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bnoano[level];
		else
			return -1;
	}

	inline OrderBookNumber get_ask_contributors(OrderBookLevel level) {
		if (level < number_of_tick_levels)
			return _bnoano[level + number_of_tick_levels];
		else
			return -1;
	}

	inline tick_price_t & get_trade_price() {
		return _tradePrice;
	}

	inline OrderBookQuantity get_trade_quantity() {
		return _tradeQuantity;
	}

	inline TradeSide get_trade_side() {
		return _tradeSide;
	}

	OrderBookNumber get_trade_num_buyers() {
		return _numBuyers;
	}

	OrderBookNumber get_trade_num_sellers() {
		return _numSellers;
	}

	inline void set_trade_id(int32_t tradeId) {
		_tradeId=tradeId;
	}

	inline void set_trade_price(tick_price_t & tradePrice) {
		_tradePrice.set_exponent(tradePrice.get_exponent());
		_tradePrice.set_mantissa(tradePrice.get_mantissa());
	}

	inline void set_trade_quantity(OrderBookQuantity tradeQuantity) {
		_tradeQuantity = tradeQuantity;
	}

	inline void set_trade_side(OrderBookSide tradeSide) {
		_tradeSide = tradeSide;
	}

	inline void set_trade_num_buyers(OrderBookNumber numBuyers) {
		_numBuyers = numBuyers;
	}

	inline void set_trade_num_sellers(OrderBookNumber numSellers) {
		_numSellers = numSellers;
	}

	inline void set_trading_type(MDType type) {
		_type = type;
	}

	inline MDType get_trading_type() {
		return _type;
	}

	inline OrderBookLevel get_num_tick_levels() {
		return number_of_tick_levels;
	}

	inline tick_size_t get_tick_size() {
		return tick_size;
	}

	inline micro_time_t get_exchange_time() const {
		return exchange_time;
	}

	inline void set_exchange_time(micro_time_t et) {
		exchange_time = et;
	}

	inline micro_time_t get_receive_time() const {
		return receive_time;
	}

	inline void set_receive_time(micro_time_t _recvTime) {
		this->receive_time = _recvTime;
	}

	inline micro_time_t get_timeof_aggressor() const {
		return aggressor_time;
	}

	inline void set_aggressor_time(micro_time_t aggressorTime) {
		this->aggressor_time = aggressorTime;
	}

	string to_string(int depth = 5) {
		std::stringstream ss("");

		ss.flags(std::ios::right);
		ss << "\n========================================================================\n";
		ss << "Instrument: " << series_name << "\n";
		ss << "========================================================================\n";
		ss << " Level  BidNum  BidSize       BidPrice        AskPrice   AskSize  AskNum\n";
		ss << " -----------------------------------------------------------------------\n";
#ifdef __TOP_OF_BOOK__
			ss.width(6); ss << 0;
			ss.width(8); ss << _bnoano[number_of_tick_levels-1];
			ss.width(8); ss << _bszasz[number_of_tick_levels-1];
			ss.width(16); ss << _bidask[number_of_tick_levels-1].get_decimal();
			ss << "    ";
			ss.width(12); ss << _bidask[number_of_tick_levels + number_of_tick_levels-1].get_decimal();
			ss.width(10); ss << _bszasz[number_of_tick_levels + number_of_tick_levels-1];
			ss.width(8); ss << _bnoano[number_of_tick_levels + number_of_tick_levels-1];
			ss << std::endl;
#endif
		for (int j = 0; j < depth; j++) {
			ss.width(6); ss << j + 1;
			ss.width(8); ss << _bnoano[j];
			ss.width(8); ss << _bszasz[j];
			ss.width(16); ss << _bidask[j].get_decimal();
			ss << "    ";
			ss.width(12); ss << _bidask[j + number_of_tick_levels].get_decimal();
			ss.width(10); ss << _bszasz[j + number_of_tick_levels];
			ss.width(8); ss << _bnoano[j + number_of_tick_levels];
			ss << std::endl;
		}

		ptime recvTime;
		recvTime.stamp(receive_time);
		ss << " -----------------------------------------------------------------------\n";
		ss << "RecvTime: " << recvTime.readable();
		ss << "MicroTime: " << receive_time << "\n";
		ss << "========================================================================\n";

		return ss.str();
	}

	void dump(ostream & out, uint32_t depth = 5) {
		out << to_string(depth);
	}

	void read(const string & stringRep, const bool & legacy=false) {

		if (!stringRep.empty() && stringRep != "") {
			boost::char_separator<char> sep(",");
			boost::tokenizer<boost::char_separator<char> > tokens(stringRep, sep);
			boost::tokenizer<boost::char_separator<char> >::iterator it = tokens.begin();

			string recvTime = *it++;
			receive_time = atoll(recvTime.c_str());

			string contractName = *it++;
			strncpy(series_name,contractName.c_str(),SERIES_NAME_LEN-1);

			string numLevels = *it++;
			filled_number_of_tick_levels = atoi(numLevels.c_str());

			string type = *it++;
			_type = (MDType)atoi(type.c_str());

			string tradePrice = *it++;
			_tradePrice.set_decimal(tradePrice);

			string tradeQuantity = *it++;
			_tradeQuantity = (TradeQuantity)atoi(tradeQuantity.c_str());

			string tradeSide = *it++;
			_tradeSide = (TradeSide)atoi(tradeSide.c_str());

			string numBuyers = *it++;
			OrderBookNumber nb = atoi(numBuyers.c_str());
			_numBuyers = nb;

			string numSellers = *it++;
			OrderBookNumber ns = atoi(numSellers.c_str());
			_numSellers = ns;

			string tickSize = *it++;
			tick_size.set_decimal(tickSize);

			string origTime = *it++;
			exchange_time = atoll(origTime.c_str());

			string aggressorTime = *it++;
			aggressor_time = atoll(aggressorTime.c_str());

			string valid = *it++;
			is_valid = (atoi(valid.c_str()) == 1) ? true : false;

			string d = *it++;
			OrderBookLevel depth = atoi(d.c_str());

			for (OrderBookLevel j = 0; j < depth; j++) {

				string bno = *it++;
				OrderBookNumber _bno = atoi(bno.c_str());
				_bnoano[j] = _bno;

				string bsz = *it++;
				OrderBookQuantity _bsz = atoi(bsz.c_str());
				_bszasz[j] = _bsz;

				string bid = *it++;
				_bidask[j].set_decimal(bid);

				string ask = *it++;
				_bidask[j + number_of_tick_levels].set_decimal(ask);

				string asz = *it++;
				OrderBookQuantity _asz = atoi(asz.c_str());
				_bszasz[j + number_of_tick_levels] = _asz;

				string ano = *it++;
				OrderBookNumber _ano = atoi(ano.c_str());
				_bnoano[j + number_of_tick_levels] = _ano;
			}

			if (!it.at_end()) {
				string ps = *it++;
				packet_seqnum = atoi(ps.c_str());
			}

			if (!it.at_end()) {
				string pt = *it++;
				packet_time_stamp = atoll(pt.c_str());
			}

			if (!it.at_end()) {
				string pi = *it++;
				performance_indicator = atoi(pi.c_str());
			}

			if (!it.at_end()) {
				string ts = *it++;
				trading_status = ts.c_str()[0];
			}

			if (!it.at_end()) {
				string psi = *it++;
				packet_seqnum_index = atoi(psi.c_str());
			}

#ifdef __TOP_OF_BOOK__
				string bno = *it++;
				OrderBookNumber _bno = atoi(bno.c_str());
				_bnoano[number_of_tick_levels-1] = _bno;

				string bsz = *it++;
				OrderBookQuantity _bsz = atoi(bsz.c_str());
				_bszasz[number_of_tick_levels-1] = _bsz;

				string bid = *it++;
				_bidask[number_of_tick_levels-1].set_decimal(bid);

				string ask = *it++;
				_bidask[number_of_tick_levels + number_of_tick_levels-1].set_decimal(ask);

				string asz = *it++;
				OrderBookQuantity _asz = atoi(asz.c_str());
				_bszasz[number_of_tick_levels + number_of_tick_levels-1] = _asz;

				string ano = *it++;
				OrderBookNumber _ano = atoi(ano.c_str());
				_bnoano[number_of_tick_levels + number_of_tick_levels-1] = _ano;
#endif
		}
		else {
			return;
		}
	}

	void read_bin(ifstream & bin_file_streami,OrderBookLevel depth) {
			bin_file_streami.read((char *)&receive_time,8);
			bin_file_streami.read((char *)&series_name,SERIES_NAME_LEN);
			bin_file_streami.read((char *)&filled_number_of_tick_levels,4);
			bin_file_streami.read((char *)&_type,4);
			bin_file_streami.read((char *)&_tradePrice,sizeof(_tradePrice));
			bin_file_streami.read((char *)&_tradeQuantity,4);
			bin_file_streami.read((char *)&_tradeSide,4);
			bin_file_streami.read((char *)&_numBuyers,4);
			bin_file_streami.read((char *)&_numSellers,4);
			bin_file_streami.read((char *)&tick_size,sizeof(tick_size));
			bin_file_streami.read((char *)&exchange_time,8);
			bin_file_streami.read((char *)&aggressor_time,8);
			bin_file_streami.read((char *)&is_valid,1);
			bin_file_streami.read((char *)_bnoano,2*depth*4);
			bin_file_streami.read((char *)_bszasz,2*depth*4);
			bin_file_streami.read((char *)_bidask,2*depth*sizeof(tick_price_t));
	}

	void write(ostream & out,OrderBookLevel depth) {
		 out << get_receive_time();out << ",";
		 out << series_name;out << ",";
		 out << filled_number_of_tick_levels;out << ",";
		 out << get_trading_type();out << ",";
		 out << get_trade_price().get_decimal();out << ",";
		 out << get_trade_quantity();out << ",";
		 out << get_trade_side();out << ",";
		 out << get_trade_num_buyers();out << ",";
		 out << get_trade_num_sellers();out << ",";
		 out << get_tick_size();out << ",";
		 out << get_exchange_time();out << ",";
		 out << get_timeof_aggressor();out << ",";
		 int valid =  (is_tick_valid()) ? 1 : 0;
		 out << valid;out << ",";

		 out << depth;out << ",";

		 for (OrderBookLevel j = 0; j < depth; j++) {
				out << get_bid_contributors(j);out << ",";
				out << get_bid_quantity(j);out << ",";
				out << get_bid_price(j).get_decimal();out << ",";
				out << get_ask_price(j).get_decimal();out << ",";
				out << get_ask_quantity(j);out << ",";
				out << get_ask_contributors(j);out << ",";
		 }

		 out << packet_seqnum;out << ",";
		 out << packet_time_stamp;out << ",";
		 out << performance_indicator;out << ",";
		 out << trading_status;out << ",";
		 out << packet_seqnum_index;

#ifdef __TOP_OF_BOOK__
		out << ",";out << get_bid_contributors(number_of_tick_levels-1);out << ",";
		out << get_bid_quantity(number_of_tick_levels-1);out << ",";
		out << get_bid_price(number_of_tick_levels-1).get_decimal();out << ",";
		out << get_ask_price(number_of_tick_levels-1).get_decimal();out << ",";
		out << get_ask_quantity(number_of_tick_levels-1);out << ",";
		out << get_ask_contributors(number_of_tick_levels-1);
#endif

		 out << std::endl;
	}


	void write_bin(ofstream & bin_file_streamo,OrderBookLevel depth) {
			bin_file_streamo.write((char *)&receive_time,8);
			bin_file_streamo.write((char *)&series_name,SERIES_NAME_LEN);
			bin_file_streamo.write((char *)&filled_number_of_tick_levels,4);
			bin_file_streamo.write((char *)&_type,4);
			bin_file_streamo.write((char *)&_tradePrice,sizeof(_tradePrice));
			bin_file_streamo.write((char *)&_tradeQuantity,4);
			bin_file_streamo.write((char *)&_tradeSide,4);
			bin_file_streamo.write((char *)&_numBuyers,4);
			bin_file_streamo.write((char *)&_numSellers,4);
			bin_file_streamo.write((char *)&tick_size,sizeof(tick_size));
			bin_file_streamo.write((char *)&exchange_time,8);
			bin_file_streamo.write((char *)&aggressor_time,8);
			bin_file_streamo.write((char *)&is_valid,1);
			bin_file_streamo.write((char *)_bnoano,2*depth*4);
			bin_file_streamo.write((char *)_bszasz,2*depth*4);
			bin_file_streamo.write((char *)_bidask,2*depth*sizeof(tick_price_t));
	}

	void reset() {
		for (OrderBookLevel i = 0; i < 2 * number_of_tick_levels; i++) {
			_bidask[i] = 0;
			_bszasz[i] = 0;
			_bnoano[i] = 0;
		}

		_tradeQuantity = 0;
		_tradePrice = 0;
		_tradeSide = TradeSide::Unknown;
		_numBuyers = 0;
		_numSellers = 0;

		_type = NoType;

		exchange_time = 0;
		receive_time = 0;
		aggressor_time = 0;

		is_valid = true;
		packet_seqnum = 0;
		packet_time_stamp = 0;
		performance_indicator = 0;
		trading_status = '1';
		packet_seqnum_index = 0;
		//_event = NULL;
	}

	bool is_tick_valid() {
#ifdef __TOP_OF_BOOK__
		if(_bidask[0] > 0 && _bszasz[0] > 0 && _bidask[number_of_tick_levels-1] > 0 && _bszasz[number_of_tick_levels-1] > 0 && is_valid) {
#else
		if(_bidask[0] > 0 && _bszasz[0] > 0 && _bidask[number_of_tick_levels] > 0 && _bszasz[number_of_tick_levels] > 0 && is_valid) {
#endif
			return true;
		}
		else return false;
	}

	void set_validity(bool valid) {
		is_valid = valid;
	}

	int compare(md_order_book4 & ref) {
		 std::stringstream ss("");
		 int comp = 0;

		 for (OrderBookLevel j = 0; j < 1; j++) {

			if (get_bid_quantity(j) != ref.get_bid_quantity(j)) {
				if ((abs((int)(get_bid_quantity(j)-ref.get_bid_quantity(j)))) > 5) {
					comp += 3;
				}
				else {
					comp += 1;
				}

				ss << "getBidSz(" << j << ") {" << get_bid_quantity(j)
						<< "} != prev.getBidSz(" << j << ") {" << ref.get_bid_quantity(j) << "}\n";
			}

			if (get_bid_price(j) != ref.get_bid_price(j)) {
				comp += 7;
				ss << "getBid(" << j << ") {" << get_bid_price(j)
						<< "} != prev.getBid(" << j << ") {" << ref.get_bid_price(j) << "}\n";
			}

			if (get_ask_price(j) != ref.get_ask_price(j)) {
				comp += 7;
				ss << "getAsk(" << j << ") {" << get_ask_price(j)
						<< "} != prev.getAsk(" << j << ") {" << ref.get_ask_price(j) << "}\n";
			}

			if (get_ask_quantity(j) != ref.get_ask_quantity(j)) {
				if ((abs((int)(get_ask_quantity(j)-ref.get_ask_quantity(j)))) > 5) {
					comp += 3;
				}
				else {
					comp += 1;
				}

				ss << "getAskSz(" << j << ") {" << get_ask_quantity(j)
						<< "} != prev.getAskSz(" << j << ") {" << ref.get_ask_quantity(j) << "}\n";
			}
		}

		return comp;
	}

	inline void set_packet_seqnum(uint32_t ps) {
		packet_seqnum = ps;
	}

	inline void set_packet_seqnum_index(uint32_t psi) {
			packet_seqnum_index = psi;
	}

	inline void set_packet_time_stamp(micro_time_t ts) {
		packet_time_stamp = ts;
	}

	inline void set_performance_indicator(uint32_t pi) {
		performance_indicator = pi;
	}

	inline void set_size_payload(int sp) {
		size_payload = sp;
	}

	inline uint32_t get_packet_seqnum() {
		return packet_seqnum;
	}

	inline uint32_t get_packet_seqnum_index() {
		return packet_seqnum_index;
	}

	inline micro_time_t get_packet_time_stamp() {
		return packet_time_stamp;
	}

	inline uint32_t get_performance_indicator() {
		return performance_indicator;
	}

	inline int get_size_payload() {
	return size_payload;
	}

	inline const char * get_series_name() {
		return series_name;
	}

	inline tick_price_t * get_prices() {
		return _bidask;
	}

	inline OrderBookQuantity * get_quantities() {
		return _bszasz;
	}

	inline OrderBookNumber * get_contributors() {
		return _bnoano;
	}

	inline char get_trading_status() {
		return trading_status;
	}

private:
	OrderBookNumber tradeNumBuyers;
	OrderBookNumber tradeNumSellers;
	OrderBookLevel filled_number_of_tick_levels;
	series_name_t series_name;
	CntrId security_id;
	tick_price_t _bidask[2 * number_of_tick_levels];
	OrderBookQuantity _bszasz[2 * number_of_tick_levels];
	OrderBookNumber _bnoano[2 * number_of_tick_levels];

	MDType _type;

	int32_t _tradeId;

	trade_price_t _tradePrice;
	TradeQuantity _tradeQuantity;
	TradeSide _tradeSide;
	OrderBookNumber _numBuyers;
	OrderBookNumber _numSellers;

	tick_size_t tick_size;
	nano_time_t exchange_time;
	nano_time_t receive_time;
	nano_time_t aggressor_time;

	bool is_valid;

	uint32_t packet_seqnum;
	nano_time_t packet_time_stamp;
	uint32_t performance_indicator;
	int size_payload;
	char trading_status;
	uint32_t packet_seqnum_index;
};

typedef md_order_book4<5> md_order_book4_5;
typedef md_order_book4<25> md_order_book4_25;
            
#ifdef __TOP_OF_BOOK__ 
            typedef md_order_book4<6> md_order_book4_6;
            typedef md_order_book4<26> md_order_book4_26;
#endif


#endif
