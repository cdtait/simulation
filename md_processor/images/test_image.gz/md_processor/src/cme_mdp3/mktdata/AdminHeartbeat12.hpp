/* Generated SBE (Simple Binary Encoding) message codec */
#ifndef _ADMINHEARTBEAT12_HPP_
#define _ADMINHEARTBEAT12_HPP_

#if defined(SBE_HAVE_CMATH)
/* cmath needed for std::numeric_limits<double>::quiet_NaN() */
#  include <cmath>
#  define SBE_FLOAT_NAN std::numeric_limits<float>::quiet_NaN()
#  define SBE_DOUBLE_NAN std::numeric_limits<double>::quiet_NaN()
#else
/* math.h needed for NAN */
#  include <math.h>
#  define SBE_FLOAT_NAN NAN
#  define SBE_DOUBLE_NAN NAN
#endif

#include <sbe/sbe.hpp>

#include <mktdata/LegSide.hpp>
#include <mktdata/DecimalQty.hpp>
#include <mktdata/MDUpdateAction.hpp>
#include <mktdata/SecurityTradingStatus.hpp>
#include <mktdata/SecurityTradingEvent.hpp>
#include <mktdata/MatchEventIndicator.hpp>
#include <mktdata/PRICE.hpp>
#include <mktdata/MaturityMonthYear.hpp>
#include <mktdata/HaltReason.hpp>
#include <mktdata/EventType.hpp>
#include <mktdata/PRICENULL.hpp>
#include <mktdata/OpenCloseSettlFlag.hpp>
#include <mktdata/MDEntryType.hpp>
#include <mktdata/FLOAT.hpp>
#include <mktdata/SecurityUpdateAction.hpp>
#include <mktdata/PutOrCall.hpp>
#include <mktdata/GroupSize.hpp>
#include <mktdata/MDEntryTypeBook.hpp>
#include <mktdata/GroupSize8Byte.hpp>
#include <mktdata/MDEntryTypeStatistics.hpp>
#include <mktdata/InstAttribValue.hpp>
#include <mktdata/MDEntryTypeDailyStatistics.hpp>
#include <mktdata/AggressorSide.hpp>
#include <mktdata/SettlPriceType.hpp>

using namespace sbe;

namespace mktdata {

class AdminHeartbeat12
{
private:
    char *buffer_;
    int bufferLength_;
    int *positionPtr_;
    int offset_;
    int position_;
    int actingBlockLength_;
    int actingVersion_;

    AdminHeartbeat12(const AdminHeartbeat12&) {}

public:

    AdminHeartbeat12(void) : buffer_(NULL), bufferLength_(0), offset_(0) {}

    static const sbe_uint16_t sbeBlockLength(void)
    {
        return (sbe_uint16_t)0;
    }

    static const sbe_uint16_t sbeTemplateId(void)
    {
        return (sbe_uint16_t)12;
    }

    static const sbe_uint16_t sbeSchemaId(void)
    {
        return (sbe_uint16_t)1;
    }

    static const sbe_uint16_t sbeSchemaVersion(void)
    {
        return (sbe_uint16_t)5;
    }

    static const char *sbeSemanticType(void)
    {
        return "0";
    }

    sbe_uint64_t offset(void) const
    {
        return offset_;
    }

    AdminHeartbeat12 &wrapForEncode(char *buffer, const int offset, const int bufferLength)
    {
        buffer_ = buffer;
        offset_ = offset;
        bufferLength_ = bufferLength;
        actingBlockLength_ = sbeBlockLength();
        actingVersion_ = sbeSchemaVersion();
        position(offset + actingBlockLength_);
        positionPtr_ = &position_;
        return *this;
    }

    AdminHeartbeat12 &wrapForDecode(char *buffer, const int offset, const int actingBlockLength, const int actingVersion,
                         const int bufferLength)
    {
        buffer_ = buffer;
        offset_ = offset;
        bufferLength_ = bufferLength;
        actingBlockLength_ = actingBlockLength;
        actingVersion_ = actingVersion;
        positionPtr_ = &position_;
        position(offset + actingBlockLength_);
        return *this;
    }

    sbe_uint64_t position(void) const
    {
        return position_;
    }

    void position(const sbe_uint64_t position)
    {
        if (SBE_BOUNDS_CHECK_EXPECT((position > bufferLength_), 0))
        {
            throw std::runtime_error("buffer too short [E100]");
        }
        position_ = position;
    }

    int size(void) const
    {
        return position() - offset_;
    }

    char *buffer(void)
    {
        return buffer_;
    }

    int actingVersion(void) const
    {
        return actingVersion_;
    }
};
}
#endif
