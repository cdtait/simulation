#ifndef token_iterator_h
#define token_iterator_h

#include <iterator>
#include <string>
#include <vector>

/**
 * @brief Token container support class aimed at higher performance.
 *
 * Wraps up awkward iteration types for use in the parser.
 * Splits a delimited line into a vector of indices.
 * Each index holds a pointer to the place in the string where the token is found.
 * It tries to minimise iteration passes of the line in one construction and does
 * not copy the original parts of the string.
 *
 * Exposes iterator class for use with token content
 *
 *  iterator<char,char*> token_it1;
 *  iterator<char,std::vector::iterator<char*>> token_it2;
 */
template <typename T,class Iter,class A = std::allocator<T*>>
 class iterator {
 public:
	 typedef typename A::difference_type difference_type;
	 typedef typename A::value_type value_type;
	 typedef typename A::reference reference;
	 typedef typename A::pointer pointer;
	 typedef std::random_access_iterator_tag iterator_category;
	 typedef typename A::size_type size_type;
	 typedef Iter value_index_type_iter;

	 iterator () = delete;
	 iterator (const iterator&) = default;
	 ~iterator() = default;

	 explicit iterator(value_index_type_iter it) : current(it) {}

	 iterator& operator=(const iterator&) = default;

	 bool operator==(const iterator& rhs) const {
		return current == rhs.current;
	 }

	 bool operator!=(const iterator& rhs) const {
		return (current < rhs.current) ? -1 : (rhs.current < current) ? +1 : 0;
	 }

	 iterator& operator ++()
	 {
		 ++current;
		 return *this;
	 }

	 iterator operator ++(int)
	 {
		iterator  tmp(*this);
		 operator ++();
		 return tmp;
	 }

	 iterator& operator --()
	 {
		 --current;
		 return *this;
	 }

	 iterator operator --(int)
	 {
		iterator  tmp(*this);
		operator --();
		return tmp;
	 }

	 iterator& operator+=(size_type n) {
		current+=n;
		return *this;
	 }

	 iterator operator+(size_type n) const {
		return iterator(current+n);
	 }

	 iterator& operator-=(size_type n) {
		current+=n;
		return *this;
	 }

	 iterator operator-(size_type n) const {
		return iterator(current-n);
	 }

	 difference_type operator-(iterator rhs) const {
		return current-rhs.current;
	 }

	 reference operator*() const noexcept {
		return *current;
	 }

	 pointer operator->() const noexcept {
		return &(operator*());
	 }

	 reference operator[](size_type i) const {
		return current[i];
	 }

 private:
	 value_index_type_iter current;
 };

#endif
