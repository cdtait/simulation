#ifndef token_time_stream_h
#define token_time_stream_h

#include <iterator>
#include <string>
#include <vector>

/**
 * @brief Token container support class aimed at higher performance.
 *
 * Wraps up awkward iteration types for use in the parser.
 * Splits a delimited line into a vector of indices.
 * Each index holds a pointer to the place in the string where the token is found.
 * It tries to minimise iteration passes of the line in one construction and does
 * not copy the original parts of the string.
 *
 * Exposes iterator class for use with token content
 */
template <typename T,class A = std::allocator<T*>>
struct token_time_stream : public token_stream<T,A> {

	token_time_stream(const T* stream_ptr,int length) : token_stream<T,A>(stream_ptr,length)
	{
    }

	private:

};

#endif
