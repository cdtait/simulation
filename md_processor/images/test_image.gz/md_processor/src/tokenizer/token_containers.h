#ifndef token_containers_h
#define token_containers_h

#include "json_spirit/json_spirit_reader_template.h"
#include "strtk/strtk.hpp"
#include "token_iterator.h"
#include "token_vector.h"
#include "token_stream.h"
#include "token_time_stream.h"

typedef json_spirit::Array json_token_array;
typedef std::vector<std::string> string_token_vector;
typedef token_vector<char,std::vector<char*>> char_token_vector;
typedef token_stream<char> char_token_stream;
typedef token_time_stream<char> char_token_time_stream;

template <typename T>
inline typename std::enable_if<std::is_same<T, json_token_array>::value,json_token_array>::type
get_tokens(const char* stream_ptr,int length) {
	std::string line(stream_ptr,length);
	json_spirit::Value value;
	json_spirit::read_string(line, value);
	assert(value.type()==json_spirit::array_type);
	return value.get_array();
}

template <typename T>
inline typename std::enable_if<std::is_same<T, string_token_vector>::value,string_token_vector>::type
get_tokens(const char* stream_ptr,int length) {
	std::string line(stream_ptr,length);
	string_token_vector token_list;
	strtk::parse(line,",",token_list);
	return token_list;
}

template <typename T>
inline typename std::enable_if<std::is_same<T, char_token_vector>::value,char_token_vector>::type
get_tokens(const char* stream_ptr,int length) {
	std::string line(stream_ptr,length);
	char_token_vector token_list(line);
	return token_list;
}

template <typename T>
inline typename std::enable_if<std::is_same<T, char_token_stream>::value,char_token_stream>::type
get_tokens(const char* stream_ptr,int length) {
	char_token_stream token_list(stream_ptr,length);
	return token_list;
}

template <typename T>
inline typename std::enable_if<std::is_same<T, char_token_time_stream>::value,char_token_time_stream>::type
get_tokens(const char* stream_ptr,int length) {
	char_token_time_stream token_list(stream_ptr,length);
	return token_list;
}


#endif
