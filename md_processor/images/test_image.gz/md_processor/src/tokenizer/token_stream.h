#ifndef token_stream_h
#define token_stream_h

#include <iterator>
#include <string>
#include <vector>

/**
 * @brief Token container support class aimed at higher performance.
 *
 * Wraps up awkward iteration types for use in the parser.
 * Splits a delimited line into a vector of indices.
 * Each index holds a pointer to the place in the string where the token is found.
 * It tries to minimise iteration passes of the line in one construction and does
 * not copy the original parts of the string.
 *
 * Exposes iterator class for use with token content
 */
template <typename T,class A = std::allocator<T*>>
struct token_stream
{
    typedef A allocator_type;
    typedef typename A::value_type value_type;
    typedef typename A::reference reference;
    typedef typename A::const_reference const_reference;
    typedef typename A::difference_type difference_type;
    typedef typename A::size_type size_type;
    typedef typename A::const_pointer const_pointer;
    typedef typename A::pointer pointer;

    typedef T* iterator;

    typedef std::reverse_iterator<iterator> reverse_iterator;

    token_stream(const T* stream_ptr,size_type length) :
    	 stream_ptr_start(stream_ptr),
    	 stream_length(length) {
    }

    iterator begin() noexcept {
    	return iterator(stream_ptr_start);
    }

    iterator end() noexcept {
    	return iterator(stream_ptr_start+stream_length);
    }

    reverse_iterator rbegin() noexcept {
    	return reverse_iterator(stream_ptr_start+stream_length);
    }

    reverse_iterator rend() noexcept {
    	return reverse_iterator(stream_ptr_start);
    }

    reference front() noexcept {
    	return stream_ptr_start[0];
    }

    reference back() noexcept {
    	return stream_ptr_start[stream_length-1];
    }

    reference operator[](size_type i) {
    	return stream_ptr_start[i];
    }

    reference at(size_type i) {
    	return stream_ptr_start[i];
    }

	private:
    const T* stream_ptr_start;
	size_type stream_length;
};

#endif
