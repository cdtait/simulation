#ifndef basic_types_h
#define basic_types_h

#include "common/entities/entity_types.h"

#endif
