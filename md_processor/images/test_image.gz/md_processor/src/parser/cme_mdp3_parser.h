#ifndef cme_mdp3_parser_h
#define cme_mdp3_parser_h

#include <stdint.h>
#include <sys/time.h>
#include <algorithm>
#include <array>

#include <cstddef>
#include <cstdio>
#include <cstdlib>

#include <iostream>
#include <limits>
#include <string>
#include <tuple>

#include <utility>

#include "md_types.h"
#include "md_stats.h"
#include "md_helper.h"

#include "md_token_types.h"

/**
 * @brief Cme parser implements a cme mdp3 model. The source input is a token iterator of the raw stream
 *
 */
struct cme_mdp3_parser {


};

#endif
