
#ifndef FACTORY_H_
#define FACTORY_H_

#include <math.h>
#include <string>
#include <typeinfo>
#include <vector>
#include "common/entities/entity_types.h"
#include "common/logging/LoggingUtil.h"

#include "common/logging/Profiler.h"

/**
* @brief Flexible factory class offering cache,recycling and growth reaction.
*/

/**
 * Standardized object factory for any type of object. Can be configured
 * to recycle objects or grow as it fills up. Implementers need to write
 * a concrete version of the abstract {@code generate()} function, which
 * determines how each object is constructed.
 */
template <class F>
class Factory {
public:

	Factory(CapacitySize N, bool recycle = false, double growthFactor = 1.2) :
			_items(N),
			_recycle(recycle),
			_growthFactor(growthFactor),
			_currentIndex(0),
			_logger(Logger::getLogger("common.factory.Factory"))
	{
	}

	virtual ~Factory() {
		for (CapacitySize i = 0; i < _items.size(); i++) {
			delete _items[i];
		}

		_items.clear();
	}

	virtual void reset() {
		_currentIndex = 0;
	}

	virtual void reset(F * item) {
		item->reset();
	}

	inline virtual F * create() {
		//PROFILE_SCOPED();
		if (_currentIndex >= _items.size()) {
			if (_recycle) {
				_currentIndex = 0;
			}
			else {
				std::size_t oldSize = _items.size();
				std::size_t newSize = (std::size_t) ceil(oldSize * _growthFactor);
				LOG_WARN(_logger, "Buffer resize occurred! (" << oldSize << " -> " << newSize << ") [" << typeid(F).name() << "]");
				_items.resize(newSize);
				for(std::size_t i=oldSize; i<_items.size(); i++) {
					_items[i] = generate();
				}
			}
		}

		F * item = _items.at(_currentIndex++);
		if(_recycle) {
			reset(item);
		}

		return item;
	}

	virtual void initialize() {
		LOG_INFO(_logger, "Creating " << (_recycle ? "[recycle]" : "[fixed]") << " buffer of size " << _items.size() << " [" << typeid(F).name() << "]");
		for(std::size_t i=0; i<_items.size(); i++) {
			_items[i] = generate();
		}
	}

protected:
	virtual F * generate() = 0;

	std::vector<F *> _items;
	bool _recycle;
	double _growthFactor;
	CapacitySize _currentIndex;
	LoggerPtr _logger;
};

#endif /*FACTORY_H_*/
