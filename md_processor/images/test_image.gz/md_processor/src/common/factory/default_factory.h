#ifndef DEFAULTFACTORY_H_
#define DEFAULTFACTORY_H_

#include "factory.h"

/**
* @brief Template factory to define defaults for recycle and growth.
*/
/**
 * @brief Default version of the {@code Factory} class that
 * generates objects on the heap via their default constructor.
 */
template <class F>
class default_factory : public Factory<F> {
public:

	default_factory(CapacitySize N, bool recycle = false, double growthFactor = 1.2) :
	Factory<F>(N, recycle, growthFactor) { }

	virtual ~default_factory() { }

protected:

	virtual F * generate() {
		return new F();
	}
};


#endif /*DEFAULTFACTORY_H_*/
