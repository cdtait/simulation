#include <sstream>
#include <streambuf>

#include "event.h"


std::ostream& operator<< (std::ostream &out, event &e) {
    return e.toStream(out);
}

std::ostream& event::toStream(std::ostream &out) {
    return ptime::toStream(out);
}

std::string event::object2String() {
    return "";
}

void  event::string2Object(boost::tokenizer<boost::char_separator<char> >::iterator & it) {
}

std::string event::debugString() {
	return std::string("");
}

