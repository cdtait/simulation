#ifndef EVENT_H_
#define EVENT_H_

#include <iostream>
#include <time.h>
#include <sys/time.h>
#include <inttypes.h>
#include <string>
#include <boost/tokenizer.hpp>
#include <sstream>

#include "common/primitives/ptime.h"

/**
 * @brief Generic event class.
 */
class event : public ptime {
public:

	enum JournalType {
		Unknown=0, ExecutionType = 1, QuoteType = 2, CancelQuoteType = 3, OrderAckType = 4,
		OrderNackType = 5, OrderCancelAckType = 6, OrderCancelNackType = 7
	};


	enum EventType {
		MarketDataEventType, SignalEventType, BrokerEventType, TraderEventType, ExchangeEventType
	};

	event() { }

	event(EventType type) : _type(type), _journalType(Unknown) { }

	virtual ~event() { }

	EventType getType() {
		return _type;
	}

	void setType(EventType type) {
		_type = type;
	}

	JournalType getJournalType() {
		return _journalType;
	}

	void setJournalType(JournalType type) {
		_journalType = type;
	}

	friend std::ostream & operator<<(std::ostream &out, event &e);

	virtual std::string object2String();
	virtual void string2Object(boost::tokenizer<boost::char_separator<char> >::iterator & it);
	virtual std::string debugString();

private:
	std::ostream& toStream(std::ostream &out);
	EventType _type;
	JournalType _journalType;
};

#endif /* EVENT_H_ */
