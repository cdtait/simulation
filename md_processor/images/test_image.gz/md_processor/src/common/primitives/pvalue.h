#include <assert.h>
#include <iostream>
#include <sstream>
#include <stdint.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>

#include "putils.h"

#ifndef PVALUE_H_
#define PVALUE_H_

#include "pdata.h"

using std::ostream;

/**
 * @brief Template value type.
 */
template <class value_type>
class pvalue : public pdata {
  public:
    // Note: This is typedefed publicly for easy reference in other classes:
    typedef value_type type;

  public:
    type _value;

    pvalue() {
      // nothing to do!
    }

  public:
    /*
    virtual ~pvalue() {
      // nothing to do!
    }
    */

    /**
     * @return the value of this pvalue or 0 if this pvalue is null.
     */
    virtual type get_value() {
      return _null ? 0 : _value;
    }

    /**
     * Sets the internal value to the argument value.  After this method
     * has been called this pvalue is no longer null.
     *
     * @param value the value to set this pvalue to.
     */
    virtual void set_value(const type & value) {
      _null = false;
      _value = value;
    }


    /**
     * Sets the internal state of this pvalue to null.
     */
    virtual void reset() {
      _null = true;
    }


    virtual ostream & insert(ostream & out) const {
      out << "[null=" << (_null ? "true" : "false") << ",value=" << _value << "]";
      return out;
    }

  protected:

    pvalue(const pvalue & other) { 
        //assert(0); 
        // std::cout << "Copying pvalue: ";
       //insert(std::cout);
    }
};

#endif /*PVALUE_H_*/
