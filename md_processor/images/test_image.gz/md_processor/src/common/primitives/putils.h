#ifndef _PUTILS_H_
#define _PUTILS_H_

#include <sstream>
#include <cassert>
#include <iostream>
#include <cstdlib>
#include <string.h>
#include <string>
#include <cstring>
#include <math.h>
#include <algorithm>
#include <stdint.h>
#include <stdio.h>

using std::stringstream;
using std::string;

/**
 * @brief This class provides basic functions to various internal classes.
 */
class putils {
public:
	//Symbols used to display a number correctly
	//Numbers over base 10 use letters to represent values over and equal to 10
	//You should be able to increase the max no. of bases by adding other symbols
	//Remember a string needs 1 extra space for null character
	static const char basesymbols[37];
	static const int MAX_BASE = 36; //Highest base allowed (make sure there are enough symbols first!)
        
	/**
	 * @return a string equal to the argument input type.
	 */
	template<typename type>
	static string  to_string(const type & input) {
                static stringstream ss;
                ss.str("");
		ss << input;

		return ss.str();
	}

	/**
	 * @return a zero string of length equal to the argument count.
	 */
	template<typename type>
	static string zeros(const type & count) {
		char buffer[50];
		assert (count < 50);
		sprintf(buffer, ("%0" + to_string(count) + "d").c_str(), 0);
		return buffer;
	}

	template<typename type>
	static std::string to_hex(const type & data, uint32_t size) {
		std::stringstream hex;

		for (uint32_t i = 0; i < size; ++i) {
			char h[2];
			sprintf(h, "%02X ", data[i]);
			hex << h;
		}

		hex << "\n\n";

		return hex.str();
	}

	/**
	 * @return a hex string for the argument input.
	 */
	template<typename type>
	static string to_single_hex(const type & input) {
		char buffer[20];
		sprintf(buffer, "%x", input);
		return string(buffer);
	}

	/**
	 * Convert long values to fit into 32 bits of data
	 *
	 * @param value the long value
	 * @return 32 bit representation of the value inside a 64 bit field.
	 */
	static int64_t convertLongUInt(const int64_t & value) {
		const uint64_t unsigned_value = value << 32;
		return unsigned_value >> 32;
	}

	//Takes a decimal number, converts it to base and stores the result in szString. Returns 1 on success or 0 on failure
	static std::string dec2base(int base, long iDec) {
		char number[256] = "";

		//Check base is between 2 and 36
		if (base < 2 || base > MAX_BASE)
			return 0; //Failed
		//If input is 0, output is 0
		if (iDec == 0) {
			strcpy(number, "0");
			return std::string(number);;
		}

		int count = 0;
		char chResult[256] = "";
		char* pChResult = chResult;
		while (iDec > 0 && count++ < 256) {
			*pChResult = basesymbols[iDec % base];
			pChResult++;
			iDec = iDec / base; //iDec = itself divided by base
		}

		std::string n(chResult);
		reverse(n.begin(),n.end());

		return n;
	}

	static int base2dec(char* number, int base) {
		if (base < 2 || base > MAX_BASE)
			return 0; //Failed

		int NumLength = strlen(number);
		int PlaceValue, total = 0;
		//Work out the place value of the first digit (base^length-1)
		PlaceValue = (int) ::pow(base, NumLength - 1);

		//For each digit, multiply by its place value and add to total
		for (int i = 0; i < NumLength; i++) {
			total += getindex(basesymbols, *number) * PlaceValue;
			number++;
			PlaceValue /= base; //Next digit's place value (previous/base)
		}
		return total;
	}

	//Finds the index of a particular character (if it exists) in an array. Returns last character on failure
	//Used by BaseToDec to find face values
	static int getindex(const char * pString, char search) {
		int index = 0;
		while (*pString != (char) 0) //Loop will finish at null character if no match is found
		{
			if (*pString == search)
				break;
			pString++;
			index++;
		}
		return index;
	}

private:
	putils() {
	}
	virtual ~putils() {
	}
};

#endif /*_PUTILS_H_*/

