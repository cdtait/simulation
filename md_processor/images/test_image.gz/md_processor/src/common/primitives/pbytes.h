#include <iostream>

#ifndef PBYTES_H_
#define PBYTES_H_

#include "pvalue.h"
#include "ptime.h"
#include "common/logging/profiler.h"
using std::ostream;
using std::cout;
using std::endl;

#define STACK_CAPACITY 100

/**
* @brief Byte stream as sequence of uint8 with time stamp on creation.
*/
class pbytes : public pvalue<uint8_t *>, public ptime {
public:
	typedef uint8_t byte;
	bool use_stop;
	byte _stack_bytes[STACK_CAPACITY];
	byte * _value_bytes;
private:
	unsigned int _capacity;

	void clear() {
		if (_value_bytes != 0 && _capacity > STACK_CAPACITY) {
			delete [] _value_bytes;
			_value_bytes = 0;
		}
		_value = 0;
		_length = -1;
		_capacity = 0;
		_null = true;
		use_stop = true;
	}

public:

	pbytes(const int capacity) : _value_bytes(0), _capacity(0) {
		_value = 0;

		if (capacity > STACK_CAPACITY) {
			clear();
			_value_bytes = new byte[capacity];
			set_value(_value_bytes, capacity);
		}
		else {
			clear();
			_value_bytes = 0;
			set_value(_stack_bytes, capacity);
		}

		memset(_value, '\0', capacity);

		_length = 0;
		_capacity = capacity;
		use_stop = true;
	}

	pbytes(const pbytes & copy) : _value_bytes(0), _capacity(0) {
		clear();

		_value = 0;
		_length = copy._length;
		_capacity = copy._capacity;

		if (_capacity > STACK_CAPACITY) {
			_value_bytes = new byte[_capacity];
			set_value(_value_bytes, _capacity);
		}
		else {
			_value_bytes = 0;
			set_value(_stack_bytes, _capacity);
		}

		for (int i = 0; i < _length; ++i) {
			_value[i] = copy._value[i];
		}
		use_stop = copy.use_stop;
	}

	pbytes(byte value[], int length, unsigned int capacity)  : _value_bytes(0), _capacity(0) {
		clear();
		_value = 0;
		_value_bytes=new byte[length];
		set_value(_value_bytes, _capacity);
		_length = length;
		for (int i = 0; i < _length; ++i) {
			_value[i] = value[i];
		}

		use_stop = true;
	}

	virtual ~pbytes() {
		clear();
	}

	inline virtual byte * get_value() const {
		// this forces users to set the length after setting the value.
		assert(_value == 0 || _length != -1);
		return _value;
	}

	/**
	 * @return the byte indexed by the argument.
	 */
	inline byte get_byte(const int index) const {
		assert(index < _length && index >= 0);
		return _value[index];
	}

	/**
	 * @return true if the argument byte is a stop byte.
	 */
	inline bool set_byte(const int index, const byte & value) {
		//PROFILE_SCOPED();
		assert(index < (int) _capacity);
		bool stop = use_stop && (value >= 0x80);
		_value[index] = (stop ? value & 0x7F : value);
		if (stop) _length = index + 1;
		return stop;
	}

	inline unsigned int get_capacity() {
		return _capacity;
	}

	/**
	  * Shift the value pointer in order to move to data
	  * points in the stream. An example is to manage
	  * pre-amble messages in a FAST stream and skip these
	  */
	 inline virtual void shift(int shift_amount) {
			 _value += shift_amount;
			 _length -= shift_amount;
	 }

private:
	/**
	 * Set the value, dangerous to use outside this class so its private array.
	 */
	inline virtual void set_value(byte value[], unsigned int capacity) {
		_null = value == 0;
		_value = value;
		_capacity = capacity;
	}
};

ostream & operator <<(ostream & out, const pbytes & bytes);

#endif /*PBYTES_H_*/
