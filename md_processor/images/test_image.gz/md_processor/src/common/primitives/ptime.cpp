#include "ptime.h"
#include <sstream>
#include <iostream>


#define ONE_SEC_IN_USECS 1000000

ptime::ptime(const ptime & p) {
	time_stamp.tv_sec = p.time_stamp.tv_sec;
	time_stamp.tv_usec = p.time_stamp.tv_usec;
}

ptime::ptime(const struct timeval & timeOfEvent) {
	time_stamp.tv_sec = timeOfEvent.tv_sec;
	time_stamp.tv_usec = timeOfEvent.tv_usec;
}

std::ostream & operator <<(std::ostream & out, const ptime & p) {
	out << p.micro_time();
	return out;
}

std::ostream & ptime::toStream(std::ostream &out) {
	out << micro_time();
	return out;
}

std::string ptime::readable() {
	  time_t rawtime = time_stamp.tv_sec;
	  struct tm * timeinfo;
	  char buffer [80];

	  timeinfo = gmtime ( &rawtime );

	  strftime (buffer,80,"GMT %x %X.",timeinfo);

	  std::stringstream ss;
	  ss <<  std::string(buffer) << time_stamp.tv_usec;

	  return ss.str();
 }

ptime operator +(ptime & time, const uint32_t& microsecs) {
	timeval tv = time.timeval_time();

	tv.tv_sec += microsecs / ONE_SEC_IN_USECS;
	tv.tv_usec += microsecs % ONE_SEC_IN_USECS;

	if (tv.tv_usec > ONE_SEC_IN_USECS) {
		tv.tv_usec -= ONE_SEC_IN_USECS;
		tv.tv_sec++;
	}

	return ptime(tv);
}

bool operator>(const timeval & tv, ptime& pt) {
	const timeval& pt_tv = pt.timeval_time();
	if (tv.tv_sec > pt_tv.tv_sec) {
		return true;
	}
	if (tv.tv_sec == pt_tv.tv_sec) {
		return tv.tv_usec > pt_tv.tv_usec;
	} else {
		return false;
	}
}

bool operator<(const timeval & tv, ptime& pt) {
	const timeval& pt_tv = pt.timeval_time();
	if (tv.tv_sec < pt_tv.tv_sec) {
		return true;
	}
	if (tv.tv_sec == pt_tv.tv_sec) {
		return tv.tv_usec < pt_tv.tv_usec;
	} else {
		return false;
	}
}

