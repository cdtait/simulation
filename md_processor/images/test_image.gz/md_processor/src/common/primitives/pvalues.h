#include <stdint.h>
#include <cstring>
#include <cstdlib>

#ifndef PVALUES_H_
#define PVALUES_H_

#include "pvalue.h"
#include "pbytes.h"
#include "pdecimal.h"
typedef int ID;

/**
 * @brief This struct is defined so that all integer-based CValues are initialized to
 * zero upon creation.
 */
template <typename int_type>
struct pintvalue : public pvalue<int_type> {
	pintvalue() {
	pvalue<int_type>::_value = 0;
  }

  virtual void reset() {
	pvalue<int_type>::_value = 0;
	pvalue<int_type>::_null = true;
  }
};


#include <sstream>

/**
 * @brief This struct represents a signed 32-bit integer value.
 */
struct pint32 : public pintvalue<int32_t> {
  static int32_t parse(const string & value) {
    //cout << "static int32_t parse(const string & value)" << endl;
    return atoi(value.c_str());
  }
};


/**
 * @brief This struct represents a signed 64-bit integer value.
 */
struct pint64 : public pintvalue<int64_t> {
  static int64_t parse(const string & value) {
    //cout << "static int64_t parse(const string & value)" << endl;
    return strtoll(value.c_str(), NULL, 0);
  }
};


/**
 * @brief This struct represents an unsigned 32-bit integer value.
 */
struct puint32 : public pintvalue<uint32_t> {
  static uint32_t parse(const string & value) {
    //cout << "static uint32_t parse(const string & value)" << endl;
    return strtoul(value.c_str(), NULL, 0);
  }
};


/**
 * @brief This struct represents an unsigned 64-bit integer value.
 */
struct puint64 : public pintvalue<uint64_t> {
  static uint64_t parse(const string & value) {
    //cout << "static uint64_t parse(const string & value)" << endl;
    return strtoull(value.c_str(), NULL, 0);
  }
};


/**
 * This struct represents a string value.
 */

/*
struct pstring : public pvalue<std::string> {
  string EMPTY;

  virtual std::string get_value() {
    return _null ? EMPTY : _value;
  }
};
*/

/**
 * @brief This struct represents a string underlying type stl string.
 */
struct pstring : public pdata {

public:
  typedef string type;
private:
  string _value;
public:
  virtual const char * get_value() const {
    return _null ? "" : _value.c_str();
  }

    pstring() : pdata(), _value() {
    }

    virtual ~pstring() {
    }

    /**
     * Sets the internal value to the argument value.  After this method
     * has been called this pvalue is no longer null.
     *
     * @param value the value to set this pvalue to.
     */
    virtual void set_value(const char * value) {
      _null = false;
      _value = value;
    }

      /**
     * Sets the internal value to the argument value.  After this method
     * has been called this pvalue is no longer null.
     *
     * @param value the value to set this pvalue to.
     */
    inline virtual void set_value(int index, char value) {
        if (index==0) {
            _value="";
        }
        _value.append(1,value);
    }

    /**
     * Sets the internal state of this pvalue to null.
     */
    virtual void reset() {
      _null = true;
    }

    virtual ostream & insert(ostream & out) const {
      out << "[null=" << (_null ? "true" : "false") << ",value='" << _value.c_str() << "']";
      return out;
    }

};

/**
 * @brief This struct represents a string underlying type fixed length simple string.
 */
template <int len>
struct pstring2 : public pdata {

public:
  typedef string type;
private:
  char _svalue[len+1];
public:
  virtual const char * get_value() const {
    return _null ? "" : _svalue;
  }

    pstring2() : pdata() {
        _svalue[len]='\0';
    }

    virtual ~pstring2() {
    }

    /**
     * Sets the internal value to the argument value.  After this method
     * has been called this pvalue is no longer null.
     *
     * @param value the value to set this pvalue to.
     */
    inline virtual void set_value(const char * value) {
      _null = false;
      strncpy(_svalue,value,len);
    }

    /**
     * Sets the internal value to the argument value.  After this method
     * has been called this pvalue is no longer null.
     *
     * @param value the value to set this pvalue to.
     */
    inline virtual void set_value(int index, char value) {
        if (index < len) {
            _svalue[index] = value;
        }
    }

    /**
     * Sets the internal state of this pvalue to null.
     */
    virtual void reset() {
      _null = true;
    }


    virtual ostream & insert(ostream & out) const {
      out << "[null=" << (_null ? "true" : "false") << ",value='" << _svalue << "']";
      return out;
    }

};

ostream & operator << (ostream & out, const pint32 & value);
ostream & operator << (ostream & out, const puint32 & value);
ostream & operator << (ostream & out, const pint64 & value);
ostream & operator << (ostream & out, const puint64 & value);
ostream & operator << (ostream & out, const pstring & value);
template <int len>
ostream & operator << (ostream & out, const pstring2<len> & value)
{
  return value.insert(out);
}

#endif /*PVALUES_H_*/
