#include "putils.h"


const char putils::basesymbols[37] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

