#include <sstream>

#ifndef decimal_type_h_
#define decimal_type_h_

#include "pvalue.h"

using std::string;

#include <boost/lexical_cast.hpp>
using boost::lexical_cast;

typedef int64_t mType;
typedef int32_t eType;

struct dec_t {
    mType _mantissa;
    eType _exponent;
    
    dec_t(mType mantissa=0,eType exponent=0) {
        _mantissa = mantissa;
        _exponent = exponent;
    }
};

class decimal_type : public pvalue<dec_t> {
   
  public:
    static decimal_type Zero;
    static decimal_type Half;
              
    decimal_type() ;
       
    decimal_type(const decimal_type & cop) ;
    
    decimal_type(const dec_t & value) ;
    
    explicit
    decimal_type(mType mantissa,eType exponent) ;
        
    explicit
    decimal_type(double d) ;
    
    
   // virtual ~decimal_type() ;
        
    decimal_type & operator =(double d) ;
    
    virtual ostream & insert(ostream & out) const;
        
    void set_decimal(double d,int precision);

    inline decimal_type & operator =(mType d) {
        set_mantissa(d);
        set_exponent(0);
        return *this;
    }

    inline decimal_type & operator =(int d) {
        set_mantissa(d);
        set_exponent(0);
        return *this;
    }
    
    inline eType get_exponent() const {
        return _value._exponent;
    }

    inline void set_exponent(const eType & exponent) {
        _null = false;
        _value._exponent = exponent;
    }

    inline mType get_mantissa() const {
        return _value._mantissa;
    }

    inline void set_mantissa(const mType & mantissa) {
        _null = false;
        _value._mantissa = mantissa;
    }

    inline void set_value(const dec_t & value) {
        _value._mantissa = value._mantissa;
        _value._exponent = value._exponent;
    }

    inline dec_t get_value() {
        return _value;
    }
    
    inline decimal_type & operator =(const decimal_type & copy) {
        _value._mantissa = copy._value._mantissa;
        _value._exponent = copy._value._exponent;
        return *this;
    }
        
    inline bool operator !=(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent || d._value._mantissa == 0 || _value._mantissa == 0) {
            return _value._mantissa != d._value._mantissa;
        } else {
            return (double) * this != (double) const_cast<decimal_type&> (d);
        }
    }

    inline bool operator ==(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent || d._value._mantissa == 0 || _value._mantissa == 0) {
            return _value._mantissa == d._value._mantissa;
        } else {
            return (double) * this == (double) const_cast<decimal_type&> (d);
        }
    }

    inline bool operator>(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent || d._value._mantissa == 0 || _value._mantissa == 0) {
            return _value._mantissa > d._value._mantissa;
        } else {
            return (double) * this > (double) const_cast<decimal_type&> (d);
        }
    }

    inline bool operator<(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent || d._value._mantissa == 0 || _value._mantissa == 0) {
            return _value._mantissa < d._value._mantissa;
        } else {
            return (double) * this < (double) const_cast<decimal_type&> (d);
        }
    }
    
    inline decimal_type operator +(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent) {
            // ar = _value._mantissa;
            // br = d._value._mantissa;
            // wr = ar + br;
            // assert((br >= 0) ? wr < ar : wr > ar);
            return decimal_type(_value._mantissa + d._value._mantissa, d.get_exponent());
        } else {
            int de = d.get_exponent() - _value._exponent;

            if (de < 0) {
                return decimal_type((_value._mantissa * ::pow(10, -de)) + d._value._mantissa, d._value._exponent);
            } else {
                return decimal_type(_value._mantissa + (d._value._mantissa * ::pow(10, de)), _value._exponent);
            }
        }
    }
    
    inline decimal_type operator -(const decimal_type & d) {
        if (d.get_exponent() == _value._exponent) {
                // ar = _value._mantissa;
                // br = d._value._mantissa;
                // wr = ar - br;
                // assert((br >= 0) ? wr > ar : wr < ar);
                return decimal_type(_value._mantissa - d._value._mantissa, d.get_exponent());
            } else {
                int de = d.get_exponent() - _value._exponent;

                if (de < 0) {
                    return decimal_type((_value._mantissa * ::pow(10, -de)) - d._value._mantissa, d._value._exponent);
                } else {
                    return decimal_type(_value._mantissa - (d._value._mantissa * ::pow(10, de)), _value._exponent);
                }
            }
    }

    inline decimal_type operator *(const decimal_type & b) {
        //return decimal_type(_value._mantissa * d._value._mantissa, _value._exponent + d._value._exponent);
        double im =_value._mantissa*(double)b._value._mantissa;
        double v=fabs(im);
        eType ie = (_value._exponent+b._value._exponent);
        mType rm=100000000000000000;
        eType rd=-17;
        
        if (v < 10) {rd=-16;rm=10000000000000000;} else
        if (v < 100) {rd=-15;rm=1000000000000000;} else
        if (v < 1000) {rd=-14;rm=100000000000000;} else
        if (v < 10000) {rd=-13;rm=10000000000000;} else
        if (v < 100000) {rd=-12;rm=1000000000000;} else
        if (v < 1000000) {rd=-11;rm=100000000000;} else
        if (v < 10000000) {rd=-10;rm=10000000000;} else
        if (v < 100000000) {rd=-9;rm=1000000000;} else
        if (v < 1000000000) {rd=-8;rm=100000000;} else
        if (v < 10000000000) {rd=-7;rm=10000000;} else
        if (v < 100000000000) {rd=-6;rm=1000000;} else
        if (v < 1000000000000) {rd=-5;rm=100000;} else
        if (v < 10000000000000) {rd=-4;rm=10000;} else
        if (v < 100000000000000) {rd=-3;rm=1000;} else
        if (v < 1000000000000000) {rd=-2;rm=100;} else
        if (v < 10000000000000000) {rd=-1;rm=10;} else
        if (v < 100000000000000000) {rd=0;rm=1;}

        mType mantissa=im*rm;
        eType exponent=ie+rd;
        
        return decimal_type(mantissa,exponent);
    }

    inline decimal_type operator /(const decimal_type & b) {
        //return decimal_type((double) (*this) / (double) d);
        
        double im=_value._mantissa/(double)b._value._mantissa;
        double v=::fabs(im);
        eType ie = (_value._exponent-b._value._exponent);
        mType rm=100000000000000000;
        eType rd=-17;
        
        if (v < 10) {rd=-16;rm=10000000000000000;} else
        if (v < 100) {rd=-15;rm=1000000000000000;} else
        if (v < 1000) {rd=-14;rm=100000000000000;} else
        if (v < 10000) {rd=-13;rm=10000000000000;} else
        if (v < 100000) {rd=-12;rm=1000000000000;} else
        if (v < 1000000) {rd=-11;rm=100000000000;} else
        if (v < 10000000) {rd=-10;rm=10000000000;} else
        if (v < 100000000) {rd=-9;rm=1000000000;} else
        if (v < 1000000000) {rd=-8;rm=100000000;} else
        if (v < 10000000000) {rd=-7;rm=10000000;} else
        if (v < 100000000000) {rd=-6;rm=1000000;} else
        if (v < 1000000000000) {rd=-5;rm=100000;} else
        if (v < 10000000000000) {rd=-4;rm=10000;} else
        if (v < 100000000000000) {rd=-3;rm=1000;} else
        if (v < 1000000000000000) {rd=-2;rm=100;} else
        if (v < 10000000000000000) {rd=-1;rm=10;} else
        if (v < 100000000000000000) {rd=0;rm=1;}

        mType mantissa=im*rm;
        eType exponent=ie+rd;
        
        return decimal_type(mantissa,exponent);
    }
    
    inline string get_decimal() const {
        stringstream ss;
        ss.str("");

        string out = putils::to_string(::llabs(_value._mantissa));

        string sign = "";
        if (_value._mantissa < 0) {
            sign = "-";
        }
        const int index = out.length() + _value._exponent;
        ss.str("");

        if (index == (int) out.length()) {
            ss << sign << out;
        } else
            if (index >= (int) out.length()) {
            ss << sign << out << putils::zeros(_value._exponent);
        } else
            if (index == 0) {
            out.insert(0, "0.");
            ss << sign << out;
        } else
            if (index > 0) {
            out.insert(index, ".");
            ss << sign << out;
        } else {
            ss << sign << "0." << putils::zeros(0 - index) << out;
        }

        return ss.str();
    }
    
    inline void set_decimal(const string & v) {
        //PROFILE_SCOPED();
 
        const string::size_type dot_pos = v.find_first_of('.');
        const string::size_type sign_pos = v.find_first_of('-');

        int lpff = 0;
        int sign = 1;

        if (sign_pos != string::npos) {
            lpff = sign_pos+1;
            sign = -1;
        }

        int vl = v.length();

        // No dot
        if (dot_pos == string::npos) {
             _value._exponent = 0;
             while (v.data()[lpff++] == '0');
             char * n = const_cast<char *>(v.data());
             _value._mantissa = sign * strtoll(n+lpff-1,NULL, 0);
        }
        // Found dot
        else {
             string & ev = const_cast<string &>(v).erase(dot_pos, 1);
             while (ev.data()[lpff++] == '0');
             char * n = const_cast<char *>(ev.data());
            _value._mantissa = sign * strtoll(n+lpff-1,NULL, 0);
            _value._exponent = 1 - (vl - dot_pos);
        }
    }
    
    inline operator double () const {
        return (_value._mantissa * pow(10.0, _value._exponent));
    }
};

#endif

