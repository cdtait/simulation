#include <sstream>
#include "pdecimal.h"
#include "pvalues.h"

#include <math.h>

using namespace std;
    
decimal_type decimal_type::Zero;
decimal_type decimal_type::Half(5,-1);

decimal_type::decimal_type() {
    set_mantissa(0);
    set_exponent(0);
}

decimal_type::decimal_type(double d) {
    set_decimal(d,10);
}

decimal_type::decimal_type(mType mantissa, eType exponent) {
    set_mantissa(mantissa);
    set_exponent(exponent);
}

decimal_type::decimal_type(const dec_t & value) {
    set_value(value);
}

decimal_type::decimal_type(const decimal_type & copy) {
    _value._mantissa = copy._value._mantissa;
    _value._exponent = copy._value._exponent;
}

decimal_type & decimal_type::operator =(double d) {
    set_decimal(d,10);
    return *this;
}
/*
decimal_type::~decimal_type() {
}
*/
ostream & decimal_type::insert(ostream & out) const {
    out << "pdecimal[exponent=" << _value._exponent << ",mantissa=" << _value._mantissa << "]";
    return out;
}
void decimal_type::set_decimal(double d,int precision) {
    char buff[30];
    sprintf(buff,"%.*f",precision,d);
    set_decimal(buff);
}

ostream & operator <<(ostream & out, const decimal_type & decimal) {
    out << decimal.get_decimal();
    return out;
}

