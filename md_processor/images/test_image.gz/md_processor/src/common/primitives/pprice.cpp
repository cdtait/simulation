#include <sstream>
#include "pprice.h"
#include "pvalues.h"

#include <math.h>

using namespace std;

namespace ausus { namespace common { namespace primitives {
    
//pprice ausus::common::primitives::Zero;
//pprice ausus::common::primitives::Half(5,-1);

pprice::pprice() {
    set_mantissa(0);
    set_exponent(0);
}

pprice::pprice(double d) {
    set_decimal(d,10);
}

pprice::pprice(mPType mantissa, ePType exponent) {
    set_mantissa(mantissa);
    set_exponent(exponent);
}

pprice::pprice(const pprice & copy) {
    _mantissa = copy._mantissa;
    _exponent = copy._exponent;
}

pprice & pprice::operator =(double d) {
    set_decimal(d,10);
    return *this;
}

pprice::~pprice() {
}

ostream & pprice::insert(ostream & out) const {
    out << "pdecimal[exponent=" << _exponent << ",mantissa=" << _mantissa << "]";
    return out;
}
void pprice::set_decimal(double d,int precision) {
    char buff[30];
    sprintf(buff,"%.*f",precision,d);
    set_decimal(buff);
}

ostream & operator <<(ostream & out, const pprice & decimal) {
    out << decimal.get_decimal();
    return out;
}

}}}
