#include <sstream>

#ifndef pprice_h_
#define pprice_h_

#include "pvalue.h"

using std::string;

#include <boost/lexical_cast.hpp>
using boost::lexical_cast;

namespace ausus { namespace common { namespace primitives {

typedef int64_t mPType;
typedef int32_t ePType;

class pprice {
private:
    mPType _mantissa;
    ePType _exponent;
    
  public:
              
    pprice() ;
       
    pprice(const pprice & cop) ;
    
    explicit
    pprice(mPType mantissa,ePType exponent) ;
        
    explicit
    pprice(double d) ;
    
    virtual ~pprice() ;
        
    pprice & operator =(double d) ;
    
    virtual ostream & insert(ostream & out) const;
        
    void set_decimal(double d,int precision);

    inline pprice & operator =(mPType d) {
        set_mantissa(d);
        set_exponent(0);
        return *this;
    }

    inline pprice & operator =(int d) {
        set_mantissa(d);
        set_exponent(0);
        return *this;
    }
    
    inline ePType get_exponent() const {
        return _exponent;
    }

    inline void set_exponent(const ePType & exponent) {
        _exponent = exponent;
    }

    inline mPType get_mantissa() const {
        return _mantissa;
    }

    inline void set_mantissa(const mPType & mantissa) {
        _mantissa = mantissa;
    }
    
    inline pprice & operator =(const pprice & copy) {
        _mantissa = copy._mantissa;
        _exponent = copy._exponent;
        return *this;
    }
        
    inline bool operator !=(const pprice & d) {
        if (d.get_exponent() == _exponent || d._mantissa == 0 || _mantissa == 0) {
            return _mantissa != d._mantissa;
        } else {
            return (double) * this != (double) const_cast<pprice&> (d);
        }
    }

    inline bool operator ==(const pprice & d) {
        if (d.get_exponent() == _exponent || d._mantissa == 0 || _mantissa == 0) {
            return _mantissa == d._mantissa;
        } else {
            return (double) * this == (double) const_cast<pprice&> (d);
        }
    }

    inline bool operator>(const pprice & d) {
        if (d.get_exponent() == _exponent || d._mantissa == 0 || _mantissa == 0) {
            return _mantissa > d._mantissa;
        } else {
            return (double) * this > (double) const_cast<pprice&> (d);
        }
    }

    inline bool operator<(const pprice & d) {
        if (d.get_exponent() == _exponent || d._mantissa == 0 || _mantissa == 0) {
            return _mantissa < d._mantissa;
        } else {
            return (double) * this < (double) const_cast<pprice&> (d);
        }
    }
    
    inline pprice operator +(const pprice & d) {
        if (d.get_exponent() == _exponent) {
            // ar = _mantissa;
            // br = d._mantissa;
            // wr = ar + br;
            // assert((br >= 0) ? wr < ar : wr > ar);
            return pprice(_mantissa + d._mantissa, d.get_exponent());
        } else {
            int de = d.get_exponent() - _exponent;

            if (de < 0) {
                return pprice((_mantissa * ::pow(10, -de)) + d._mantissa, d._exponent);
            } else {
                return pprice(_mantissa + (d._mantissa * ::pow(10, de)), _exponent);
            }
        }
    }
    
    inline pprice operator -(const pprice & d) {
        if (d.get_exponent() == _exponent) {
                // ar = _mantissa;
                // br = d._mantissa;
                // wr = ar - br;
                // assert((br >= 0) ? wr > ar : wr < ar);
                return pprice(_mantissa - d._mantissa, d.get_exponent());
            } else {
                int de = d.get_exponent() - _exponent;

                if (de < 0) {
                    return pprice((_mantissa * ::pow(10, -de)) - d._mantissa, d._exponent);
                } else {
                    return pprice(_mantissa - (d._mantissa * ::pow(10, de)), _exponent);
                }
            }
    }

    inline pprice operator *(const pprice & b) {
        //return pprice(_mantissa * d._mantissa, _exponent + d._exponent);
        double im =_mantissa*(double)b._mantissa;
        double v=fabs(im);
        ePType ie = (_exponent+b._exponent);
        mPType rm=100000000000000000;
        ePType rd=-17;
        
        if (v < 10) {rd=-16;rm=10000000000000000;} else
        if (v < 100) {rd=-15;rm=1000000000000000;} else
        if (v < 1000) {rd=-14;rm=100000000000000;} else
        if (v < 10000) {rd=-13;rm=10000000000000;} else
        if (v < 100000) {rd=-12;rm=1000000000000;} else
        if (v < 1000000) {rd=-11;rm=100000000000;} else
        if (v < 10000000) {rd=-10;rm=10000000000;} else
        if (v < 100000000) {rd=-9;rm=1000000000;} else
        if (v < 1000000000) {rd=-8;rm=100000000;} else
        if (v < 10000000000) {rd=-7;rm=10000000;} else
        if (v < 100000000000) {rd=-6;rm=1000000;} else
        if (v < 1000000000000) {rd=-5;rm=100000;} else
        if (v < 10000000000000) {rd=-4;rm=10000;} else
        if (v < 100000000000000) {rd=-3;rm=1000;} else
        if (v < 1000000000000000) {rd=-2;rm=100;} else
        if (v < 10000000000000000) {rd=-1;rm=10;} else
        if (v < 100000000000000000) {rd=0;rm=1;}

        mPType mantissa=im*rm;
        ePType exponent=ie+rd;
        
        return pprice(mantissa,exponent);
    }

    inline pprice operator /(const pprice & b) {
        //return pprice((double) (*this) / (double) d);
        
        double im=_mantissa/(double)b._mantissa;
        double v=::fabs(im);
        ePType ie = (_exponent-b._exponent);
        mPType rm=100000000000000000;
        ePType rd=-17;
        
        if (v < 10) {rd=-16;rm=10000000000000000;} else
        if (v < 100) {rd=-15;rm=1000000000000000;} else
        if (v < 1000) {rd=-14;rm=100000000000000;} else
        if (v < 10000) {rd=-13;rm=10000000000000;} else
        if (v < 100000) {rd=-12;rm=1000000000000;} else
        if (v < 1000000) {rd=-11;rm=100000000000;} else
        if (v < 10000000) {rd=-10;rm=10000000000;} else
        if (v < 100000000) {rd=-9;rm=1000000000;} else
        if (v < 1000000000) {rd=-8;rm=100000000;} else
        if (v < 10000000000) {rd=-7;rm=10000000;} else
        if (v < 100000000000) {rd=-6;rm=1000000;} else
        if (v < 1000000000000) {rd=-5;rm=100000;} else
        if (v < 10000000000000) {rd=-4;rm=10000;} else
        if (v < 100000000000000) {rd=-3;rm=1000;} else
        if (v < 1000000000000000) {rd=-2;rm=100;} else
        if (v < 10000000000000000) {rd=-1;rm=10;} else
        if (v < 100000000000000000) {rd=0;rm=1;}

        mPType mantissa=im*rm;
        ePType exponent=ie+rd;
        
        return pprice(mantissa,exponent);
    }
    
    inline string get_decimal() const {
        static stringstream ss;
        ss.str("");

        string out = putils::to_string(::llabs(_mantissa));

        string sign = "";
        if (_mantissa < 0) {
            sign = "-";
        }
        const int index = out.length() + _exponent;
        ss.str("");

        if (index == (int) out.length()) {
            ss << sign << out;
        } else
            if (index >= (int) out.length()) {
            ss << sign << out << putils::zeros(_exponent);
        } else
            if (index == 0) {
            out.insert(0, "0.");
            ss << sign << out;
        } else
            if (index > 0) {
            out.insert(index, ".");
            ss << sign << out;
        } else {
            ss << sign << "0." << putils::zeros(0 - index) << out;
        }

        return ss.str();
    }
    
    inline void set_decimal(const string & v) {
        //PROFILE_SCOPED();
 
        const string::size_type dot_pos = v.find_first_of('.');
        const string::size_type sign_pos = v.find_first_of('-');

        int lpff = 0;
        int sign = 1;

        if (sign_pos != string::npos) {
            lpff = sign_pos+1;
            sign = -1;
        }

        int vl = v.length();

        // No dot
        if (dot_pos == string::npos) {
             _exponent = 0;
             while (v.data()[lpff++] == '0');
             char * n = const_cast<char *>(v.data());
             _mantissa = sign * strtoll(n+lpff-1,NULL, 0);
        }
        // Found dot
        else {
             string & ev = const_cast<string &>(v).erase(dot_pos, 1);
             while (ev.data()[lpff++] == '0');
             char * n = const_cast<char *>(ev.data());
            _mantissa = sign * strtoll(n+lpff-1,NULL, 0);
            _exponent = 1 - (vl - dot_pos);
        }
    }
    
    inline operator double () const {
        return (_mantissa * pow(10.0, _exponent));
    }
};

// OK, this is odd but its to do with swig not c++
class half_pprice : public pprice {
public:
    half_pprice() : pprice(5,-1) {
    }
};
   static const pprice PrcZero;
   static const half_pprice PrcHalf;
}}}

 
#endif

