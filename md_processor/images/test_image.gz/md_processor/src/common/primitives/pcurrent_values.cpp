
#include "pcurrent_values.h"

ostream & operator<<(ostream & out, const pcurrent_values & cvs) {
	return cvs.insert(out);
}
