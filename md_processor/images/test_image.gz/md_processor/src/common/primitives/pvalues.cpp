#include "pvalues.h"


ostream & operator << (ostream & out, const pint32 & i32) {
  return i32.insert(out);
}


ostream & operator << (ostream & out, const puint32 & u32) {
  return u32.insert(out);
}


ostream & operator << (ostream & out, const pint64 & i64) {
  return i64.insert(out);
}


ostream & operator << (ostream & out, const puint64 & u64) {
  return u64.insert(out);
}


ostream & operator << (ostream & out, const pstring & str) {
  return str.insert(out);
}

