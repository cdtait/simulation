#ifndef PDATA_H_
#define PDATA_H_
    
/**
 * @brief This is the base class for all types of data.  pdata instances can
 * be null and may have a length.
 */
class pdata {
  public:
    bool _null;
    int _length;

    pdata() {
      _null = true;
      _length = 0;
    }


  public:
    /*
    virtual ~pdata() {
      _null = true;
      _length = 0;
    }
    */

    /**
     * @return the number of bytes occupied by this data object.
     */
    inline unsigned int get_length() const {
      return _length;
    }


    /**
     * Set the number of bytes represented by this object.
     *
     * @param length the length of the data contained in this object.
     */
    void set_length(const int length) {
      _length = length;
    }


    /**
     * @return true if this object contains null data or is null itself.
     */
    bool is_null() const {
      return _null;
    }


    /**
     * Set the internal state representing whether the internal data is null or
     * not.
     *
     * @param null true if this pdata is null.
     */
    void set_null(const bool null) {
      _null = null;
    }
};

#endif /*PDATA_H_*/
