#include <iostream>
#include <time.h>
#include <sys/time.h>
#include <inttypes.h>

#ifndef PTIME_THING_H_
#define PTIME_THING_H_

typedef uint64_t micro_time_t;
typedef uint64_t nano_time_t;

/**
 * @brief Time wrapper utility allowing convenient conversions via instructions and time reference.
 */
class ptime {
public:

	ptime() {
		clear();
	}

	ptime(const ptime & p);

	ptime(const struct timeval& timeOfEvent);

	const struct timeval & timeval_time() {
		return time_stamp;
	}

	micro_time_t micro_time() const {
		return (time_stamp.tv_sec * 1000000) +time_stamp.tv_usec;
	}

	inline void stamp() {
		gettimeofday(&time_stamp, NULL);
	}

	// TODO - why is this not passed by ref?
	inline void stamp(struct timeval timeOfEvent) {
		time_stamp.tv_usec = timeOfEvent.tv_usec;
		time_stamp.tv_sec = timeOfEvent.tv_sec;
	}

	inline void stamp(micro_time_t timeOfEvent) {
		time_stamp.tv_sec = timeOfEvent / 1000000;
		time_stamp.tv_usec = timeOfEvent % 1000000;
	}

	inline void clear() {
		time_stamp.tv_usec = 0;
		time_stamp.tv_sec = 0;
	}

	void reset() {
		clear();
	}

	static void nanosleep(uint64_t nanos) {
		struct timespec tout;
		tout.tv_sec = nanos / 1000000000;
		tout.tv_nsec = nanos % 1000000000;
		::nanosleep(&tout, NULL);
	}

	static uint64_t get_epoch(int year, int mon, int mday, int hour, int min, int sec) {
		// Set the relevant epoch to say something more recent
		// than 1970 in order to reduce the size of the number.
		// TODO See if there is a better way to create this
		time_t currTime = time(NULL);
		struct tm * gmTime = ::gmtime(&currTime);

		gmTime->tm_sec = sec;
		gmTime->tm_min = min;
		gmTime->tm_hour = hour;
		gmTime->tm_mday = mday;
		gmTime->tm_mon = mon - 1;
		gmTime->tm_yday = 0;
		gmTime->tm_year = year - 1900;

		time_t epoch_time = mktime(gmTime);
		// Seconds to 20090101 from 19700101 i.e 0 time epoch in unix
		uint64_t idepoch = epoch_time * 1000000;

		return idepoch;
	}

	static uint64_t get_epoch(std::string dateTimeStr) {
		struct tm gmTime;
		strptime(dateTimeStr.c_str(), "%Y%m%d %H:%M:%S", &gmTime);
		gmTime.tm_isdst = 0;
		time_t epoch_time = timegm(&gmTime);
		return epoch_time * 1000000;
	}

	std::ostream& toStream(std::ostream &out);
	std::string readable();

private:
	struct timeval time_stamp;
};

std::ostream & operator <<(std::ostream & out, const ptime & p);
ptime operator +(ptime& time, const uint32_t& microsecs);

bool operator>(const timeval& tv, ptime& time);
bool operator<(const timeval& tv, ptime& time);

#endif /*PTIME_THING_H_*/
