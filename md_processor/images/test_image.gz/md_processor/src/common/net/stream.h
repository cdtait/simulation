#ifndef stream_h_
#define stream_h_

#define XML_TAB "  "

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>

#include "common/xml/xml_config.h"

/**
 * @brief Define generic multicast FAST stream properties.
 */
	struct stream {
		std::string address;
		std::string port;
		std::string tag;
		std::string type;
		std::string interface;
		std::string name;
	};

	typedef std::vector<stream> streams;

	/**
	 * @brief Define a collection of streams with config.
	 */
	class stream_list {
	public:

		stream_list() { }

		void add(const stream & stream) {
			_streams.push_back(stream);
		}

		const streams & getStreams() const {
			return _streams;
		}

		const std::string getFilter() const {
			std::string filter = "udp and (";
			BOOST_FOREACH(stream stream, _streams) {
				filter += " ( dst net " + stream.address + " and dst port " + stream.port + " ) or ";
			}
			filter += " ( dst net 999.999.999.999 and dst port 9999 ) )";
			return filter;
		}

		std::string writeXML() const {
			return toString();
		}

		std::string toString() const {
			std::stringstream ss;
			ss << XML_TAB << XML_TAB << "<Streams>\n";

			for (streams::const_iterator it = _streams.begin(); it != _streams.end(); it++) {
				ss << XML_TAB << XML_TAB << XML_TAB
						<< "<Stream port='" << (*it).port << "'"
						<< " address='" << (*it).address << "'"
						<< " tag='" << (*it).tag << "'"
						<< " type='" << (*it).type << "'"
						<< " interface='" << (*it).interface << "'"
						<< " name='" << (*it).name
						<< "'/>\n";
			}

			ss << XML_TAB << XML_TAB << "</Streams>\n";
			return ss.str();
		}

		void readXML(const std::string & xmlRoot, xml_config & config) {
			std::string xpathRefSubString(xmlRoot + "/Streams/Stream");
			std::vector<xml_result_value> & sList = config.getRes(xpathRefSubString.c_str());

			for (unsigned int i = 1; i < sList.size() + 1; i++) {
				stream stream;
				stream.address = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@address");
				stream.port = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@port");
				stream.tag = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@tag");
				stream.type = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@type");
				stream.interface = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@interface");
				stream.name = config.stringValue(xpathRefSubString + "[" + boost::lexical_cast<std::string > (i) + "]/@name");
				_streams.push_back(stream);
			}
		}

	private:
		streams _streams;
	};


#endif /* STREAM_H_ */
