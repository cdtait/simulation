#ifndef _MULTICASTEFSOURCE_H
#define	_MULTICASTEFSOURCE_H

#include <cstdlib>
#include <iostream>

#include <sys/types.h>
#include <sys/stat.h>

#include <cstring>

#include <vector>
#include <string>
#include <map>
#include <math.h>
#include <list>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdio>

extern "C" {
#include <etherfabric/vi.h>
#include <etherfabric/iobufset.h>
#include <etherfabric/pd.h>
#include <etherfabric/memreg.h>
};

#include <boost/lexical_cast.hpp>

#include "common/logging/logging_util.h"
#include "common/entities/entity_types.h"
#include "common/net/pcap/PcapAdapter.h"
#include "common/primitives/ptime.h"
#include "common/primitives/pbytes.h"
#include "common/xml/XMLConfig.h"
#include "common/arguments/arguments.h"
#include "common/xml/XMLConfig.h"
#include "common/net/Stream.h"
#include "common/net/StreamSource.h"
#include "common/net/socket/SocketAddress.h"

struct vi {
  int              id;
  char*            interface;
  ef_driver_handle dh;
  ef_vi            vi;
  int              rx_prefix_len;
  ef_iobufset      pkt_bufs;
  struct pkt_buf*  free_pkt_bufs;
  int              free_pkt_bufs_n;
};


struct pkt_buf {
  struct vi*       vi_owner;
  struct pkt_buf*  next;
  ef_addr          addr;
  int              id;
  int              n_refs;
};


#define TRY(x)                                                  \
  do {                                                          \
    int __rc = (x);                                             \
    if( __rc < 0 ) {                                            \
      fprintf(stderr, "ERROR: TRY(%s) failed\n", #x);           \
      fprintf(stderr, "ERROR: at %s:%d\n", __FILE__, __LINE__); \
      fprintf(stderr, "ERROR: rc=%d errno=%d (%s)\n",           \
              __rc, errno, strerror(errno));                    \
      exit(1);                                                  \
    }                                                           \
  } while( 0 )


#define TEST(x)                                                 \
  do {                                                          \
    if( ! (x) ) {                                               \
      fprintf(stderr, "ERROR: TEST(%s) failed\n", #x);          \
      fprintf(stderr, "ERROR: at %s:%d\n", __FILE__, __LINE__); \
      exit(1);                                                  \
    }                                                           \
  } while( 0 )


/* Deliver payload just after the prefix.  We align the start 2-bytes after
 * a 4-byte boundary so that IP header is nicely aligned.
 *
 * NB. You may get performance boost by aligning the start of the DMA
 * buffer on a 64-byte boundary.
 */
#define RX_DMA_OFF       (sizeof(struct pkt_buf) + 2)

/* Where does a received packet start? */
#define RX_PKT_OFF(vi)   (RX_DMA_OFF + (vi)->rx_prefix_len)

/* Get pointer to the received packet payload. */
#define RX_PKT_PTR(pb)   ((char*) (pb) + RX_PKT_OFF((pb)->vi_owner))

/* Pack VI that owns the packet buffer, and the buffer-id into TX request
 * ID.  NB. We only have 16-bits to play with.
 */
#define MK_TX_RQ_ID(vi_i, pb_i)  (((vi_i) << 12) | (pb_i))
#define TX_RQ_ID_VI(rq_id)       ((rq_id) >> 12)
#define TX_RQ_ID_PB(rq_id)       ((rq_id) & 0xfff)

    /**
    * @brief Multicast source based on the select network function.
    */
    class multicast_ef_source : public stream_producer<pbytes*> {

    public:
    	multicast_ef_source(XMLConfig & config);
        virtual ~multicast_ef_source();

        void setStreams(const StreamList & streams, int optimize = 1);
        pbytes ** produce();
        void addStream(const Stream & stream);
        void removeStream(const Stream & stream);

                struct pkt_buf* pkt_buf_from_id(struct vi* vi, int pkt_buf_i);
        void pkt_buf_free(struct pkt_buf* pkt_buf);
        void pkt_buf_release(struct pkt_buf* pkt_buf);
        void pkt_buf_init(struct vi* vi, int pkt_buf_i);
        void vi_refill_rx_ring(struct vi* vi);
        struct vi* vi_alloc(int id, const char* interface);
        struct vi* vi_alloc_from_set(int id, const char* interface,
            ef_vi_set* vi_set, ef_driver_handle vi_set_dh,
            int vi_set_instance);
        void vi_map_all_pkt_bufs(struct vi* vi, struct vi** vis, int vis_n);
        int vi_send(struct vi* vi, struct pkt_buf* pkt_buf, int off, int len);
        
        static socklen_t socklen;

    private:
        LoggerPtr _logger;
        SocketMap _socketMap;
        FDMap _sockets;
        fd_set _socks;
        struct timeval _timeout;
        pbytes ** data_cache_array;
        pbytes ** data_array;
        struct vi* vi;
    };

#endif	/* _MULTICASTEFSOURCE_H */

