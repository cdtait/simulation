/*
 * File:   MulticastEFSource.cpp
 * Author: Jock Strap
 *
 */

#include "multicast_ef_source.h"

socklen_t multicast_ef_source::socklen = sizeof(struct sockaddr_in);

multicast_ef_source::multicast_ef_source(XMLConfig & config) :
_logger(Logger::getLogger("MulticastEFSource"))
{
        FD_ZERO(&_socks);
        _timeout.tv_sec = 0;
        _timeout.tv_usec = 500000;
        data_cache_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        data_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        
        for (int i=0; i < MAXSELECTSIZE; i++) {
                data_cache_array[i] = new pbytes(MAXBUF);
                data_array[i] = NULL;
        }
                       
        data_cache_array[MAXSELECTSIZE] = NULL;
        data_array[MAXSELECTSIZE] = NULL;
}

multicast_ef_source::~multicast_ef_source() {
}
        
void multicast_ef_source::setStreams(const stream_list & streams, int optimize) {

    // Create socket connection
    // Walk round the filter string extracting the mcast address/port
    // for each product and then join the mcast group for each
            
    // Assume all streams come off the same interface
    ef_filter_spec filter_spec;
    vi = vi_alloc(0, (*streams.getStreams().begin()).name.c_str());

    struct sockaddr_in sin;
    struct addrinfo hints;
    struct addrinfo* ai;
    int protocol = IPPROTO_UDP;
    int rc = -EINVAL;
    
    streams::const_iterator end = streams.getStreams().end();

    for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
        const Stream & stream = (*it);
        addStream(stream);
        
        hints.ai_flags = AI_NUMERICSERV;
        hints.ai_family = AF_INET;
        hints.ai_socktype = 0;
        hints.ai_protocol = 0;
        hints.ai_addrlen = 0;
        hints.ai_addr = NULL;
        hints.ai_canonname = NULL;
        hints.ai_next = NULL;

        rc = getaddrinfo(stream.address.c_str(), stream.port.c_str(), &hints, &ai);

        if (rc == 0) {
            TEST(ai->ai_addrlen == sizeof(sin));
            memcpy(&sin, ai->ai_addr, ai->ai_addrlen);
        } else {
            LOG_ERROR(_logger, "ERROR: getaddrinfo("<< stream.address <<", "<< stream.port << ") returned " << rc << " " <<  gai_strerror(rc));
            rc = -EINVAL;
        }
        
        ef_filter_spec_init(&filter_spec, EF_FILTER_FLAG_NONE);
        ef_filter_spec_set_ip4_local(&filter_spec, protocol, sin.sin_addr.s_addr, sin.sin_port);
        TRY(ef_vi_filter_add(&vi->vi, vi->dh, &filter_spec, NULL));
    }
}

pbytes ** multicast_ef_source::produce() {
    ef_event evs[16];
    int i, n_ev;
    int count = 0;

    n_ev = ef_eventq_poll(&vi->vi, evs, 10);

    if (n_ev > 0) {
        for (i = 0; i < n_ev; ++i) {
            switch (EF_EVENT_TYPE(evs[i])) {
                case EF_EVENT_TYPE_RX:
                {
                    /* This code does not handle jumbos. */
                    assert(EF_EVENT_RX_SOP(evs[i]) != 0);
                    assert(EF_EVENT_RX_CONT(evs[i]) == 0);

                    struct pkt_buf* pkt_buf;
                    int len = EF_EVENT_RX_BYTES(evs[i]);
                    int pkt_buf_i = EF_EVENT_RX_RQ_ID(evs[i]);
                    LOG_TRACE(_logger, "Interface: [" << vi->interface << " received pkt=" << pkt_buf_i << " len=" << len);
                    //LOG_INFO(_logger, "Interface: [" << vi->interface << " received pkt=" << pkt_buf_i << " len=" << len);

                    pkt_buf = pkt_buf_from_id(vi, EF_EVENT_RX_RQ_ID(evs[i]));

                    if (len > -1) {                             
                        const struct ip *ip = (struct ip *) (RX_PKT_PTR(pkt_buf) + ETH_HLEN);
                        int size_ip = (ip->ip_hl & 0x0f) * 4;

                        int protocol_header;

                        if (ip->ip_p == IPPROTO_UDP) {
                            udphdr *uh = (udphdr *) ((unsigned char *) ip + size_ip);
                            protocol_header = sizeof (*uh);
                            len = ntohs(ip->ip_len) - (size_ip + protocol_header);

                            memcpy(data_cache_array[count]->_value, RX_PKT_PTR(pkt_buf)+ ETH_HLEN + size_ip + protocol_header, len);
                            data_cache_array[count]->stamp();
                            data_cache_array[count]->set_length(len);

                            LOG_TRACE(_logger, "len :"<<len);
                            LOG_TRACE(_logger, "b:\n" << putils::to_hex(data_cache_array[count]->_value, len));
                            //LOG_INFO(_logger, "len :"<<len);
                            //LOG_INFO(_logger, "b:\n" << putils::to_hex(data_cache_array[count]->_value, len));
                            
                            data_array[count] = data_cache_array[count];
                            count++;
                        }
                        else {
                            LOG_ERROR(_logger, "ip does not appear to be udp");
                        }
  
                    } else {
                        LOG_ERROR(_logger, "error len:" << len);
                    }

                    pkt_buf_release(pkt_buf);
                }
                    break;
                case EF_EVENT_TYPE_RX_DISCARD:
                {
                    if (EF_EVENT_RX_DISCARD_TYPE(evs[i]) == EF_EVENT_RX_DISCARD_MCAST_MISMATCH) {
                        struct pkt_buf* pkt_buf;
                        int len = EF_EVENT_RX_BYTES(evs[i]);
                        int pkt_buf_i = EF_EVENT_RX_RQ_ID(evs[i]);
                        //LOG_INFO(_logger, "Interface: [" << vi->interface << " received discarded pkt=" << pkt_buf_i << " len=" << len);
                        LOG_TRACE(_logger, "Interface: [" << vi->interface << " received discarded pkt=" << pkt_buf_i << " len=" << len);

                        pkt_buf = pkt_buf_from_id(vi, pkt_buf_i);
                        pkt_buf_release(pkt_buf);
                    } else {
                        LOG_ERROR(_logger, "ERROR: packet discarded because of EF_EVENT_RX_DISCARD_MCAST_MISMATCH" );
                    }
                }
                    break;
                default:
                    LOG_ERROR(_logger, "ERROR: unexpected event type=" << (int) EF_EVENT_TYPE(evs[i]));
                    break;
            }
        }

        vi_refill_rx_ring(vi);
    }
    
    data_array[count] = NULL;

    return data_array;
}

void multicast_ef_source::addStream(const Stream & stream) {
    LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");
    std::string group = stream.address + ":" + stream.port;
    int multicast_port = atoi(stream.port.c_str());

    SocketAddress * sock_address = NULL;

    SocketMap::const_iterator it = _socketMap.find(group);

    // Have we already got a socket for this port?
    if (it == _socketMap.end()) {
        // No? Well create the socket
        sock_address =  new SocketAddress;
        sock_address->count = 1;
        sock_address->fd = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);

        int reuse = 1;
        int status = setsockopt(sock_address->fd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));

        LOG_INFO(_logger,"Setting reuse on the socket fd:" << sock_address->fd << " on " << group);

        _sockets[sock_address->fd] = sock_address;

        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        status = setsockopt(sock_address->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));

        _socketMap[group] = sock_address;
    }
    else {
        // Yes? Then share the socket address
        sock_address = it->second;
        sock_address->count++;
    }
}

 void multicast_ef_source::removeStream(const Stream & stream) {
   LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    std::string group = stream.address + ":" + stream.port;

    SocketMap::const_iterator it = _socketMap.find(group);

    if (it != _socketMap.end()) {
        SocketAddress * sock_address = it->second;
        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        setsockopt(sock_address->fd, IPPROTO_IP, IP_DROP_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));
        _socketMap.erase(group);

        if (sock_address->count==1) {

            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            int multicast_port = atoi(stream.port.c_str());
            LOG_INFO(_logger,"Clearing descriptor:" << sock_address->fd);
            FD_CLR(sock_address->fd,&_socks);
            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            close(sock_address->fd);
            sock_address->count--;
            LOG_INFO(_logger,"Removing from sockets[" << multicast_port << "]");
            _sockets.erase(sock_address->fd);

            delete sock_address;
        }
        else {
            sock_address->count--;
        }
     }
}
 
struct pkt_buf* multicast_ef_source::pkt_buf_from_id(struct vi* vi, int pkt_buf_i)
{
  assert(pkt_buf_i < ef_iobufset_num(&vi->pkt_bufs));
  return (struct pkt_buf*) ef_iobufset_ptr(&vi->pkt_bufs, pkt_buf_i);
}


void multicast_ef_source::pkt_buf_free(struct pkt_buf* pkt_buf)
{
  struct vi* vi = pkt_buf->vi_owner;
  assert(pkt_buf->n_refs == 0);
  pkt_buf->next = vi->free_pkt_bufs;
  vi->free_pkt_bufs = pkt_buf;
  ++vi->free_pkt_bufs_n;
}


void multicast_ef_source::pkt_buf_release(struct pkt_buf* pkt_buf)
{
  assert(pkt_buf->n_refs > 0);
  if( --pkt_buf->n_refs == 0 )
    pkt_buf_free(pkt_buf);
}


void multicast_ef_source::pkt_buf_init(struct vi* vi, int pkt_buf_i)
{
  struct pkt_buf* pkt_buf;
  pkt_buf = pkt_buf_from_id(vi, pkt_buf_i);
  pkt_buf->vi_owner = vi;
  pkt_buf->addr = ef_iobufset_addr(&vi->pkt_bufs, pkt_buf_i);
  pkt_buf->id = pkt_buf_i;
  pkt_buf->n_refs = 0;
  pkt_buf_free(pkt_buf);
}


void multicast_ef_source::vi_refill_rx_ring(struct vi* vi)
{
#define REFILL_BATCH_SIZE  16
  struct pkt_buf* pkt_buf;
  int i;

  if( ef_vi_receive_space(&vi->vi) >= REFILL_BATCH_SIZE &&
      vi->free_pkt_bufs_n >= REFILL_BATCH_SIZE ) {
    for( i = 0; i < REFILL_BATCH_SIZE; ++i ) {
      pkt_buf = vi->free_pkt_bufs;
      vi->free_pkt_bufs = vi->free_pkt_bufs->next;
      --vi->free_pkt_bufs_n;
      assert(pkt_buf->n_refs == 0);
      pkt_buf->n_refs = 1;
      ef_vi_receive_init(&vi->vi, pkt_buf->addr + RX_DMA_OFF, pkt_buf->id);
    }
    ef_vi_receive_push(&vi->vi);
  }
}


struct vi* multicast_ef_source::vi_alloc(int id, const char* interface)
{
  int i, ifindex;
  struct vi* vi;

  if( (ifindex = if_nametoindex(interface)) == 0 )
    ifindex = atoi(interface);

  vi = (struct vi*)malloc(sizeof(*vi));
  vi->id = id;
  vi->interface = strdup(interface);
  TRY(ef_driver_open(&vi->dh));
  TRY(ef_vi_alloc(&vi->vi, vi->dh, ifindex, -1, -1, -1, NULL, -1, EF_VI_FLAGS_DEFAULT));
  TRY(ef_iobufset_alloc(&vi->pkt_bufs, vi->dh, &vi->vi, vi->dh, 0, 2048,
                        ef_vi_receive_capacity(&vi->vi), 4, 0));
  vi->rx_prefix_len = ef_vi_receive_prefix_len(&vi->vi);
  vi->free_pkt_bufs_n = 0;
  for( i = 0; i < ef_iobufset_num(&vi->pkt_bufs); ++i )
    pkt_buf_init(vi, i);
  vi_refill_rx_ring(vi);

  return vi;
}


struct vi* multicast_ef_source::vi_alloc_from_set(int id, const char* interface,
                             ef_vi_set* vi_set, ef_driver_handle vi_set_dh,
                             int vi_set_instance)
{
  struct vi* vi;
  int i;

  vi = (struct vi*)malloc(sizeof(*vi));
  vi->id = id;
  vi->interface = strdup(interface);
  TRY(ef_driver_open(&vi->dh));
  TRY(ef_vi_alloc_from_set(&vi->vi, vi->dh, vi_set, vi_set_dh,
                           vi_set_instance, -1, -1, -1, NULL, -1, EF_VI_FLAGS_DEFAULT));
  TRY(ef_iobufset_alloc(&vi->pkt_bufs, vi->dh, &vi->vi, vi->dh, 0, 2048,
                        ef_vi_receive_capacity(&vi->vi), 4, 0));
  vi->rx_prefix_len = ef_vi_receive_prefix_len(&vi->vi);
  vi->free_pkt_bufs_n = 0;
  for( i = 0; i < ef_iobufset_num(&vi->pkt_bufs); ++i )
    pkt_buf_init(vi, i);
  vi_refill_rx_ring(vi);

  return vi;
}


void multicast_ef_source::vi_map_all_pkt_bufs(struct vi* vi, struct vi** vis, int vis_n)
{
  struct vi* other;
  int i;
  for( i = 0; i < vis_n; ++i )
    if( (other = vis[i]) != vi )
      TRY(ef_iobufset_remap(&other->pkt_bufs, other->dh, &vi->vi, vi->dh,
                            vi->dh));
}


int multicast_ef_source::vi_send(struct vi* vi, struct pkt_buf* pkt_buf, int off, int len)
{
  int rc;
  rc = ef_vi_transmit(&vi->vi, pkt_buf->addr + off, len,
                      MK_TX_RQ_ID(pkt_buf->vi_owner->id, pkt_buf->id));
  if( rc == 0 )
    ++pkt_buf->n_refs;
  return rc;
}

