/* 
 * File:   MulticastEPollSource.cpp
 * Author: Jock Strap
 * 
 */

#include "multicast_epoll_producer.h"

namespace common {
namespace net {
namespace socket {

socklen_t multicast_epoll_producer::socklen = sizeof(struct sockaddr_in);

void multicast_epoll_producer::setStreams(const stream_list & streams, int optimize) {

    // Create socket connection
    // Walk round the filter string extracting the mcast address/port
    // for each product and then join the mcast group for each

    ::memset(_events,'\0',MAXEPOLLSIZE*sizeof(struct epoll_event));
    _kernel_event_backing_store_fd = epoll_create(MAXEPOLLSIZE);

    streams::const_iterator end = streams.getStreams().end();

    for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
        const stream & stream = (*it);
        addStream(stream);
    }
}



void multicast_epoll_producer::addStream(const stream & stream) {
	LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    int status = 0;
    int multicast_port = atoi(stream.port.c_str());

    EpollSocketAddress * sock_address = NULL;

    EpollPortMap::const_iterator it = _portMap.find(multicast_port);

    // Have we already got a socket for this port?
    if (it == _portMap.end()) {
        // No? Well create the socket
        sock_address =  new EpollSocketAddress;
        sock_address->count = 1;
        sock_address->ev.data.fd = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
        memset((char *) & sock_address->listen_address, 0, sizeof(sock_address->listen_address));
        sock_address->listen_address.sin_family = AF_INET;
        sock_address->listen_address.sin_port = htons(multicast_port);
        sock_address->listen_address.sin_addr.s_addr = INADDR_ANY;

        LOG_INFO(_logger,"Adding socket with fd:" << sock_address->ev.data.fd << " on port:" << multicast_port << " on any address");

        int status = bind(sock_address->ev.data.fd, (struct sockaddr *)&sock_address->listen_address, sizeof(struct sockaddr_in));

        LOG_INFO(_logger,"Binding socket fd:" << sock_address->ev.data.fd << " on port:" << multicast_port);

        int reuse = 1;
        status = setsockopt(sock_address->ev.data.fd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));

        LOG_INFO(_logger,"Setting reuse on the socket fd:" << sock_address->ev.data.fd << " on port:" << multicast_port);

        _sockets[sock_address->ev.data.fd] = sock_address;
        _portMap[multicast_port] = sock_address;

        int flags;

    	#if defined(O_NONBLOCK)
        if (-1 == (flags = fcntl(sock_address->ev.data.fd, F_GETFL, 0)))
            flags = 0;
        	fcntl(sock_address->ev.data.fd, F_SETFL, flags | O_NONBLOCK);
    	#else
        	flags = 1;
        	ioctl(sock_address->ev.data.fd, FIOBIO, &flags);
    	#endif

        epoll_event ev = { 0, { 0 } };
        ev.events = EPOLLIN | EPOLLERR | EPOLLHUP | EPOLLOUT | EPOLLPRI | EPOLLET;
  
        int result = epoll_ctl(_kernel_event_backing_store_fd, EPOLL_CTL_ADD, sock_address->ev.data.fd, &ev);
        if (result != 0) {
        	LOG_ERROR(_logger," errno:" << errno);
        }
    }
    else {
        // Yes? Then share the socket address
        sock_address = it->second;
        sock_address->count++;
    }

    struct ip_mreq multicast_address;
    memset((char *) &multicast_address, 0, sizeof(multicast_address));

    multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
    multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

    status = setsockopt(sock_address->ev.data.fd, IPPROTO_IP, IP_ADD_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));

    std::string group = stream.address + ":" + stream.port;
    _socketMap[group] = sock_address;
}

 void multicast_epoll_producer::removeStream(const stream & stream) {
    LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    std::string group = stream.address + ":" + stream.port;

    EpollSocketMap::const_iterator it = _socketMap.find(group);

    if (it != _socketMap.end()) {
    	EpollSocketAddress * sock_address = it->second;
        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        setsockopt(sock_address->ev.data.fd, IPPROTO_IP, IP_DROP_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));
        _socketMap.erase(group);

        if (sock_address->count==1) {
            LOG_INFO(_logger,"Closing socket:" << sock_address->ev.data.fd);
            int multicast_port = atoi(stream.port.c_str());
            LOG_INFO(_logger,"Removing from portMap[" << multicast_port << "]");
            _portMap.erase(multicast_port);
            LOG_INFO(_logger,"Removing socket[" << multicast_port << "]");
            _sockets.erase(sock_address->ev.data.fd);

//            struct epoll_event ev;
            close(sock_address->ev.data.fd);
            sock_address->count--;

            LOG_INFO(_logger,"Removing event descriptor:" << sock_address->ev.data.fd);

            delete sock_address;
        }
        else {
            sock_address->count--;
        }
    }
}
}}}

