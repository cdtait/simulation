/*
 * File:   MulticastSelectSource.cpp
 * Author: Jock Strap
 *
 */

#include "multicast_select_producer.h"

namespace common {
namespace net {
namespace socket {

socklen_t multicast_select_producer::socklen = sizeof(struct sockaddr_in);

multicast_select_producer::multicast_select_producer(xml_config & config) :
_logger(Logger::getLogger("MulticastSelectSource"))
{
        FD_ZERO(&_socks);
        _timeout.tv_sec = 0;
        _timeout.tv_usec = 500000;
        _highsock = -1;
        data_cache_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        data_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        
        for (int i=0; i < MAXSELECTSIZE; i++) {
                data_cache_array[i] = new pbytes(MAXBUF);
                data_array[i] = NULL;
        }
                       
        data_cache_array[MAXSELECTSIZE] = NULL;
        data_array[MAXSELECTSIZE] = NULL;
}

multicast_select_producer::~multicast_select_producer() {
}
        
void multicast_select_producer::setStreams(const stream_list & streams, int optimize) {

    // Create socket connection
    // Walk round the filter string extracting the mcast address/port
    // for each product and then join the mcast group for each
            
    streams::const_iterator end = streams.getStreams().end();

    for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
        const stream & stream = (*it);
        addStream(stream);
    }
}



void multicast_select_producer::addStream(const stream & stream) {
	LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    int status = 0;
    int multicast_port = atoi(stream.port.c_str());

    socket_address * sock_address = NULL;

    PortMap::const_iterator it = _portMap.find(multicast_port);

    // Have we already got a socket for this port?
    if (it == _portMap.end()) {
        // No? Well create the socket
        sock_address =  new socket_address;
        sock_address->count = 1;
        sock_address->fd = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
        if (_highsock < sock_address->fd) {
        	_highsock = sock_address->fd;
        }
        memset((char *) & sock_address->listen_address, 0, sizeof(sock_address->listen_address));
        sock_address->listen_address.sin_family = AF_INET;
        sock_address->listen_address.sin_port = htons(multicast_port);
        sock_address->listen_address.sin_addr.s_addr = INADDR_ANY;
        //sock_address->listen_address.sin_addr.s_addr = inet_addr(stream.interface.c_str());

        LOG_INFO(_logger,"Adding socket with fd:" << sock_address->fd << " on port:" << multicast_port << " on any address");

        int status = bind(sock_address->fd, (struct sockaddr *)&sock_address->listen_address, sizeof(struct sockaddr_in));

        LOG_INFO(_logger,"Binding socket fd:" << sock_address->fd << " on port:" << multicast_port << " status:" << status);

        int reuse = 1;
        status = setsockopt(sock_address->fd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));

        LOG_INFO(_logger,"Setting reuse on the socket fd:" << sock_address->fd << " on port:" << multicast_port);
/*
        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "p3p2");
        if (setsockopt(sock_address->fd, SOL_SOCKET, SO_BINDTODEVICE,(void *)&ifr, sizeof(ifr)) < 0) {
                LOG_ERROR(_logger,"Could not bind to device socket fd:" << sock_address->fd << " on interface:" << "p3p4");
        }
*/
        _sockets[sock_address->fd] = sock_address;
        _portMap[multicast_port] = sock_address;

        int flags;

    	#if defined(O_NONBLOCK)
        if (-1 == (flags = fcntl(sock_address->fd, F_GETFL, 0)))
            flags = 0;
        	fcntl(sock_address->fd, F_SETFL, flags | O_NONBLOCK);
    	#else
        	flags = 1;
        	ioctl(sock_address->fd, FIOBIO, &flags);
    	#endif

        FD_SET(sock_address->fd,&_socks);

    }
    else {
        // Yes? Then share the socket address
        sock_address = it->second;
        sock_address->count++;
    }

    struct ip_mreq multicast_address;
    memset((char *) &multicast_address, 0, sizeof(multicast_address));

    multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
    multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

    status = setsockopt(sock_address->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));

    std::string group = stream.address + ":" + stream.port;
    _socketMap[group] = sock_address;
}

 void multicast_select_producer::removeStream(const stream & stream) {
    LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    std::string group = stream.address + ":" + stream.port;

    SocketMap::const_iterator it = _socketMap.find(group);

    if (it != _socketMap.end()) {
        socket_address * sock_address = it->second;
        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        setsockopt(sock_address->fd, IPPROTO_IP, IP_DROP_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));
        _socketMap.erase(group);

        if (sock_address->count==1) {

            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            int multicast_port = atoi(stream.port.c_str());
            LOG_INFO(_logger,"Removing from portMap[" << multicast_port << "]");
            _portMap.erase(multicast_port);
            LOG_INFO(_logger,"Clearing descriptor:" << sock_address->fd);
            FD_CLR(sock_address->fd,&_socks);
            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            close(sock_address->fd);
            sock_address->count--;
            LOG_INFO(_logger,"Removing from sockets[" << multicast_port << "]");
            _sockets.erase(sock_address->fd);

            FDMap::const_iterator iter = _sockets.begin();

            // Reestablish highest file descriptor as it might have gone
            if (sock_address->fd == _highsock) {
                _highsock = -1;
                for (; iter != _sockets.end(); iter++) {
                   if (_highsock < (*iter).second->fd) {
                    _highsock = (*iter).second->fd;
                   }
                }
            }

            delete sock_address;
        }
        else {
            sock_address->count--;
        }
    }
}

}}}

