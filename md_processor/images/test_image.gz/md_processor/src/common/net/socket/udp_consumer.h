#ifndef UDPSink_h_
#define	UDPSink_h_

#include <boost/asio.hpp>
#include <boost/array.hpp>
#include <log4cxx/logger.h>
#include "common/primitives/pbytes.h"

using boost::asio::ip::udp;
using namespace log4cxx;

namespace common {
	namespace net {
		namespace socket {

		/**
		* @brief Single UDP sink to handle sending of messages as udp events.
		*/
			class udp_consumer {
			public:

				udp_consumer(const std::string& address, const int& port, bool multicast);

				virtual ~udp_consumer();

				virtual bool consume(pbytes * data);

			private:
				static const int BUFFER_SIZE = 64 * 1024;

				boost::asio::io_service _io_service;
				udp::socket _socket;
				udp::endpoint _endpoint;

				boost::array<uint8_t, BUFFER_SIZE> _buffer;

				LoggerPtr _logger;
			};

		}
	}
}

#endif	/* UDPSink_h_ */

