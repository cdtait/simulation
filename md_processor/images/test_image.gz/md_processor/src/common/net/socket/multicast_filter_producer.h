#ifndef multicast_filter_producer_h
#define	multicast_filter_producer_h

#include <cstdlib>
#include <iostream>

#include <sys/types.h>
#include <sys/stat.h>

#include <cstring>

#include <vector>
#include <string>
#include <map>
#include <math.h>
#include <list>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdio>

#include "common/primitives/ptime.h"
#include <boost/lexical_cast.hpp>
#include "common/logging/logging_util.h"
#include "common/entities/entity_types.h"
#include "common/net/pcap/pcap_adapter.h"
#include "common/primitives/ptime.h"
#include "common/primitives/pbytes.h"
#include "common/xml/xml_config.h"
#include "common/arguments/arguments.h"
#include "common/xml/xml_config.h"
#include "common/net/stream.h"
#include "common/net/stream_producer.h"
#include "common/net/socket/socket_address.h"

namespace common {
namespace net {
namespace socket {

    /**
    * @brief Multicast source based on the select network function.
    */
    class multicast_filter_producer : public stream_producer {

    public:
        multicast_filter_producer(xml_config & config);
        virtual ~multicast_filter_producer();

        template <typename consumer>
        void produce(consumer & c) {
            _timeout.tv_sec = 0;
            _timeout.tv_usec = 500000;

            FDMap::const_iterator iter = _sockets.begin();

            for (; iter != _sockets.end(); iter++) {
            	 FD_SET((*iter).second->fd,&_socks);
            }

            int nfds = select(FD_SETSIZE, &_socks, (fd_set *) 0, (fd_set *) 0, &_timeout);
            //LOG_INFO(_logger,"nfds:" << nfds);
            int count = 0;

            if (nfds > -1) {
                for (iter = _sockets.begin(); iter != _sockets.end(); iter++) {
                    if (FD_ISSET((*iter).second->fd, &_socks)) {
                        data_cache_array[count]->set_length(0);
                        int len = ::recvfrom((*iter).second->fd, data_cache_array[count]->_value, MAXBUF, 0, (struct sockaddr *) & (*iter).second->listen_address, &socklen);

                        if (len > -1) {
                            data_cache_array[count]->stamp();
                            data_cache_array[count]->set_length(len);
                            data_array[count] = data_cache_array[count];

                            //LOG_INFO(_logger,"len:" << len);
                            count++;
                        }
                        else {
                            LOG_ERROR(_logger,"error len:" << len);
                        }
                    }
                }
            }
            else {
                if (errno == EBADF ) {
                    LOG_ERROR(_logger, "An invalid file descriptor was given in one of the sets. (Perhaps a file descriptor that was already closed, or one on which an error has occurred.)");
                }
                else if(errno == EINTR) {
                    LOG_ERROR(_logger, "A signal was caught.");
                }
                else if(errno == EINVAL) {
                    LOG_ERROR(_logger, "The nfds is negative or the value contained within timeout is invalid.");
                }
               else if(errno == ENOMEM) {
                    LOG_ERROR(_logger, "Unable to allocate memory for internal tables. ");
                }
            }

            //LOG_INFO(_logger,"data_array count:" << count);

            data_array[count] = NULL;

        //#ifdef __LOG_TRACE__
        //    for (int i =0; i < MAXSELECTSIZE; i++) {
        //        if (data_array[i]) {
        //                LOG_INFO(_logger,"data_array[" << i << "]:\n" << putils::to_hex(data_array[i]->_value,data_array[i]->get_length()));
        //        }
        //    }
        //#endif

            c.consume(data_array);

            //return data_array;
        }

        void setStreams(const stream_list & streams, int optimize = 1);
        void addStream(const stream & stream);
        void removeStream(const stream & stream);

        static socklen_t socklen;

    private:
        LoggerPtr _logger;
        SocketMap _socketMap;
        //pbytes _data;
        FDMap _sockets;
        //PortMap _portMap;
        fd_set _socks;
        struct timeval _timeout;
        //int _highsock;
        pbytes ** data_cache_array;
        pbytes ** data_array;
    };

}}}
#endif	/* MulticastFilterSource_h_ */

