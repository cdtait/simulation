#include "udp_consumer.h"
#include "common/logging/logging_util.h"

namespace common { namespace net { namespace socket {
		udp_consumer::udp_consumer(const std::string& address, const int& port, bool multicast) :
			_socket(_io_service),
			_endpoint(boost::asio::ip::address::from_string(address), port),
			_logger(Logger::getLogger("ausus.common.net.socket.UDPSink")) {
				boost::system::error_code errorCode;

				_socket.open(_endpoint.protocol(), errorCode);

				if (errorCode) {
					LOG_FATAL(_logger, "Failed to open socket - error code [" << errorCode.value() << "]");
					exit(errorCode.value());
				} else {
					LOG_INFO(_logger, "Opened socket");
				}

				if (!multicast) _socket.set_option(boost::asio::ip::udp::socket::broadcast(true));
		}

		udp_consumer::~udp_consumer() {
		}

		bool udp_consumer::consume(pbytes * data) {
				_socket.send_to(boost::asio::buffer(data->get_value(), data->get_length()), _endpoint);
				return true;
		}

}}}
