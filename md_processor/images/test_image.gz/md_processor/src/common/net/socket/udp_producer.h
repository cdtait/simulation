#ifndef _UDPSOUREC_H
#define	_UDPSOUREC_H

#include <string>
#include <boost/asio.hpp>
#include <common/logging/logging_util.h>
#include <boost/array.hpp>
#include <boost/lexical_cast.hpp>
#include <string>
#include <iostream>
#include <sstream>

#include "common/primitives/putils.h"
#include "common/primitives/pbytes.h"

using namespace log4cxx;
using boost::asio::ip::udp;

namespace common { namespace net { namespace socket {
/**
* @brief Single UDP source for handle receiving of udp events.
*/
class udp_producer  {
public:

	udp_producer(const std::string& address, const int& port, const long int& timeout) :
		_address(address),
		_port(port),
		_data(BUFFER_SIZE),
		_logger(Logger::getLogger("common.net.socket.UDPSource")) {

		struct sockaddr_in servAddr;
		struct hostent *h = ::gethostbyname(address.c_str());

		if (h == NULL) {
			LOG_ERROR(_logger, address << ": unknown host '" << port << "'");
			throw new std::exception();
		}

		struct in_addr * ip = (struct in_addr *) h->h_addr_list[0];
		char * taddr = ::inet_ntoa(*ip);

		LOG_ERROR(_logger, address << ": Creating connection to '" << h->h_name
				<< "' (IP : " << taddr << ") (Timeout : " << timeout << ")");

		// Create the server address and port we will receive from
		servAddr.sin_family = h->h_addrtype;
		memcpy((char *) & servAddr.sin_addr.s_addr, h->h_addr_list[0], h->h_length);
		servAddr.sin_port = htons(port);

		// Create the socket
		_sock = ::socket(AF_INET, SOCK_DGRAM, 0);

		if (_sock < 0) {
			LOG_ERROR(_logger, "Cannot open socket: " << address);
			throw new std::exception();
		}

		// Create the set receive timeout
		ptime p;
		p.stamp(timeout);
		int ret = setsockopt(_sock, SOL_SOCKET, SO_RCVTIMEO, &p.timeval_time(), sizeof (p.timeval_time()));

		if (ret < 0) {
			LOG_ERROR(_logger, "Cannot set receive timeout on socket");
			throw new std::exception();
		}

		// Allow the multiple binds
		int reuse = 1;
		ret = setsockopt(_sock, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof (reuse));

		if (ret < 0) {
			LOG_ERROR(_logger, "Cannot set reuse on socket");
			throw new std::exception();
		}

		int broadcast = 1;
		ret = setsockopt(_sock, SOL_SOCKET, SO_BROADCAST, (char *) & broadcast, sizeof (broadcast));

		if (ret < 0) {
			LOG_ERROR(_logger, "Cannot set broadcast on socket");
			throw new std::exception();
		}

		// Bind to the socket
		ret = bind(_sock, (struct sockaddr *) & servAddr, sizeof (servAddr));

		if (ret < 0) {
			LOG_ERROR(_logger, "Cannot bind port: " << port);
			throw new std::exception();
		}
	}

	~udp_producer() {
		::close(_sock);
	}

	template<typename consumer>
	void produce(consumer & c) {
		LOG_TRACE(_logger, "Listening for data...");

		// Keep calling recv and passing data onto the consumer
		// TODO Loop here!!!!!
		ssize_t len = ::recv(_sock, _data._value, BUFFER_SIZE, 0);
		_data.set_length(len);
		_data.stamp();

		LOG_TRACE(_logger, "Message received [" << len << "]");

		//return &_data;
		c.consume(&_data);
	}


private:
	static const int BUFFER_SIZE = 64 * 1024;

	std::string _address;
	int _port;
	int _sock;
	pbytes _data;

	LoggerPtr _logger;
};
}}}

#endif	/* _UDPSOUREC_H */

