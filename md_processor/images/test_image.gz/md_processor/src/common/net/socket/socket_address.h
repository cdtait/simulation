#ifndef SocketAddress_h_
#define	SocketAddress_h_

#include <cstdlib>
#include <iostream>

#include <sys/types.h>
#include <sys/stat.h>

#include <cstring>

#include <vector>
#include <string>
#include <map>
#include <math.h>
#include <list>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdio>

/**
* @brief Wrap a unix socket address track subscriber count.
*/
    struct socket_address {
        struct sockaddr_in listen_address;
        int count;
        int fd;
    };

    typedef std::map<std::string, socket_address*> SocketMap;
    typedef std::map<int, socket_address*> PortMap;
    typedef std::map<int, socket_address*> FDMap;

    
    #define MAXBUF 2048*10
    #define MAXSELECTSIZE 100

#endif	/* SocketAddress */

