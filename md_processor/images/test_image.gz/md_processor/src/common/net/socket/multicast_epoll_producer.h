#ifndef multicast_epoll_producer_h
#define	multicast_epoll_producer_h

#include <cstdlib>
#include <iostream>

#include <sys/types.h>
#include <sys/stat.h>

#include <cstring>

#include <vector>
#include <string>
#include <map>
#include <math.h>
#include <list>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdio>


#include "common/primitives/ptime.h"
#include <boost/lexical_cast.hpp>
#include "common/logging/logging_util.h"
#include "common/entities/entity_types.h"
#include "common/net/pcap/pcap_adapter.h"
#include "common/primitives/ptime.h"
#include "common/primitives/pbytes.h"
#include "common/xml/xml_config.h"
#include "common/arguments/arguments.h"
#include "common/xml/xml_config.h"
#include "common/net/stream.h"
#include "common/net/stream_producer.h"

namespace common {
namespace net {
namespace socket {

    struct EpollSocketAddress {
        struct sockaddr_in listen_address;
        int count;
        struct epoll_event ev;
    };

    typedef std::map<std::string, EpollSocketAddress*> EpollSocketMap;
    typedef std::map<int, EpollSocketAddress*> EpollPortMap;
    typedef std::map<int, EpollSocketAddress*> EpollFDMap;

    #define MAXBUF 2048*10
	#define MAXEPOLLSIZE 10

    /**
    * @brief Multicast source based on the epoll network library.
    */
    class multicast_epoll_producer {

    public:
    	multicast_epoll_producer(xml_config & config) :
        _logger(Logger::getLogger("MulticastEPollSource")),
        _data(MAXBUF),
        _kernel_event_backing_store_fd(-1)
        {
        	::memset(_events,'\0',MAXEPOLLSIZE*sizeof(struct epoll_event));
        }

        virtual ~multicast_epoll_producer() {
        }

        template<typename consumer>
        void produce(consumer & c) {
        	struct epoll_event events[MAXEPOLLSIZE];
        	//::memset(events,'\0',MAXEPOLLSIZE*sizeof(struct epoll_event));
        	_data.set_length(0);

            int nfds = epoll_wait(_kernel_event_backing_store_fd, events, MAXEPOLLSIZE, 500);

            //LOG_INFO(_logger,"File descriptors:" << _curfds);

            if (nfds > -1 ) {
        		int acclen = 0;
        		int len;

        		for (int n = 0; n < nfds; ++n) {
                    if(events[n].events & EPOLLIN)
                    {
                         if (events[n].data.fd == 0)
                             continue;

                         //LOG_INFO(_logger,"Receive from:" << n);
                         len=recvfrom(events[n].data.fd, _data._value + acclen, MAXBUF, 0,(struct sockaddr *)&_sockets[events[n].data.fd]->listen_address, &socklen);
                         // LOG_INFO(_logger,"errno:" << errno  << " n:" << n << " fd" << events[n].data.fd);

                         if (len > -1) {
                        	 acclen += len;
                        	 _data.stamp();
                         }

                         _data.set_length(acclen);
                    }
                    else {
                    	LOG_INFO(_logger,"events[n].events:" << events[n].events);
                    }
        		}
            }

            c.consume(&_data);

            //return &_data;
        }
        void setStreams(const stream_list & streams, int optimize = 1);
        void addStream(const stream & stream);
        void removeStream(const stream & stream);

        static socklen_t socklen;

    private:
        LoggerPtr _logger;
        EpollSocketMap _socketMap;
        pbytes _data;
        EpollFDMap _sockets;
        EpollPortMap _portMap;
        struct epoll_event _events[MAXEPOLLSIZE];
        int _kernel_event_backing_store_fd;
    };

}}}
#endif	/* _MULTICASTEPOLLSOURCE_H */

