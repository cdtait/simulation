#ifndef _MULTICASTSOURCE_H
#define	_MULTICASTSOURCE_H

#include <cstdlib>
#include <iostream>

#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>

#include <cstring>
#include <cstdlib>

#include <vector>
#include <string>
#include <map>
#include <math.h>
#include <list>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <sys/resource.h>

#include <boost/asio.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>
#include <boost/lexical_cast.hpp>
#include "common/logging/logging_util.h"
#include "common/entities/entity_types.h"
#include "common/net/pcap/pcap_adapter.h"

#include "common/primitives/ptime.h"
#include "common/primitives/pbytes.h"
#include "common/xml/xml_config.h"
#include "common/arguments/arguments.h"
#include "common/xml/xml_config.h"
#include "common/net/stream.h"
#include "common/net/stream_producer.h"

namespace common {
namespace net {
namespace socket {

    struct SocketEventDef {
        boost::asio::ip::udp::socket* socket;
        struct epoll_event ev;
    };

    #define MAXBUF 1024
    #define MAXEPOLLSIZE 10

    /**
    * @brief Very simple multicast source. Uses blocking call on epoll library.
    */
    class multicast_producer : public stream_producer {

    public:
        multicast_producer(xml_config & config) :
        _logger(Logger::getLogger("MulticastSource")),
        _data(BUFFER_SIZE),
        _kernel_event_backing_store_fd(-1),
        _curfds(0)
        {
           ::memset(_events,'\0',MAXEPOLLSIZE);
        }

        ~multicast_producer() {
        }

        inline void setStreams(const stream_list & streams, int optimize = 1) {

            LOG_INFO(_logger, "Subscribing to snapshot and delta streams");
            _kernel_event_backing_store_fd = epoll_create(MAXEPOLLSIZE);

            // Create socket connection
            // Walk round the filter string extracting the mcast address/port
            // for each product and then join the mcast group for each

            streams::const_iterator end = streams.getStreams().end();

            for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
                const stream & stream = (*it);
                int multicast_port = atoi(stream.port.c_str());
                // Create the socket so that multiple may be bound to the same address.
                SocketEventDef * sock_event_def = new SocketEventDef;

                sock_event_def->socket = new boost::asio::ip::udp::socket(io_service);
                boost::asio::ip::address_v4 multicast_address(boost::asio::ip::address_v4::from_string(stream.address));
                boost::asio::ip::udp::endpoint listen_endpoint(multicast_address, multicast_port);

                sock_event_def->socket->open(listen_endpoint.protocol());
                sock_event_def->socket->set_option(boost::asio::ip::udp::socket::reuse_address(true));
                sock_event_def->socket->bind(listen_endpoint);

                boost::asio::ip::address_v4 network_interface(get_interface_address_from_name(stream.interface, sock_event_def->socket));
                
                // Join the multicast group.
                boost::asio::ip::multicast::join_group option(multicast_address, network_interface);
                sock_event_def->socket->set_option(option);

                std::string group = stream.address + ":" + stream.port;
                _socketMap[group] = sock_event_def;

                // register with select or epoll

                boost::asio::socket_base::non_blocking_io command(true);
                sock_event_def->socket->io_control(command);

                sock_event_def->ev.events = EPOLLIN | EPOLLET;
                sock_event_def->ev.data.fd = sock_event_def->socket->native();

                if (epoll_ctl(_kernel_event_backing_store_fd, EPOLL_CTL_ADD, sock_event_def->ev.data.fd, &sock_event_def->ev) < 0) {
                    LOG_ERROR(_logger,"Could not control event descriptor:" << sock_event_def->ev.data.fd << " error:" << strerror(errno));
                }
                else {
                    _curfds++;
                }
            }
        }

        inline void addStream(const stream & stream) {
            LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

            std::string group = stream.address + ":" + stream.port;
//            int type = atoi(stream.type.c_str());

            int multicast_port = atoi(stream.port.c_str());

            SocketEventDef * sock_event_def = new SocketEventDef;

            sock_event_def->socket = new boost::asio::ip::udp::socket(io_service);
            boost::asio::ip::address_v4 multicast_address(boost::asio::ip::address_v4::from_string(stream.address));
            boost::asio::ip::udp::endpoint listen_endpoint(multicast_address, multicast_port);

            sock_event_def->socket->open(listen_endpoint.protocol());
            sock_event_def->socket->set_option(boost::asio::ip::udp::socket::reuse_address(true));
            sock_event_def->socket->bind(listen_endpoint);

            boost::asio::ip::address_v4 network_interface(get_interface_address_from_name(stream.interface, sock_event_def->socket));

            // Join the multicast group.
            boost::asio::ip::multicast::join_group option(multicast_address, network_interface);
            sock_event_def->socket->set_option(option);

            _socketMap[group] = sock_event_def;

            // register with select or epoll

            boost::asio::socket_base::non_blocking_io command(true);
            sock_event_def->socket->io_control(command);

            sock_event_def->ev.events = EPOLLIN | EPOLLET;
            sock_event_def->ev.data.fd = sock_event_def->socket->native();

            if (epoll_ctl(_kernel_event_backing_store_fd, EPOLL_CTL_ADD, sock_event_def->ev.data.fd, &sock_event_def->ev) < 0) {
                LOG_ERROR(_logger,"Could not control event descriptor:" << sock_event_def->ev.data.fd << " error:" << strerror(errno));
            }
            else {
                _curfds++;
            }
        }

        inline void removeStream(const stream & stream) {
            LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

            std::string group = stream.address + ":" + stream.port;

            SocketMap::const_iterator it = _socketMap.find(group);
            if(it != _socketMap.end()) {
                SocketEventDef * sock_event_def = it->second;
                sock_event_def->socket->close();
                _socketMap.erase(group);
                _curfds--;
            }
        }

        inline boost::asio::ip::address_v4 get_interface_address_from_name(const std::string & interface_name, boost::asio::ip::udp::socket * socket) {
            boost::asio::ip::address_v4 interface = boost::asio::ip::address_v4::any();
            std::string name = interface_name;

            LOG_INFO(_logger, "Searching for interface " << name);

            if (name != "") {
                struct ifconf ifc;
                char buff[1024];
                struct ifreq *ifr;
                int i;
                ifc.ifc_len = sizeof (buff);
                ifc.ifc_buf = buff;

                if (ioctl(socket->native(), SIOCGIFCONF, &ifc) >= 0) {
                    ifr = ifc.ifc_req;
                    for (i = ifc.ifc_len / sizeof (struct ifreq); --i >= 0; ifr++) {
                        if (ifr->ifr_name == name) {
                            LOG_INFO(_logger, "Found device: " << ifr->ifr_name);
                            struct sockaddr add = ifr->ifr_addr;
                            //name = add.sa_data;
                            break;
                        }
                    }
                } else {
                    LOG_INFO(_logger, "SIOCGIFCONF:Failed");
                }
                interface = boost::asio::ip::address_v4::from_string(name);
            }
            return interface;
        }

        pbytes * produce() {
            LOG_TRACE(_logger, "Listening for events...");

            /* Wait for an event(s) */
            int nfds = epoll_wait(_kernel_event_backing_store_fd, _events, _curfds, -1);

            if (nfds == -1) {
                perror("epoll_wait");
                return NULL;
            }

            int acclen = 0;
            char buf[MAXBUF + 1];
            int len;
            /* Intialize buffer */
            ::memset(buf, '\0', MAXBUF + 1);

            /* Wheech roon aw ra descriptars we goat events fur */
            for (int n = 0; n < nfds; ++n) {
                    /* recv on a ready socket */
                    len = recv(_events[n].data.fd, buf, BUFFER_SIZE, 0);

                    if (len > 0) {
                        LOG_DEBUG(true,_logger, _events[n].data.fd << " buffer:'" << putils::to_hex(buf,len) << "" << len << "\n");
                    }
                    else {
                        if (len < 0) {
                            LOG_ERROR(_logger,"No data in buffer for error " << errno << "，error message'" << strerror(errno) << "'\n");
                            if (errno != EWOULDBLOCK) {
                                close(_events[n].data.fd);
                                // Non NULL event for older kernels, should be allowed NULL from 2.6.9 onwards
                                struct epoll_event ev;
                                epoll_ctl(_kernel_event_backing_store_fd, EPOLL_CTL_DEL, _events[n].data.fd,&ev);
                                _curfds--;
                            }
                        }
                    }

                    ::memcpy(_data._value + acclen,buf,len);
                    acclen += len;

                    // Keep addiing to the data buffer from each message
                    _data.set_length(acclen);
                    _data.stamp();
            }


            LOG_TRACE(_logger, "Message received [" << len << "]");

            return &_data;
        }

        void start() {
            pbytes * data = NULL;

            long l = 0;

            timespec time1;
            timespec time2;

            clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time1);

            while ((data = produce()) != NULL) {
                l++;
                LOG_DEBUG(true,_logger, "Message no:" << l << " bytes sent\n" << putils::to_hex(data->get_value(), data->get_length()) << "\n/" << data->get_length());

            }

            clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time2);
        }

    private:
        static const int BUFFER_SIZE = 64 * 1024;
        LoggerPtr _logger;
        std::string _device;

        typedef std::map<std::string, SocketEventDef*> SocketMap;
        SocketMap _socketMap;
        boost::asio::io_service io_service;
        pbytes _data;
        struct epoll_event _events[MAXEPOLLSIZE];
        int _kernel_event_backing_store_fd;
        int _curfds;
    };

}}}

#endif	/* _MULTICASTSOURCE_H */

