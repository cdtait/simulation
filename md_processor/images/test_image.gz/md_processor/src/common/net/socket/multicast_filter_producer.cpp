/*
 * File:   MulticastFilterSource.cpp
 * Author: Jock Strap
 *
 */

#include "multicast_filter_producer.h"
#include "socket_address.h"

namespace common { namespace net { namespace socket {

socklen_t multicast_filter_producer::socklen = sizeof(struct sockaddr_in);

multicast_filter_producer::multicast_filter_producer(xml_config & config) :
_logger(Logger::getLogger("MulticastFilterSource"))
{
        FD_ZERO(&_socks);
        _timeout.tv_sec = 0;
        _timeout.tv_usec = 500000;
        data_cache_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        data_array = (pbytes**)new pbytes*[MAXSELECTSIZE+1];
        
        for (int i=0; i < MAXSELECTSIZE; i++) {
                data_cache_array[i] = new pbytes(MAXBUF);
                data_array[i] = NULL;
        }
                       
        data_cache_array[MAXSELECTSIZE] = NULL;
        data_array[MAXSELECTSIZE] = NULL;
}

multicast_filter_producer::~multicast_filter_producer() {
}
        
void multicast_filter_producer::setStreams(const stream_list & streams, int optimize) {

    // Create socket connection
    // Walk round the filter string extracting the mcast address/port
    // for each product and then join the mcast group for each
            
    streams::const_iterator end = streams.getStreams().end();

    for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
        const stream & stream = (*it);
        addStream(stream);
    }
}

void multicast_filter_producer::addStream(const stream & stream) {
    LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");
    std::string group = stream.address + ":" + stream.port;
    int multicast_port = atoi(stream.port.c_str());

    socket_address * sock_address = NULL;

    SocketMap::const_iterator it = _socketMap.find(group);

    // Have we already got a socket for this port?
    if (it == _socketMap.end()) {
        // No? Well create the socket
        sock_address =  new socket_address;
        sock_address->count = 1;
        sock_address->fd = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);

        memset((char *) & sock_address->listen_address, 0, sizeof(sock_address->listen_address));
        sock_address->listen_address.sin_family = AF_INET;
        sock_address->listen_address.sin_port = htons(multicast_port);
        sock_address->listen_address.sin_addr.s_addr = inet_addr(stream.address.c_str());

        LOG_INFO(_logger,"Adding socket with fd:" << sock_address->fd << " on " << group);

        int status = bind(sock_address->fd, (struct sockaddr *)&sock_address->listen_address, sizeof(struct sockaddr_in));
        
        LOG_INFO(_logger,"Binding socket fd:" << sock_address->fd << " on port:" << multicast_port << " status:" << status);

        int reuse = 1;
        status = setsockopt(sock_address->fd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));

        LOG_INFO(_logger,"Setting reuse on the socket fd:" << sock_address->fd << " on " << group);

        _sockets[sock_address->fd] = sock_address;

        int flags;

    	#if defined(O_NONBLOCK)
        if (-1 == (flags = fcntl(sock_address->fd, F_GETFL, 0)))
            flags = 0;
        	fcntl(sock_address->fd, F_SETFL, flags | O_NONBLOCK);
    	#else
        	flags = 1;
        	ioctl(sock_address->fd, FIOBIO, &flags);
    	#endif

        FD_SET(sock_address->fd,&_socks);

        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        status = setsockopt(sock_address->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));

        _socketMap[group] = sock_address;
    }
    else {
        // Yes? Then share the socket address
        sock_address = it->second;
        sock_address->count++;
    }
}

 void multicast_filter_producer::removeStream(const stream & stream) {
    LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

    std::string group = stream.address + ":" + stream.port;

    SocketMap::const_iterator it = _socketMap.find(group);

    if (it != _socketMap.end()) {
    	socket_address * sock_address = it->second;
        struct ip_mreq multicast_address;
        memset((char *) &multicast_address, 0, sizeof(multicast_address));

        multicast_address.imr_multiaddr.s_addr = inet_addr(stream.address.c_str());
        multicast_address.imr_interface.s_addr = inet_addr(stream.interface.c_str());

        setsockopt(sock_address->fd, IPPROTO_IP, IP_DROP_MEMBERSHIP,(const void *)&multicast_address, sizeof(struct ip_mreq));
        _socketMap.erase(group);

        if (sock_address->count==1) {

            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            int multicast_port = atoi(stream.port.c_str());
            LOG_INFO(_logger,"Clearing descriptor:" << sock_address->fd);
            FD_CLR(sock_address->fd,&_socks);
            LOG_INFO(_logger,"Closing socket:" << sock_address->fd);
            close(sock_address->fd);
            sock_address->count--;
            LOG_INFO(_logger,"Removing from sockets[" << multicast_port << "]");
            _sockets.erase(sock_address->fd);

            delete sock_address;
        }
        else {
            sock_address->count--;
        }
    }
}
}}}

