
#include "pcap_adapter_exception.h"

namespace common {
namespace net {
namespace pcap {

pcap_adapter_exception::pcap_adapter_exception(const char * message) : base_exception(message) {
    // TODO Auto-generated constructor stub
}

pcap_adapter_exception::pcap_adapter_exception(const char * message,const char * buffer) : base_exception((std::string(message)+" - "+buffer).c_str()) {
    // TODO Auto-generated constructor stub
}

pcap_adapter_exception::~pcap_adapter_exception() throw () {
    // TODO Auto-generated destructor stub
}

}}}
