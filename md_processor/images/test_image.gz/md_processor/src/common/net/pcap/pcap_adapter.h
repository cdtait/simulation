
#ifndef PCAP_ADAPTER_H_
#define PCAP_ADAPTER_H_

#include <pcap.h>
#include <pcap-bpf.h>
#include <pcap/sll.h>
#include <signal.h>
#include <exception>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip.h>
#include <netinet/ether.h>
#include <net/if.h>
#include <net/ethernet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <iostream>
#include <cstring>
#include <cstdlib>

#include <log4cxx/logger.h>
#include <log4cxx/xml/domconfigurator.h>
#include <log4cxx/ndc.h>

using namespace std;
using namespace log4cxx;
using namespace log4cxx::helpers;
using namespace log4cxx::xml;

#include "pcap_adapter_exception.h"

#include "common/primitives/putils.h"
#include "common/primitives/pbytes.h"
#include "common/logging/logging_util.h"
#include "common/net/stream.h"

namespace common {
	namespace net {
		namespace pcap {
		/**
		* @brief Generic Pcap adapter for UDP and TCP packets. Allows filtering, properties and different device types.
		*/
			class pcap_adapter {
			public:
				typedef pbytes PCapData;
				static LoggerPtr logger;
				const static int DEFAULT_SNAPLEN = 65535;

				/**
				 * Construct the adapter.
				 * @param devOrFileName
				 * @param snapLength
				 * @param promisc
				 * @param timeOut
				 * @return
				 */
				pcap_adapter(const char * devOrFileName = NULL,
						const char * filter = NULL,
						int snapLength = DEFAULT_SNAPLEN,
						bool promisc = true,
						int timeOut = 500) :

				data(DEFAULT_SNAPLEN),
				_packetCaptureHandle(NULL),
				_devOrFileName(NULL),
				_netFilter(NULL),
				_linkLayerLength(ETH_HLEN)
				{
					reset(devOrFileName, filter, snapLength, promisc, timeOut);
					data_array[0] = NULL;
					data_array[1] = NULL;
				}

				/**
				 * Construct the adapter.
				 * @param devOrFileName
				 * @param snapLength
				 * @param promisc
				 * @param timeOut
				 * @return
				 */
				void reset(const char * devOrFileName = NULL,
						const char * filter = NULL,
						int snapLength = DEFAULT_SNAPLEN,
						bool promisc = true,
						int timeOut = 500) {

					if (devOrFileName && _devOrFileName) {
						delete _devOrFileName;
						_devOrFileName = NULL;
					}
					if (filter && _netFilter) {
						delete _netFilter;
						_netFilter = NULL;
					}
					if (_packetCaptureHandle) {
						pcap_close(_packetCaptureHandle);
					}

					NDC::push("PcapAdapter::reset context");

					const char *pname = _devOrFileName;

					if (!devOrFileName && !_devOrFileName) {
						pname = pcap_lookupdev(_errorBuffer);
						if (pname == NULL) {
							throw pcap_adapter_exception(_errorBuffer);
						}
					} else {
						pname = devOrFileName ? devOrFileName : _devOrFileName;
					}

					_packetCaptureHandle = pcap_open_offline(pname, _errorBuffer);

					if (!_packetCaptureHandle) {
						_packetCaptureHandle = pcap_open_live(pname, snapLength, promisc, timeOut, _errorBuffer);
					}

					if (!_packetCaptureHandle) {
						throw pcap_adapter_exception("Could not find pcap device or file", _errorBuffer);
					}

					_devOrFileName = strdup(pname);
					LOG4CXX_INFO(logger, "[name:" + string(_devOrFileName) + "]");

					_netFilter = strdup("");
					_linkLayerType = pcap_datalink(_packetCaptureHandle);

					if (_linkLayerType == DLT_LINUX_SLL) {
						_linkLayerLength = SLL_HDR_LEN;
						LOG4CXX_INFO(logger, "Changed _linkLayerLength to cooked :" << _linkLayerLength << " " << pcap_datalink_val_to_name(_linkLayerType));
					}

					if (filter) {
						setFilter(filter);
					}

					LOG4CXX_INFO(logger, "Reset done.");

					NDC::pop();
				}

				/**
				 * Destroy and cleanup
				 * @return
				 */
				virtual ~pcap_adapter() {
					if (_netFilter) {
						delete _netFilter;
					}
					if (_packetCaptureHandle) {
						pcap_close(_packetCaptureHandle);
					}
				}

				inline u_char * nextDataItem(struct pcap_pkthdr *hdr) {
					return (u_char *) pcap_next(_packetCaptureHandle, hdr);
				}

				inline int getSnaplength() {
					return pcap_snapshot(_packetCaptureHandle);
				}

				inline int getLinkLayerType() {
					return _linkLayerType;
				}

				inline char * getFilter() {
					return _netFilter;
				}

				inline void setFilter(const char* value, int optimize = 1) {
					bpf_program fcode;
					::free(_netFilter);
					_netFilter = strdup(value);

					if (pcap_compile(_packetCaptureHandle, &fcode, _netFilter, optimize, 0) < 0) {
						throw pcap_adapter_exception("Falied to compile pcap", pcap_geterr(_packetCaptureHandle));
					}
					if (pcap_setfilter(_packetCaptureHandle, &fcode) < 0) {
						throw pcap_adapter_exception("Falied to set filter for pcap", pcap_geterr(_packetCaptureHandle));
					}

					pcap_freecode(&fcode);
				}

				virtual inline void setStreams(const stream_list & streams, int optimize = 1) {
					setFilter(streams.getFilter().c_str(), optimize);
				}

				inline int getFileno(pcap_t *pcap) {
					FILE *f = pcap_file(pcap);

					if (f != NULL) {
						return (fileno(f));
					} else {
						return (pcap_fileno(pcap));
					}
				}

				inline void setNonblock(pcap_t *pcap, int nonblock, char *ebuf) {
					pcap_setnonblock(pcap, nonblock, ebuf);
				}

				inline int getNonblock(pcap_t *pcap, char *ebuf) {
					return (pcap_getnonblock(pcap, ebuf));
				}

				inline int getDatalink() {
					return pcap_datalink(_packetCaptureHandle);
				}

				pbytes ** produce() {
					packet = nextDataItem(&header);

					if (packet) {
						extractData(&header, packet, data, _linkLayerLength);
						data_array[0] = &data;
						return data_array;
					} else {
						data_array[0] = NULL;
						return data_array;
					}
				}

				static void extractData(const struct pcap_pkthdr *header,
					const unsigned char *packet, PCapData & data, int linkLayerLength) {

					if (packet) {
						// TODO Is this the best thing to do here does it incur a big penalty?
						if (header) {
							data.stamp(header->ts);
						}

						const struct ip *ip = (struct ip *) (packet + linkLayerLength);
						int size_ip = (ip->ip_hl & 0x0f) * 4;

						int protocolHeader;

						if (ip->ip_p == IPPROTO_TCP) {
							const struct tcphdr *tcp = (struct tcphdr *) (packet + linkLayerLength + size_ip);
							protocolHeader = (tcp->doff & 0x0f) * 4;
							data._value = (unsigned char *) (packet + linkLayerLength + size_ip + protocolHeader);
							data.set_length(ntohs(ip->ip_len) - (size_ip + protocolHeader));

						} else if (ip->ip_p == IPPROTO_UDP) {
							udphdr *uh = (udphdr *) ((unsigned char *) ip + size_ip);
							protocolHeader = sizeof (*uh);
							data._value = (unsigned char *) (packet + linkLayerLength + size_ip + protocolHeader);
							data.set_length(ntohs(ip->ip_len) - (size_ip + protocolHeader));
						}
					}
				}

				PCapData & getData() {
					return data;
				}

				struct pcap_pkthdr & getHeader() {
					return header;
				}

				u_char * getPacket() {
					return packet;
				}

				pcap_t * getHandle() {
					return _packetCaptureHandle;
				}

				static std::string dumpAsHex(PCapData pCapData) {
					return putils::to_hex(pCapData.get_value(), pCapData.get_length());
				}

			private:
				PCapData data;
				pcap_t *_packetCaptureHandle;
				char *_devOrFileName;
				char *_netFilter;
				char _errorBuffer[256];
				int _linkLayerType;
				struct pcap_pkthdr header;
				u_char * packet;
				pbytes * data_array[2];
				int _linkLayerLength;
			};

		}
	}
}

#endif /* PCAP_ADAPTER_H_ */
