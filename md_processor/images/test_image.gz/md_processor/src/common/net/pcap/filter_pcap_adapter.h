
#ifndef FILTERPCAP_ADAPTER_H_
#define FILTERPCAP_ADAPTER_H_

#include <map>
#include <boost/asio.hpp>
#include "pcap_adapter.h"
#include "common/logging/logging_util.h"

namespace common {
	namespace net {
		namespace pcap {

		/**
		 * @brief A Pcap adapter with allows range filtering of packet sequence numbers.
		 */
			class filter_pcap_adapter : public pcap_adapter {
			public:

				/**
				 * Construct the adapter.
				 * @param minPacketSeqNum,
				 * @param maxPacketSeqNum,
				 * @param outFile,
				 * @param devOrFileName
				 * @param snapLength
				 * @param promisc
				 * @param timeOut
				 * @return
				 */
				filter_pcap_adapter(const int minPacketSeqNum,
						const int maxPacketSeqNum,
						const char * outFile,
						const char * devOrFileName,
						const char * filter = NULL,
						int snapLength = DEFAULT_SNAPLEN,
						bool promisc = true,
						int timeOut = 500) :

							pcap_adapter(devOrFileName, filter, snapLength, promisc, timeOut),
				_minPacketSeqNum(minPacketSeqNum),
				_maxPacketSeqNum(maxPacketSeqNum),
				_tracker(0)
				{
					_logger = Logger::getLogger("common.net.pcap.FilterPcapAdapter");
					LOG_INFO(_logger, "_minPacketSeqNum:" << _minPacketSeqNum);
					LOG_INFO(_logger, "_maxPacketSeqNum:" << _maxPacketSeqNum);
					_dumper = pcap_dump_open(getHandle() , outFile);
				}

				/**
				 * Destroy and cleanup
				 * @return
				 */
				~filter_pcap_adapter() {
					pcap_dump_close(_dumper);
				}

				template<typename consumer>
				void produce(consumer & c) {
				   pbytes * pb = pcap_adapter::produce();
				   _tracker++;

				   u_char * p = getPacket();

				   if (p && _tracker >= _minPacketSeqNum && _tracker <= _maxPacketSeqNum) {
					pcap_dump((u_char*)_dumper,&getHeader(),p);
					pcap_dump_flush(_dumper);
				   }

				   c.consume(pb);
				   //return pb;
				}

			private:
				LoggerPtr _logger;
				int _minPacketSeqNum;
				int _maxPacketSeqNum;
				int _tracker;
				pcap_dumper_t * _dumper;
			};
		}
	}
}

#endif /* FILTERPCAP_ADAPTER_H_ */
