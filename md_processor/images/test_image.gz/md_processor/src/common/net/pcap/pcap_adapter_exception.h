#ifndef PCAP_ADAPTER_EXCEPTION_H_
#define PCAP_ADAPTER_EXCEPTION_H_

#include "common/logging/logging_util.h"

namespace common {
namespace net {
namespace pcap {

/**
* @brief Defines an exception that can be thrown by and adapter.
*/
class pcap_adapter_exception : public base_exception {
public:
	pcap_adapter_exception(const char * message);
	pcap_adapter_exception(const char * message,const char * buffer);
    virtual ~pcap_adapter_exception() throw ();
};

}}}

#endif /* PCAP_ADAPTER_EXCEPTION_H_ */
