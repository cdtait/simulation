
#ifndef MULTICASTPCAP_ADAPTER_H_
#define MULTICASTPCAP_ADAPTER_H_

#include <map>
#include <boost/asio.hpp>
#include "pcap_adapter.h"
#include "common/net/stream.h"
#include "common/net/stream_producer.h"
#include "common/logging/logging_util.h"


namespace common {
	namespace net {
		namespace pcap {
		/**
		  * @brief A Pcap adapter spcific for multicast streams.
		  */
			class multicast_pcap_adapter : public pcap_adapter, public stream_producer {
			public:

				/**
				 * Construct the adapter.
				 * @param devOrFileName
				 * @param snapLength
				 * @param promisc
				 * @param timeOut
				 * @return
				 */
				multicast_pcap_adapter(const char * devOrFileName,
						const char * filter = NULL,
						int snapLength = DEFAULT_SNAPLEN,
						bool promisc = true,
						int timeOut = 500) :

							pcap_adapter(devOrFileName, filter, snapLength, promisc, timeOut)
				{
					_logger = Logger::getLogger("common.net.pcap.MulticastPcapAdapter");
					LOG_INFO(_logger, "devOrFileName:" << devOrFileName);
					LOG_INFO(_logger, "dataFilter:" << filter);
				}

				/**
				 * Destroy and cleanup
				 * @return
				 */
				~multicast_pcap_adapter() { }

				inline void setStreams(const stream_list & streams, int optimize = 1) {

					LOG_INFO(_logger, "Subscribing to snapshot and delta streams");

					setFilter(streams.getFilter().c_str(), optimize);

					// Create socket connection
					// Walk round the filter string extracting the mcast address/port
					// for each product and then join the mcast group for each

					streams::const_iterator end = streams.getStreams().end();

					for (streams::const_iterator it = streams.getStreams().begin(); it != end; ++it) {
						const stream & stream = (*it);

						std::string group = stream.address + ":" + stream.port;

						int multicast_port = atoi(stream.port.c_str());
						// Create the socket so that multiple may be bound to the same address.
						boost::asio::ip::udp::socket * socket = new boost::asio::ip::udp::socket(io_service);
						boost::asio::ip::address_v4 multicast_address(boost::asio::ip::address_v4::from_string(stream.address));
						boost::asio::ip::udp::endpoint listen_endpoint(multicast_address, multicast_port);

						socket->open(listen_endpoint.protocol());
						socket->set_option(boost::asio::ip::udp::socket::reuse_address(true));
						socket->bind(listen_endpoint);

						boost::asio::ip::address_v4 network_interface(get_interface_address_from_name(stream.interface, socket));

						LOG_INFO(_logger, "Subscribing to [" << multicast_address << "," << stream.interface << "]");

						// Join the multicast group.
						boost::asio::ip::multicast::join_group option(multicast_address, network_interface);
						socket->set_option(option);

						_socketMap[group] = socket;
					}
				}

				inline void addStream(const stream & stream) {
					LOG_INFO(_logger, "Subscribing to stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

					std::string group = stream.address + ":" + stream.port;
//                        int type = atoi(stream.type.c_str());

					int multicast_port = atoi(stream.port.c_str());
					// Create the socket so that multiple may be bound to the same address.
					boost::asio::ip::udp::socket * socket = new boost::asio::ip::udp::socket(io_service);
					boost::asio::ip::address_v4 multicast_address(boost::asio::ip::address_v4::from_string(stream.address));
					boost::asio::ip::udp::endpoint listen_endpoint(multicast_address, multicast_port);

					socket->open(listen_endpoint.protocol());
					socket->set_option(boost::asio::ip::udp::socket::reuse_address(true));
					socket->bind(listen_endpoint);

					boost::asio::ip::address_v4 network_interface(get_interface_address_from_name(stream.interface, socket));

					// Join the multicast group.
					boost::asio::ip::multicast::join_group option(multicast_address, network_interface);
					socket->set_option(option);

					_socketMap[group] = socket;
				}

				inline void removeStream(const stream & stream) {
					LOG_INFO(_logger, "Unsubscribing from stream [" << stream.address << "," << stream.port << "," << stream.tag << "," << stream.type << "," << stream.interface << "]");

					std::string group = stream.address + ":" + stream.port;
//                        int type = atoi(stream.type.c_str());

					SocketMap::const_iterator it = _socketMap.find(group);
					if(it != _socketMap.end()) {
						boost::asio::ip::udp::socket * socket = it->second;
						socket->close();
						_socketMap.erase(group);
					}
				}

				inline boost::asio::ip::address_v4 get_interface_address_from_name(const std::string & interface_name, boost::asio::ip::udp::socket * socket) {
					boost::asio::ip::address_v4 interface = boost::asio::ip::address_v4::any();
					std::string name = interface_name;

					if (name != "") {
						struct ifconf ifc;
						char buff[1024];
						struct ifreq *ifr;
						int i;
						ifc.ifc_len = sizeof (buff);
						ifc.ifc_buf = buff;

						if (ioctl(socket->native(), SIOCGIFCONF, &ifc) >= 0) {
							ifr = ifc.ifc_req;
							for (i = ifc.ifc_len / sizeof (struct ifreq); --i >= 0; ifr++) {
								if (ifr->ifr_name == name) {
									LOG_INFO(_logger, "Found device: " << ifr->ifr_name);
									//struct sockaddr add = ifr->ifr_addr;
									//name = add.sa_data;
									break;
								}
							}
						} else {
							LOG_INFO(_logger, "SIOCGIFCONF:Failed");
						}
						interface = boost::asio::ip::address_v4::from_string(name);
					}
					return interface;
				}

				void run() {
					io_service.run();
				}

			private:
				typedef std::map<std::string, boost::asio::ip::udp::socket*> SocketMap;

				SocketMap _socketMap;
				boost::asio::io_service io_service;
				LoggerPtr _logger;
			};
		}
	}
}

#endif /* PCAP_ADAPTER_H_ */
