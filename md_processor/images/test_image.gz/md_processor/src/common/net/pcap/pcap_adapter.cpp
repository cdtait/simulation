
#include "pcap_adapter.h"

namespace common {
namespace net {
namespace pcap {
    LoggerPtr pcap_adapter::logger = Logger::getLogger("PcapLogger");
}}}

