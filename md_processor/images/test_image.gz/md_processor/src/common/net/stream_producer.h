
#ifndef stream_producer_h_
#define stream_producer_h_

#include "stream.h"


/**
 * @brief Template to define what a stream source should do.
 */
class stream_producer {
public:
		stream_producer() {
        }
        
		virtual ~stream_producer() {
        }

        virtual void setStreams(const stream_list & streams, int optimize = 1) = 0;
        virtual void addStream(const stream & stream) = 0;
        virtual void removeStream(const stream & stream) = 0;
};

#endif /* stream_producer_h_ */
