#include <cstdlib>
#include <csignal>
#include <iostream>
#include "system.h"
#include "common/logging/profiler.h"
#include "common/primitives/ptime.h"


system::service_list system::_services;

void system::init() {
	signal(SIGINT, term);
	signal(SIGTERM, term);
}

void system::startup() {
	service_list::const_iterator end = system::_services.end();
	for (service_list::const_iterator it = system::_services.begin(); it != end; ++it) {
		(*it)->start();
	}
}

void system::shutdown() {
	service_list::const_iterator end = system::_services.end();
	for (service_list::const_iterator it = system::_services.begin(); it != end; ++it) {
		(*it)->stop();
	}

	profiler::dumphtml();
	ptime::nanosleep(1000 * 1000 * 1000);
}

void system::addService(service * service) {
	system::_services.push_back(service);
}

void system::term(int sig) {
	system::shutdown();
	exit(0);
}

