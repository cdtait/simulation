#ifndef __SYSTEM_H
#define	__SYSTEM_H

#include <vector>
#include "service.h"


/**
 * @brief Java-like convenience class for managing the startup and
 * shutdown of the engine with support for the registration of
 * services.
 */
class system {
public:

	static void init();
	static void startup();
	static void shutdown();
	static void addService(service * service);

private:
	static void term(int sig);

	typedef std::vector<service *> service_list;
	static service_list _services;
};



#endif	/* _SYSTEM_H */

