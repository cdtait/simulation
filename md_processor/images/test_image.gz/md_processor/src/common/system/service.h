#ifndef _SERVICE_H
#define	_SERVICE_H


/**
 * @brief An abstract class providing a common interface for top-level components
 * such as market data providers and exchanges.
 */
class service {
public:

	virtual ~service() { }

	virtual void start() = 0;
	virtual void stop() = 0;
	virtual void reset() = 0;
};



#endif	/* _SERVICE_H */

