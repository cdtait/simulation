
#ifndef ARGUMENTS_H_
#define ARGUMENTS_H_

#include "argument_options.h"
#include <stdarg.h>
#include <iostream>
#include <vector>

/**
 * @brief Convenience class to read in argument options from the process command line and return a value from an option name.
 */
class arguments {
public:
	arguments();
	arguments(int argc, char**argv);
	arguments(char*argv1,char*argv2=0,char*argv3=0,
			char*argv4=0,char*argv5=0,char*argv6=0,
			char*argv7=0,char*argv8=0,char*argv9=0);
	arguments(const std::vector<std::string> & args);
	virtual ~arguments();

	char ** testArgv();
	int intValue(const char* name);
	std::string stringValue(const char* name);
	long longValue(const char* name);
	double doubleValue(const char* name);
	void addOption(const char* name,
            const char* vs,
            const char* description);

	std::string __str();

private:
	argument_options _options;
};


#endif /* ARGUMENTS_H_ */
