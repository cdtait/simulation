
#ifndef ARGUMENTOPTIONS_H_
#define ARGUMENTOPTIONS_H_

#include <boost/program_options.hpp>

namespace po = boost::program_options;

/**
 * @brief Handle process argument options. Effectively checks with the expected input
 * format and converts argument values to correct variable types.
 */
class argument_options {
	friend std::ostream &operator<<(std::ostream &stream,const argument_options & argOptions);
public:
	argument_options();
	argument_options(int argc, char* argv[]);
	virtual ~argument_options();

	void setArgs(int argc, char* argv[]);
	void
	add(const char* name,
	            const char* vs,
	            const char* description);

	po::variable_value operator[](const char* name);
	po::options_description_easy_init addOptions();
	void parse();

private:
	po::options_description _desc;
	po::variables_map _vm;
	bool _parsed;
	int _argc;
	char** _argv;
	po::options_description_easy_init _desc_opts;
};

#endif /* ARGUMENTOPTIONS_H_ */
