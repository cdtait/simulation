
#include "argument_options.h"

#include <boost/program_options.hpp>

using namespace boost::program_options;

argument_options::argument_options() :
	_desc("Allowed options"), _parsed(false), _desc_opts(&_desc){
}

argument_options::argument_options(int argc, char* argv[]) :
	_desc("Allowed options"), _parsed(false), _desc_opts(&_desc) {
	setArgs(argc, argv);
}

void argument_options::setArgs(int argc, char* argv[]) {
	_argc = argc;
	_argv = new char*[argc + 1];

	for (int i = 0; argv[i] != NULL; i++) {
		int len = strlen(argv[i]);
		_argv[i] = new char[len + 1];
		strcpy(_argv[i], argv[i]);
	}
	_argv[argc] = NULL;
}

argument_options::~argument_options() {
	delete[] _argv;
}

void
argument_options::add(const char* name,
            const char* vs,
            const char* description)  {
	value_semantic* v = value<std::string>();

	if (strcmp(vs,"int")==0) {
		v = value<int>();
	}
	else
	if (strcmp(vs,"long")==0) {
		v = value<long>();
	}
	else
	if (strcmp(vs,"double")==0) {
		v = value<double>();
	}
	else
	if (strcmp(vs,"string")==0) {
		v = value<std::string>();
	}

	_desc_opts = _desc_opts(name,v,description);
}

variable_value argument_options::operator[](const char* name) {
	parse();
	return _vm[name];
}

options_description_easy_init argument_options::addOptions() {
	options_description_easy_init desc_opts = _desc.add_options();
	return desc_opts;
}

void argument_options::parse() {
	if (!_parsed) {
		store(parse_command_line(_argc, _argv, _desc), _vm);
		notify(_vm);
		_parsed=true;
	}
}

std::ostream &operator<<(std::ostream &stream,const argument_options & argOptions) {
	stream << argOptions._desc;
	return stream;
}

