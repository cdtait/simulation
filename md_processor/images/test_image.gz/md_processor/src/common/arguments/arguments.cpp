
#include "arguments.h"

#include <boost/program_options.hpp>
using namespace boost::program_options;
using namespace std;


char ** arguments::testArgv() {
int _argc;
char** _argv;
_argc=4;
_argv = new char*[_argc + 1];

_argv[0] = new char[5];
_argv[1] = new char[15];
_argv[2] = new char[15];
_argv[3] = new char[37];

_argv[_argc] = NULL;

::strcpy(_argv[0],"test");
_argv[0][4] = '\0';
::strcpy(_argv[1],"--anInteger=10");
_argv[1][14] = '\0';
::strcpy(_argv[2],"--aDouble=10.8");
_argv[2][14] = '\0';
::strcpy(_argv[3],"--aString=/path/to/xml/xmlconfig.xml");
_argv[3][36] = '\0';

return _argv;
}

arguments::arguments() {
}

arguments::arguments(int argc, char* argv[]) :
	_options(argc,argv) {
	//std::cerr << "arguments::arguments(int argc, char* argv[])" << std::endl;
}

arguments::arguments(char*argv1,char*argv2,char*argv3,
		char*argv4,char*argv5,char*argv6,
		char*argv7,char*argv8,char*argv9) {
	//std::cerr << "arguments::arguments(char*argv1," << std::endl;

	char** argv;
	int argc=1;

#define INC_ARGC(name) if (argv##name) {argc++;}

#define SET_ARGS(name) \
	if (argv##name) { \
		argv[name] = new char[strlen(argv##name)+1]; \
		::strcpy(argv[name],argv##name); \
		argv[name][strlen(argv##name)] = '\0'; \
	}

	INC_ARGC(1)INC_ARGC(2)INC_ARGC(3)
	INC_ARGC(4)INC_ARGC(5)INC_ARGC(6)
	INC_ARGC(7)INC_ARGC(8)INC_ARGC(9)

	argv = new char*[argc + 1];

	argv[0]=new char[5];
	::strcpy(argv[0],"test");
	argv[0][4] = '\0';

	SET_ARGS(1)SET_ARGS(2)SET_ARGS(3)
	SET_ARGS(4)SET_ARGS(5)SET_ARGS(6)
	SET_ARGS(7)SET_ARGS(8)SET_ARGS(9)

	argv[argc] = NULL;

	_options.setArgs(argc,argv);
}

arguments::arguments(const std::vector<std::string> & args) {
	std::cerr << "arguments::arguments(const std::vector<std::string> & args)" << std::endl;
	int argc = args.size()+1;
	char** argv = new char*[argc + 1];
	std::cerr << "args.length()" << argc << std::endl;
	std::cerr << "args.front()" << args.front() << std::endl;

	argv[0]=new char[5];
	::strcpy(argv[0],"test");
	argv[0][4] = '\0';

	for (int i = 1;i < argc;i++) {
		const string & s = args[i-1];
		std::cerr << "i=" << i << " s=" << s << std::endl;
		argv[i] = new char[s.length()+1];
		::strcpy(argv[i],s.c_str());
		argv[i][s.length()] = '\0';
	}

	argv[argc] = NULL;

	_options.setArgs(argc,argv);
}

/*
arguments::arguments(const std::vector<int> & args) {
	std::cerr << "arguments::arguments(const std::vector<int> & args)" << std::endl;
	int argc = args.size()+1;
	std::cerr << "args.length()" << argc << std::endl;
	std::cerr << "args.front()" << args.front() << std::endl;
}
*/

arguments::~arguments() {
}

int arguments::intValue(const char* name) {
	return _options[name].as<int>();
}

long arguments::longValue(const char* name) {
	return _options[name].as<long>();
}

double arguments::doubleValue(const char* name) {
	return _options[name].as<double>();
}

std::string arguments::stringValue(const char* name) {
	return _options[name].as<std::string>();
}

void arguments::addOption(const char* name,
        const char* vs,
        const char* description) {
	_options.add(name,vs,description);
}

std::string arguments::__str() {
  stringstream sout;
  sout<< _options;
  return sout.str();
}

