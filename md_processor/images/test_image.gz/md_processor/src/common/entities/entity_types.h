#ifndef _SCCR_COMMON_TYPES_H
#define	_SCCR_COMMON_TYPES_H

#include <assert.h>
#include <stdint.h>
#include <cstddef>
#include <iterator>
#include <array>
#include <map>
#include <unordered_map>
#include <vector>
#include <utility>
#include <numeric>
#include <algorithm>
#include <string>
#include <stdint.h>
#include <cstddef>

#include "common/primitives/pdecimal.h"
#include "common/primitives/ptime.h"

#define TOUCH 0     // OrderBookLevel zero
#define EMPTY 0
#define TWENTYFOUR_HOURS_IN_SECONDS 86400
#define DEFAULT_ORDER_ID_SIZE 16
#define DEFAULT_EXEC_ID_SIZE 16
#define DEFAULT_TIME_SIZE 16
#define DEFAULT_INSTRUMENT_ID_SIZE 16

typedef char ExecutionIdStr[DEFAULT_EXEC_ID_SIZE];
typedef char OrderIdStr[DEFAULT_ORDER_ID_SIZE];
typedef char InstrumentIdStr[DEFAULT_INSTRUMENT_ID_SIZE];

static const unsigned int WORKFLOW_NAME_LEN=24;
static const unsigned int SERIES_NAME_LEN=24;
static const unsigned int SIGNAL_NAME_LEN=16;

typedef double PnL;


enum ExchangeId {
	EXCHANGE_UNDEFINED=-1, EBS13 = 1, EBS14 = 2
};

enum Direction {
	LONG = 1, SHORT = 2, FLAT = 0, UNDEFINED = -1
};


enum BuySell {
	BUY = 1, SELL = 2,  NOSIDE = -1
};

/**
 *  @brief The enumerated side type as char Bid or Ask
 *
 */
enum class Side : char {
	Bid='B',
	Ask='S',
	Unknown='U'
};

enum MDType {
	NoType = -1, QuoteType = 0, MDTradeType = 1
};

enum Aggression {
	AGGRESSIVE=0, ACTIVE=1, NEUTRAL=2, PASSIVE=3
};

enum OrderStatus {
	// TODO - should PENDING_NEW actually be "NEW" or "PENDING"
	PENDING_NEW=0, ACCEPTED=1, REJECTED=2, PENDING_CANCEL=3, CANCELACCEPTED=4, CANCELREJECTED=5,
			CANCELCOMPLETED=6, DONE=7, NONE=-1
};

enum OrderCondition {
	VANILLA = 0, IMMEDIATE_OR_CANCEL = 1
};

enum FilledStatus {
	UNFILLED=0, PARTIALLY_FILLED=1, FILLED=2
};

enum InstrType {
	FUTURE=0, CALL=1, PUT=2
};

/**
 *  @brief The enumerated event type as char Add,Modify or Cancel
 *
 */
enum class Event : char {
	Add='A',
	Change='C',
	Delete='D',
	Overlay='O',
	Modify='Y',
	Cancel='X',
	Trade='T',
	Mid='M',
	Snapshot='S',
	Volume='V',
	Unknown='U'
};

/**
 *  @brief The enumerated print type as char text human readable output or csv
 *
 */
enum class PublishType : char {
	Trading='T',
	CSV='C',
	None='N',
	Unknown='U'
};


typedef decimal_type price_t;
typedef price_t tick_price_t;
typedef price_t trade_price_t;
typedef decimal_type tick_size_t;
typedef double AvgPrice;
typedef double MidPrice;
typedef std::string OrderId;
typedef std::string ExecutionId;
typedef uint32_t CntrId;
typedef uint32_t id_key_t;
typedef std::string InstrumentId;
typedef unsigned int Quantity;
typedef int SignedQuantity;
typedef Quantity OrderBookQuantity;
typedef Quantity OrderBookNumber;
typedef Quantity TradeQuantity;
typedef unsigned int Volume;
typedef Volume TradeVolume;
typedef Side OrderBookSide;
typedef Side TradeSide;
typedef unsigned int OrderBookLevel;
typedef unsigned int OrderBookPlaces;
typedef unsigned int Latency;
typedef unsigned int Pos;
typedef unsigned int TotalSize;
typedef unsigned int CapacitySize;
typedef double SignalValue;
typedef double MeanValue;
typedef char WorkflowName[WORKFLOW_NAME_LEN];
typedef char series_name_t[SERIES_NAME_LEN];
typedef char SignalName[SIGNAL_NAME_LEN];
typedef char Status[15];
typedef unsigned int PosIndex;
typedef long index_type;

// Predefine max levels. The BookMap,BookHash,BookVector are not themselves limited in level
// this limit is only here for copying or print convenience
constexpr uint32_t max_levels=20;
// Quantity as unsigned 32 bit, could be 16 and we get better vectorized performance
typedef uint32_t QuantityValueType;
// Order id as unsigned 32 bit
typedef uint32_t OrderIdKeyType;
// Price as unsigned 32 bit, represented in examples always as integer
// maybe replace with double PriceType below if required
typedef uint32_t PriceLevelKey;
// Price as double.
typedef double PriceType;
// 100 million order ids in day as example for range check
constexpr OrderIdKeyType max_order_id=1e8;
// 500 as example
constexpr QuantityValueType max_order_quantity=500;
// 2000 as example
constexpr PriceLevelKey max_order_price=2000;


OrderStatus string2OrderStatus(const std::string & s);
std::string orderStatus2String( OrderStatus s);

FilledStatus string2FilledStatus(const std::string & fs);
std::string filledStatus2String(FilledStatus fs);

Direction string2Direction(const std::string & d);
std::string direction2String(Direction d);

BuySell string2BuySell(const std::string & b);
std::string buySell2String(BuySell b);


/**
 *  @brief The order properties extracted from event
 *
 */
typedef struct {
	OrderIdKeyType orderid;
	Side side;
	QuantityValueType quantity;
	PriceLevelKey price;
} Order;

typedef std::vector<Order> Orders;

/**
 *  @brief The trade properties extracted from event
 *
 */
typedef struct {
	Side side;
	QuantityValueType quantity;
	PriceLevelKey price;
} Trade;

typedef std::vector<Trade> Trades;

/**
 *  @brief Pending match order
 *
 */
typedef struct {
	PriceLevelKey price;
	OrderIdKeyType orderid;
} PendingMatch;

// Arrays used to represent different types in BookData
template <int N> using IArrray = std::array<int, N>;
template <int N> using DArrray = std::array<double, N>;


/**
   *  @brief The BookData that is snap copied from OrderBook to publish
   *  or further processed
   *
   *  What we have here is a fixed memory chunk that should be efficient to transport
   *
   *  Could pack __attribute__((packed, aligned(8))) but may not add any efficiencies
   *  Could binary encode but again may not yield overall considering decode and network packet header
   *  If it goes on the wire internally infiniband RDMA  will work OK
   *
   *  @tparam  levels as int  defaults to 5
   *  structure we can use and defaults the BookMap.
   */
template <int levels=5>
struct BookData {
	BookData() = default;
	BookData(BookData&& b) = default;

	BookData&
    operator=(BookData&& b) = default;

	void set_event(Event event) {
		this->event=event;
	}

	void set_trade_price(trade_price_t tradePrice) {
		this->last_trade.price=tradePrice;
	}

	void set_trade_quantity(TradeQuantity tradeQuantity) {
		this->last_trade.quantity=tradeQuantity;
	}

	void set_trade_side(TradeSide tradeSide) {
		this->last_trade.side=tradeSide;
	}

	void set_exchange_time(nano_time_t exchange_time) {
		this->exchange_time=exchange_time;
	}

	void set_receive_time(nano_time_t receive_time) {
		this->receive_time=receive_time;
	}

	void set_aggressor_time(nano_time_t aggressor_time) {
		this->aggressor_time=aggressor_time;
	}

	void set_is_valid(bool is_valid) {
		this->is_valid=is_valid;
	}

	void set_packet_seqnum(uint32_t packet_seqnum) {
		this->packet_seqnum=packet_seqnum;
	}

	void set_packet_time_stamp(uint32_t packet_time_stamp) {
		this->packet_time_stamp=packet_time_stamp;
	}

	void set_series_name(const std::string & name) {
		::strcpy(series_name, name.c_str());
	}

	void set_security_id(CntrId security_id) {
		this->security_id=security_id;
	}

	Event get_event() const {
		return event;
	}

	trade_price_t get_trade_price() const {
		return last_trade.price;
	}

	TradeQuantity get_trade_quantity() const {
		return last_trade.quantity;
	}

	TradeSide get_trade_side() const {
		return last_trade.side;
	}


	nano_time_t get_exchange_time() const {
		return exchange_time;
	}

	nano_time_t get_receive_time() const {
		return receive_time;
	}

	nano_time_t get_aggressor_time() const {
		return aggressor_time;
	}

	bool get_is_valid() const {
		return is_valid;
	}

	uint32_t get_packet_seqnum() const {
		return this->packet_seqnum;
	}

	uint32_t get_packet_time_stamp() const {
		return this->packet_time_stamp;
	}

	std::string get_series_name() const {
		return series_name;
	}

	CntrId get_security_id() const {
		return this->security_id;
	}

	// Number of bid orders
	IArrray<levels> bdcontr{};
	// Bid order quantities
	IArrray<levels> bdquantity{};
	// Bid order prices
	DArrray<levels> bdprice{};
	// Ask order prices
	DArrray<levels> sdprice{};
	// Ask order quantities
	IArrray<levels> sdquantity{};
	// Number of ask orders
	IArrray<levels> sdcontr{};
	// Last trade we seen
	Trade last_trade{};
	// Total traded quantity at last traded price
	Trade total_traded_quantity{};
	// Event that cause the publish
	Event event{Event::Unknown};

	nano_time_t exchange_time;
	nano_time_t receive_time;
	nano_time_t aggressor_time;
	bool is_valid;
	uint32_t packet_seqnum;
	nano_time_t packet_time_stamp;
	series_name_t series_name;
	CntrId security_id;
};

/**
 *  @brief   This is the default sum template used by the map containers
 *  @tparam  Orders This is the BookContainers internal data structure for the orders
 *  @param   orders Orders type used in the sum
 *  @return	 the sum of the order quantities
 *
 *  Sum the quantities in a levels this is an implementation default for map types
 */
template<typename Orders>
inline auto sum(Orders & orders) -> QuantityValueType {
	auto f = [](QuantityValueType total,typename Orders::value_type q){return total+q.second; };
	return std::accumulate(orders.begin(), orders.end(), 0, f);
}

/**
 *  @brief   This is the specialized sum template used by vector of quanties as the BookVector has
 *  @tparam  Orders This is the BookContainers internal data structure for the orders
 *  @param   orders Orders type used in the sum
 *  @return	 the sum of the order quantities
 *
 *  Sum the quantities in a levels this is an implementation default vector
 *  if we cannot do @see vectorization
 */
inline auto sum(std::vector<QuantityValueType> & orders) -> QuantityValueType {
	auto f = [](QuantityValueType total, QuantityValueType q){return total+q; };
	return std::accumulate(orders.begin(), orders.end(), 0, f);
}

// Sorting methods used by Bid and Ask price levels
typedef typename std::less<PriceLevelKey> LessComp;
typedef typename std::greater<PriceLevelKey> GreaterComp;

/**
*  @brief The total traded holds a price with a a vector of quantity values
*/
typedef struct {
	Side side{};
	PriceLevelKey price{};
	std::vector<QuantityValueType> total;
} TotalTraded;

/**
*  @brief Special hash functor for use if we used the side as a key into a unordered_map
*
*  Currently not used
*/
typedef std::hash<Side> SideHashType;
namespace std
{
	template<>
	struct hash<Side>
	{
	  size_t
	  operator()(Side val) const noexcept
	  {
		  return static_cast<size_t>(val);
	  }
	};
}


#endif	/* _SCCR_COMMON_TYPES_H */

