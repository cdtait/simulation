#include "entity_types.h"

OrderStatus string2OrderStatus(const std::string & s) {
	if (s == "CANCELACCEPTED") {
		return CANCELACCEPTED;
	} else if (s == "CANCELCOMPLETED") {
		return CANCELCOMPLETED;
	} else if (s == "ACCEPTED") {
		return ACCEPTED;
	} else if (s == "REJECTED") {
		return REJECTED;
	} else if (s == "PENDING_CANCEL") {
		return PENDING_CANCEL;
	} else if (s == "CANCELREJECTED") {
		return CANCELREJECTED;
	} else if (s == "PENDING_NEW") {
		return PENDING_NEW;
	} else {
		return NONE;
	}
}

std::string orderStatus2String(OrderStatus s) {
	if (s == CANCELACCEPTED) {
		return "CANCELACCEPTED";
	} else if (s == CANCELCOMPLETED) {
		return "CANCELCOMPLETED";
	} else if (s == ACCEPTED) {
		return "ACCEPTED";
	} else if (s == REJECTED) {
		return "REJECTED";
	} else if (s == PENDING_CANCEL) {
		return "PENDING_CANCEL";
	} else if (s == CANCELREJECTED) {
		return "CANCELREJECTED";
	} else if (s == PENDING_NEW) {
		return "PENDING_NEW";
	} else {
		return "NONE";
	}
}

FilledStatus string2FilledStatus(const std::string & fs) {
	if (fs == "PARTIALLY_FILLED") {
		return PARTIALLY_FILLED;
	} else if (fs == "FILLED") {
		return FILLED;
	} else {
		return UNFILLED;
	}
}

std::string filledStatus2String(FilledStatus fs) {
	if (fs == PARTIALLY_FILLED) {
		return "PARTIALLY_FILLED";
	} else if (fs == FILLED) {
		return "FILLED";
	} else {
		return "UNFILLED";
	}
}

BuySell string2BuySell(const std::string & b) {
	if (b == "BUY") {
		return BUY;
	} else if (b == "SELL") {
		return SELL;
	} else {
		return NOSIDE;
	}
}

std::string buySell2String(BuySell b) {
	if (b == BUY) {
		return "BUY";
	} else if (b == SELL) {
		return "SELL";
	} else {
		return "NOSIDE";
	}
}

Direction string2Direction(const std::string & d) {
	if (d == "LONG") {
		return LONG;
	} else if (d == "SHORT") {
		return SHORT;
	} else {
		return UNDEFINED;
	}
}

std::string direction2String(const Direction d) {
	if (d == LONG) {
		return "LONG";
	} else if (d == SHORT) {
		return "SHORT";
	} else {
		return "UNDEFINED";
	}
}
