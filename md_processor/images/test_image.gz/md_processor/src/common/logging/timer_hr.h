#ifndef _TIMERHR_H
#define	_TIMERHR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/time.h>

/* rdtscll() has been copied from asm/msr.h
 * which is not available on all versions of Linux
 */
#define rdtscll(val) { \
     unsigned int a,d; \
     asm volatile("rdtsc" : "=a" (a), "=d" (d)); \
     (val) = ((unsigned long)a) | (((unsigned long)d)<<32); \
}

/**
 * @brief Set timer properties for linux OS.
 */
class timer_hr {
public:
    timer_hr() {
        clock_rate = 0;
    }
    
    virtual ~timer_hr() { }

    /**
     * Copyright 10/03/02 Sun Microsystems, Inc. All Rights Reserved
     * gethrtime.c. Providing this functionality for Linux which doesn't
     *    have gethrtime() and gethrvtime(). Simple implementation probably
     *    not accurate enough.
     */

    typedef long long hrtime_t;

    static int clock_rate;

    static void get_clock_rate() {
        FILE *fp;
        if ((fp = fopen("/proc/cpuinfo", "r")) != NULL) {

            char temp[1024];
            while (fgets(temp, sizeof (temp), fp) != NULL) {
                if (strncmp(temp, "cpu MHz", 7) == 0) {
                    char *val = strchr(temp, ':');
                    clock_rate = val ? atoi(val + 1) : 0;
                    if (clock_rate)
                        break;
                }
            }
            fclose(fp);
        }

        if (clock_rate == 0)
            clock_rate = 1000;
    }

    hrtime_t gethrtime() {
        if (clock_rate == 0)
            get_clock_rate();
        hrtime_t res;
        rdtscll(res);
        return (res / clock_rate * 1000);
    }

    hrtime_t gethrvtime() {
        struct rusage usage;
        int status;
        hrtime_t rc = 0;
        double drc;

        status = getrusage(RUSAGE_SELF, &usage);
        if (!status) {
            drc = usage.ru_utime.tv_sec + usage.ru_utime.tv_usec * 1e-6;
            //            usage.ru_stime.tv_sec + usage.ru_stime.tv_usec * 1e-6;
            drc = drc * 1000000000;
            rc = (hrtime_t) drc;
        }
        return rc;
    }

private:

};

#endif	/* _TIMERHR_H */

