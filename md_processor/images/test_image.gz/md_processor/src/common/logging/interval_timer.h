#ifndef _INTERVALTIMER_H
#define	_INTERVALTIMER_H

#if defined(__TPROFILER_FULL_TYPE_EXPANSION__)
#define TPROFILE_FUNCTION() __PRETTY_FUNCTION__
#else
#define TPROFILE_FUNCTION() __FUNCTION__
#endif

#define TPROFILE_RAW ( markKey )  IntervalTimer::mark( markKey )
#define TPROFILE ( )              TPROFILE_RAW ( TPROFILE_FUNCTION().__LINE__ )

#include <string>

/**
 * @brief Time utility for interval recording. Can be reset and dumps changes.
 */
class interval_timer {
public:
    interval_timer();
    virtual ~interval_timer();

    void mark(std::string key);

    void reset();
    void dump();
    void dumpDeltas();

private:

};

#endif	/* _INTERVALTIMER_H */

