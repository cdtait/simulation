#include "interval_timer.h"

interval_timer::interval_timer() {
}

interval_timer::~interval_timer() {
}

void interval_timer::mark(std::string key) {

    // Find timer instance associated with the key
    // Create if missing
    // Do timestamp
}

void interval_timer::reset() {
}

void interval_timer::dump() {
}

void interval_timer::dumpDeltas() {
}
