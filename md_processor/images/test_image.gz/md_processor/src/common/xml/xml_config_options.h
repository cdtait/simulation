
#ifndef XMLCONFIGOPTIONS_H_
#define XMLCONFIGOPTIONS_H_

#include <iostream>
#include <cstddef>
#include <set>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xqilla/xqilla-dom3.hpp>
#include <boost/array.hpp>
#include <boost/any.hpp>
#include "xml_result_value.h"
#include "xml_config_result.h"

XERCES_CPP_NAMESPACE_USE;

/**
 * @brief Creates a result from xpath pattern. With the given document source(systemId) loaded.
 * Return a node subset based on the xpath pattern transcode.
 */
class xml_config_options {
public:
	xml_config_options(const char* const systemId);
	virtual ~xml_config_options();

	xml_config_result * getRes(const char* const toTranscode);
	xml_config_result * getRes(const char* const toTranscode,xml_result_value & relativeResult);

private:
	DOMImplementation *_xqillaImplementation;

#if	XERCES_VERSION_MAJOR >= 3
	DOMLSParser * _parser;
#else
	DOMBuilder *_builder;
#endif

	DOMDocument *_document;
};


#endif /* XMLCONFIGOPTIONS_H_ */
