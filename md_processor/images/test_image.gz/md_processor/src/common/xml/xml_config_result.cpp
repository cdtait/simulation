
#include "xml_config_result.h"
#include "xml_result_value.h"
#include <vector>
#include <boost/any.hpp>

//XMLConfigResult::XMLConfigResult() : _expression(NULL),_result(NULL), _document(NULL) {
xml_config_result::xml_config_result() : _result(NULL), _document(NULL), _resolver(NULL) {
}

xml_config_result::xml_config_result(const char* const toTranscode) {
	initialize(toTranscode);
}

void xml_config_result::initialize(const char* const toTranscode) {
	initialize(toTranscode,_document);
}

void xml_config_result::initialize(const char* const toTranscode,const DOMNode *contextNode) {
	AutoRelease<DOMXPathNSResolver> resolver(_document->createNSResolver(_document->getDocumentElement()));
	resolver->addNamespaceBinding(X("xs"), X("http://www.w3.org/2001/XMLSchema"));

#if	XERCES_VERSION_MAJOR >= 3
	const DOMXPathExpression * expression = _document->createExpression(X(toTranscode), 0);
	_result = expression->evaluate(_document,  DOMXPathResult::ITERATOR_RESULT_TYPE, 0);
#else
	const DOMXPathExpression * expression = _document->createExpression(X(toTranscode), 0);
	_result = (XPath2Result*)expression->evaluate(_document, XPath2Result::ITERATOR_RESULT, 0);
#endif

    // Iterate over the results, printing them
    while(_result->iterateNext()) {
#if	XERCES_VERSION_MAJOR >= 3
     const DOMNode  * nodeToWrite = _result->getNodeValue();
#else
      const DOMNode  * nodeToWrite = _result->asNode();
#endif

      short nodeType = nodeToWrite->getNodeType();

      switch (nodeType) {
		  case DOMNode::TEXT_NODE:
		  case DOMNode::ATTRIBUTE_NODE:
		  {
			  std::string a = UTF8(nodeToWrite->getNodeValue());
			  xml_result_value v;
			  v._value = a;
			  v._nodeName = "text";
			  v._pathName = toTranscode;
			  _r.push_back(v);
			  break;
		  }
		  default:
			  const DOMNode  *  a = nodeToWrite;
			  xml_result_value v;
			  v._value = a;
			  v._nodeName = UTF8(a->getNodeName());
			  std::string fullExpression = toTranscode;
			  size_t parentPath = fullExpression.find_last_of("/");
			  v._pathName = fullExpression.substr(0,parentPath+1);
			  _r.push_back(v);
			  break;
      }
    }

    ((XQillaExpression*)expression)->release();
}

xml_config_result::~xml_config_result() {
	release();
}

void xml_config_result::release() {
	if (_result) {
		_result->release();
		_result = NULL;
	}
	_r.clear();
}

std::vector<xml_result_value> & xml_config_result::getRes() {
	return _r;
}

const xml_result_value & xml_config_result::operator[](int index) const {
	return _r[index];
}

