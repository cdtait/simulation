/* 
 * File:   Configurable.cpp
 * Author: ausus
 * 
 * Created on 08 September 2009, 13:45
 */

#include "configurable.h"

