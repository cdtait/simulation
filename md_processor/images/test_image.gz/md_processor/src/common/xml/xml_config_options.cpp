
#include "xml_config_options.h"
#include <vector>
#include <boost/any.hpp>

using boost::any_cast;

xml_config_options::xml_config_options(const char* const systemId) {
	  // Initialise Xerces-C and XQilla using XQillaPlatformUtils
	  XQillaPlatformUtils::initialize();

	  // Get the XQilla DOMImplementation object
	  _xqillaImplementation = DOMImplementationRegistry::getDOMImplementation(X("XPath2 3.0"));

	  // Create a DOMBuilder object
#if	XERCES_VERSION_MAJOR >= 3
	  _parser = _xqillaImplementation->createLSParser(DOMImplementationLS::MODE_SYNCHRONOUS, 0);
#else
	  _builder = _xqillaImplementation->createDOMBuilder(DOMImplementationLS::MODE_SYNCHRONOUS, 0);
	  _builder->setFeature(X("namespaces"), true);
	  _builder->setFeature(X("http://apache.org/xml/features/validation/schema"), true);
	  _builder->setFeature(X("validation"), true);
#endif

	  // Parse a DOMDocument
#if	XERCES_VERSION_MAJOR >= 3
          _document = _parser->parseURI(systemId);
#else
	  _document = _builder->parseURI(systemId);
#endif
}

xml_config_options::~xml_config_options() {
#if	XERCES_VERSION_MAJOR >= 3
          _parser->release();
#else
	  _builder->release();
#endif

	  // Terminate Xerces-C and XQilla using XQillaPlatformUtils
	  XQillaPlatformUtils::terminate();
}

xml_config_result * xml_config_options::getRes(const char* const toTranscode) {
	xml_config_result * result = new xml_config_result();
	result->_document = _document;
	result->initialize(toTranscode);
	return result;
}

xml_config_result * xml_config_options::getRes(const char* const toTranscode,xml_result_value & relativeResult) {
	xml_config_result * result = new xml_config_result();
	result->_document = _document;
	result->initialize((relativeResult.pathName()+toTranscode).c_str());
	return result;
}

