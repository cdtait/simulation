#include "xml_config.h"
#include <vector>
#include <boost/any.hpp>
#include <boost/tokenizer.hpp>
#include <boost/lexical_cast.hpp>

using boost::any_cast;
using boost::lexical_cast;

xml_config::xml_config(const char* const systemId) : _options(systemId) {
}

xml_config::~xml_config() {
}

xml_config_result * xml_config::operator[](const char* const xPath) {
	return _options.getRes(xPath);
}

std::vector<xml_result_value> & xml_config::getRes(const char* const xPath) {
	return _options.getRes(xPath)->getRes();
}

std::vector<xml_result_value> & xml_config::getRes(const char* const xPath, xml_result_value & relativeResult) {
	return _options.getRes(xPath, relativeResult)->getRes();
}

const xml_result_value & xml_config::getValue(const char* const xPath, int index) {
	xml_config_result * result = _options.getRes(xPath);

	if (result->getRes().size() > 0) {
		return (*result)[index];
	} else {
		return *(new xml_result_value());
	}
}

int xml_config::intValue(const char* const xPath, int index, int defaultValue) {
	const xml_result_value & v = getValue(xPath, index);
	return (const_cast<xml_result_value &> (v)).intValue(defaultValue);
}

bool xml_config::boolValue(const char* const xPath, int index, bool defaultValue) {
	const xml_result_value & v = getValue(xPath, index);
	return (const_cast<xml_result_value &> (v)).stringValue(defaultValue ? "true" : "false") == "true";
}

std::string xml_config::stringValue(const char* const xPath, int index, std::string defaultValue) {
	const xml_result_value & v = getValue(xPath, index);
	return (const_cast<xml_result_value &> (v)).stringValue(defaultValue);
}

long xml_config::longValue(const char* const xPath, int index, long defaultValue) {
	const xml_result_value & v = getValue(xPath, index);
	return (const_cast<xml_result_value &> (v)).longValue(defaultValue);
}

double xml_config::doubleValue(const char* const xPath, int index, double defaultValue) {
	const xml_result_value & v = getValue(xPath, index);
	return (const_cast<xml_result_value &> (v)).doubleValue(defaultValue);
}

/**
 * Reads a comma delimited string as a double array
 */
std::vector<double> xml_config::doubleVector(const char* const xPath, int index, double defaultValue) {

	std::vector<double> outVec;

	const xml_result_value & v = getValue(xPath, index);
	std::string value = (const_cast<xml_result_value &> (v)).stringValue();

	typedef boost::tokenizer < boost::char_separator<char> > tokenizer;
	boost::char_separator<char> sep(",");
	tokenizer tokens(value, sep);

	for (tokenizer::iterator it = tokens.begin(); it != tokens.end(); it++) {
		std::string s = *it;
		outVec.push_back(lexical_cast<double>(s));
	}

	return outVec;
}

std::vector<std::string> xml_config::stringVector(const char* const toTranscode, int index, std::string defaultValue) {
	std::vector<std::string> outVec;

	const xml_result_value & v = getValue(toTranscode, index);
	std::string value = (const_cast<xml_result_value &> (v)).stringValue();

	typedef boost::tokenizer < boost::char_separator<char> > tokenizer;
	boost::char_separator<char> sep(",");
	tokenizer tokens(value, sep);

	for (tokenizer::iterator it = tokens.begin(); it != tokens.end(); it++) {
		std::string s = *it;
		outVec.push_back(lexical_cast<std::string>(s));
	}

	return outVec;
}

std::set<std::string> xml_config::stringSet(const char* const toTranscode, int index, std::string defaultValue) {
	std::set<std::string> outSet;
	std::vector<std::string> v = stringVector(toTranscode,index, defaultValue);
	std::copy(v.begin(), v.end(), std::inserter(outSet,outSet.end()));
	return outSet;
}



std::string xml_config::nodeName(const char * const xPath, int index) {
	const xml_result_value & v = getValue(xPath, index);

	return (const_cast<xml_result_value &> (v)).name();
}

