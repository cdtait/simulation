
#ifndef XMLCONFIGRESULT_H_
#define XMLCONFIGRESULT_H_

#include <iostream>
#include <cstddef>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xqilla/xqilla-dom3.hpp>
#include <boost/array.hpp>
#include <boost/any.hpp>

#include "xml_result_value.h"

XERCES_CPP_NAMESPACE_USE;

/**
 * @brief Result node of the xpath pattern within the DOM context node.
 * Results can be one or many.
 */
struct xml_config_result {
	friend class xml_config_options;

	xml_config_result();
	xml_config_result(const char* const toTranscode);
	virtual ~xml_config_result();

	void release();
	const xml_result_value & operator[](int index) const;
	void initialize(const char* const toTranscode);
	void initialize(const char* const toTranscode,const DOMNode *contextNode);
	std::vector<xml_result_value> & getRes();
private:
	//const DOMXPathExpression *_expression;
#if	XERCES_VERSION_MAJOR >= 3
	DOMXPathResult *_result;
#else
	XPath2Result *_result;
#endif
	DOMDocument *_document;
    DOMXPathNSResolver * _resolver;
	std::vector<xml_result_value> _r;
};

#endif /* XMLCONFIGRESULT_H_ */
