
#include "xml_result_value.h"
#include <vector>
#include <boost/any.hpp>
#include <boost/lexical_cast.hpp>

using boost::any_cast;
using boost::lexical_cast;


xml_result_value::xml_result_value() {
}

xml_result_value::~xml_result_value() {
}

int xml_result_value::intValue(int defaultValue) {
	if (_value.empty()) {
		return defaultValue;
	}
	else {
		std::string s = any_cast<std::string>(_value);
		return lexical_cast<int>(s);
	}
}

long xml_result_value::longValue(long defaultValue) {
	if (_value.empty()) {
		return defaultValue;
	}
	else {
		std::string s = any_cast<std::string>(_value);
		return lexical_cast<long>(s);
	}
}

double xml_result_value::doubleValue(double defaultValue) {
	if (_value.empty()) {
		return defaultValue;
	}
	else {
		std::string s = any_cast<std::string>(_value);
		return lexical_cast<double>(s);
	}
}

std::string xml_result_value::stringValue(std::string defaultValue) {
	if (_value.empty()) {
		return defaultValue;
	}
	else {
		return any_cast<std::string>(_value);
	}
};

int xml_result_value::intValue() const {
	std::string s = any_cast<std::string>(_value);
	return lexical_cast<int>(s);
}

long xml_result_value::longValue() const {
	std::string s = any_cast<std::string>(_value);
	return lexical_cast<long>(s);
}

double xml_result_value::doubleValue() const {
	std::string s = any_cast<std::string>(_value);
	return lexical_cast<double>(s);
}

std::string xml_result_value::stringValue() const {
	return any_cast<std::string>(_value);
}

