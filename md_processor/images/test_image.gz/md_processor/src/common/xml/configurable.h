/* 
 * File:   Configurable.h
 * Author: ausus
 *
 * Created on 08 September 2009, 13:45
 */

#ifndef configurable_h
#define	configurable_h

#include "xml_config.h"

/**
 * @brief Interface to describe a configurable class.
 */
/**
 * Interface used to dictate that a class can be configured via XML.
 */
class configurable {
public:
    virtual void configure(xml_config& config) = 0;
    
private:

};

#endif	/* _CONFIGURABLE_H */

