
#ifndef XMLCONFIG_H_
#define XMLCONFIG_H_

#include "xml_config_options.h"

/**
 * @namespace ausus.common.xml
 */

/**
* @brief Represents the complete node(dom) structure for the given document source(systemId).
* ALlows manipulation of subnodes and extraction of values on elements and attributes via xpath.
* Explicit conversion is used to determine types in values.
*/

/**
 * Representation of an XML configuration document that can be used
 * to configure a class / classes.
 */
class xml_config {
public:
	xml_config(const char* const systemId);
	virtual ~xml_config();

	xml_config_result * operator[](const char* const xPath);
	const xml_result_value & getValue(const char* const xPath, int index);
	std::vector<xml_result_value> & getRes(const char* const xPath);
	std::vector<xml_result_value> & getRes(const char* const xPath, xml_result_value & relativeResult);

	int intValue(const char* const xPath, int index = 0, int defaultValue = 0);
	bool boolValue(const char* const xPath, int index = 0, bool defaultValue = false);
	std::string stringValue(const char* const xPath, int index = 0, std::string defaultValue = "");
	long longValue(const char* const xPath, int index = 0, long defaultValue = 0);
	double doubleValue(const char* const xPath, int index = 0, double defaultValue = 0);
	std::vector<double> doubleVector(const char* const xPath, int index = 0, double defaultValue = 0);
	std::vector<std::string> stringVector(const char* const xPath, int index = 0, std::string defaultValue = "");
	std::set<std::string> stringSet(const char* const toTranscode, int index, std::string defaultValue="");

	std::string nodeName(const char* const xPath, int index = 0);

	const xml_result_value & getValue(const std::string xPath, int index) {
		return getValue(xPath.c_str(), index);
	}

	std::vector<xml_result_value> & getRes(const std::string xPath) {
		return getRes(xPath.c_str());
	}

	std::vector<xml_result_value> & getRes(const std::string xPath, xml_result_value & relativeResult) {
		return getRes(xPath.c_str(), relativeResult);
	}

	bool hasRes(const std::string xPath) {
		return getRes(xPath.c_str()).size() > 0;
	}

	bool hasRes(const std::string xPath, xml_result_value & relativeResult) {
		return getRes(xPath.c_str(), relativeResult).size() > 0;
	}

	int intValue(const std::string xPath, int index = 0, int defaultValue = 0){
		return intValue(xPath.c_str(), index, defaultValue);
	}

	bool boolValue(const std::string xPath, int index = 0, bool defaultValue = false) {
		return boolValue(xPath.c_str(), index, defaultValue);
	}

	std::string stringValue(const std::string xPath, int index = 0, std::string defaultValue = "") {
		return stringValue(xPath.c_str(), index, defaultValue);
	}

	long longValue(const std::string xPath, int index = 0, long defaultValue = 0) {
		return longValue(xPath.c_str(), index, defaultValue);
	}

	double doubleValue(const std::string xPath, int index = 0, double defaultValue = 0) {
		return doubleValue(xPath.c_str(), index, defaultValue);
	}

	std::vector<double> doubleVector(const std::string xPath, int index = 0, double defaultValue = 0) {
		return doubleVector(xPath.c_str(), index, defaultValue);
	}

	std::string nodeName(const std::string xPath, int index = 0) {
		return nodeName(xPath.c_str(), index);
	}

private:
	xml_config_options _options;
};


#endif /* XMLCONFIGOPTIONS_H_ */
