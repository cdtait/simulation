
#ifndef XMLRESULTVALUE_H_
#define XMLRESULTVALUE_H_

#include <iostream>
#include <boost/array.hpp>
#include <boost/any.hpp>

class XMLConfigResult;
class xml_config_options;

/**
 * @brief Actual result value wrapped up so that it can be converted to its true type.
 */
struct xml_result_value {
	friend class XMLConfigResult;
	friend class xml_config_options;
	xml_result_value();
	virtual ~xml_result_value();

	int intValue(int defaultValue);
	std::string stringValue(std::string defaultValue);
	long longValue(long defaultValue);
	double doubleValue(double defaultValue);

	int intValue() const;
	std::string stringValue() const;
	long longValue() const;
	double doubleValue() const;

	const char * type() { return _value.type().name(); }
	std::string name() { return _nodeName; }
	std::string pathName() { return _pathName; }

	boost::any _value;
	std::string _nodeName;
	std::string _pathName;
};


#endif /* XMLRESULTVALUE_H_ */
