#ifndef cme_print_formatter_h
#define cme_print_formatter_h

#include <iostream>
#include <iomanip>

#include "common/primitives/ptime.h"

#include "book/md_order_book2.h"

#include "mktdata/MessageHeader.hpp"
#include "mktdata/MDIncrementalRefreshBook32.hpp"
#include "mktdata/SnapshotFullRefresh38.hpp"
#include "mktdata/MDIncrementalRefreshVolume37.hpp"
#include "mktdata/MDIncrementalRefreshTradeSummary42.hpp"
#include "mktdata/MDInstrumentDefinitionFuture27.hpp"

using namespace mktdata;

void print_book_txt(std::ostream & ostr,md_order_book2& book)
{
	static constexpr const int buff_len=512;
	char buffer[buff_len];

	static constexpr const char* cme_trade_header=
{R"(|-------------------------------------------------------|
| trade_id:%d    time:%lu            |
| %c of %u at %7.7f      |
)"};
	static constexpr const char* cme_trade_volume=
{R"(|-------------------------------------------------------|
| trade_volume:%u                       |
)"};
	static constexpr const char* cme_readable_book_header=
{R"(|-------------------------------------------------------|
| ptime:%lu      pseqnum:%d             |
| symbol:%s   secid:%d      secseqnum:%d      |
| extime:%lu      rectime:%lu             |
|-------------------------------------------------------|
|             Bid              |           Ask          |
|-------------------------------------------------------|
|Level| Num | Qty |   Price    |    Price   | Qty | Num |
|-------------------------------------------------------|
)"};

	Event event = book.get_event();

	if (event==Event::Trade) {
		int32_t trade_id= book.get_trade_id();
		trade_price_t trade_price= book.get_trade_price();
		TradeQuantity trade_quantity= book.get_trade_quantity();
		TradeSide trade_side= book.get_trade_side();
		//OrderBookNumber num_buyers= book.get_num_buyers();
		//OrderBookNumber num_sellers= book.get_num_sellers();
		nano_time_t aggressor_time= book.get_aggressor_time();

		//::sprintf(buffer,"%d %llu %c %u",trade_id,aggressor_time,trade_side,trade_quantity);
		::sprintf(buffer,cme_trade_header,trade_id,aggressor_time,trade_side,trade_quantity,(double)trade_price);

		ostr << buffer;
	}
	else if (event==Event::Volume) {
			TradeVolume trade_volume= book.get_trade_volume();
			//::sprintf(buffer,"%d %llu %c %u",trade_id,aggressor_time,trade_side,trade_quantity);
			::sprintf(buffer,cme_trade_header,trade_volume,);

			ostr << buffer;
	}
	else {
		//bool is_valid= book.get_is_valid();
		uint32_t packet_seqnum= book.get_packet_seqnum();
		nano_time_t packet_time_stamp= book.get_packet_time_stamp();
		std::string series_name= book.get_series_name();
		CntrId security_id= book.get_security_id();
		uint32_t rpt_seqnum= book.get_rpt_seqnum();
		nano_time_t exchange_time= book.get_exchange_time();
		nano_time_t receive_time= book.get_receive_time();

		::sprintf(buffer,
				cme_readable_book_header,
				packet_time_stamp,
				packet_seqnum,
				series_name.c_str(),
				security_id,
				rpt_seqnum,
				exchange_time,
				receive_time);

		ostr << buffer;

		uint32_t bidDepth = book.bid().getDepth();
		uint32_t askDepth = book.ask().getDepth();

		int cx = 0;

		for (uint32_t level = 1; level <= 5; level++) {
			const md_order_book_2_level& bidOrderBookLevel = book.bid().getLevel(level);
			const md_order_book_2_level& askOrderBookLevel = book.ask().getLevel(level);

			uint32_t bidorders=0;
			uint32_t bidquantity=0;
			double bidpprice=0;

			uint32_t askorders=0;
			uint32_t askquantity=0;
			double askpprice=0;

			if (level<=bidDepth) {
				bidorders=bidOrderBookLevel.orders;
				bidquantity=bidOrderBookLevel.quantity;
				bidpprice=bidOrderBookLevel.price;
			}

			if (level<=askDepth) {
				askorders=askOrderBookLevel.orders;
				askquantity=askOrderBookLevel.quantity;
				askpprice=askOrderBookLevel.price;
			}

			cx += ::snprintf(
					buffer + cx,
					buff_len - cx,
					"|%5d|%5d|%5d|%5.7f|%5.7f|%5d|%5d|\n",
					level,
					bidorders,
					bidquantity,
					bidpprice,
					askpprice,
					askquantity,
					askorders);
		}


		ostr << buffer;
	}

	ostr << readable_trailer << std::endl;
	ostr << std::endl;
}

/**
 * Prints the book in csv format
 *
 * @param ostr
 * @param book
 */
void print_book_csv(std::ostream & ostr,md_order_book2& book) {
	uint32_t packet_seqnum= book.get_packet_seqnum();
	nano_time_t packet_time_stamp= book.get_packet_time_stamp();
	std::string series_name= book.get_series_name();
	nano_time_t exchange_time= book.get_exchange_time();
	nano_time_t receive_time= book.get_receive_time();
	CntrId security_id= book.get_security_id();
	uint32_t rpt_seqnum= book.get_rpt_seqnum();

	Event event = book.get_event();
	int32_t trade_id= book.get_trade_id();
	trade_price_t trade_price= book.get_trade_price();
	TradeQuantity trade_quantity= book.get_trade_quantity();
	TradeSide trade_side= book.get_trade_side();
	OrderBookNumber num_buyers= book.get_num_buyers();
	OrderBookNumber num_sellers= book.get_num_sellers();
	TradeVolume trade_volume= book.get_trade_volume();
	nano_time_t aggressor_time= book.get_aggressor_time();

	//bool is_valid= book.get_is_valid();

	static constexpr const unsigned int buffer_len = 512;
	char buffer[buffer_len];

	::sprintf(buffer,
			"%u,%lu,%lu,%lu,%s,%u,%u,%c,%d,%ld,%u,%c,%u,%u,%u,%lu,",
			packet_seqnum,
			packet_time_stamp,
			exchange_time,
			receive_time,
			series_name.c_str(),
			security_id,
			rpt_seqnum,
			event,
			trade_id,
			trade_price.get_mantissa(),
			trade_quantity,
			trade_side,
			trade_volume,
			num_buyers,
			num_sellers,
			aggressor_time);

	ostr << buffer;

	static constexpr const char* csv_level_format={"%u,%u,%u,%5.7f,%5.7f,%u,%u,"};

    uint32_t bidDepth = book.bid().getDepth();
    uint32_t askDepth = book.ask().getDepth();

	int cx = 0;

	for (uint32_t level = 1; level <= 5; level++) {
		const md_order_book_2_level& bidOrderBookLevel = book.bid().getLevel(level);
		const md_order_book_2_level& askOrderBookLevel = book.ask().getLevel(level);

		uint32_t bidorders=0;
		uint32_t bidquantity=0;
		double bidpprice=0;

		uint32_t askorders=0;
		uint32_t askquantity=0;
		double askpprice=0;

		if (level<=bidDepth) {
			bidorders=bidOrderBookLevel.orders;
			bidquantity=bidOrderBookLevel.quantity;
			bidpprice=bidOrderBookLevel.price;
		}

		if (level<=askDepth) {
			askorders=askOrderBookLevel.orders;
			askquantity=askOrderBookLevel.quantity;
			askpprice=askOrderBookLevel.price;
		}

		cx += ::snprintf(
				buffer + cx,
				buffer_len - cx,
				csv_level_format,
				level,
				bidorders,
				bidquantity,
				bidpprice,
				askpprice,
				askquantity,
				askorders);
	}

	ostr << buffer << "\n";
}

void print_book_csv_header(std::ostream & ostr) {
	ostr << "packet_seqnum,packet_time_stamp,exchange_time,"
		<< "receive_time,series_name,security_id,rpt_seqnum,event,"
		<< "trade_id,trade_price,trade_quantity,"
		<< "trade_side,trade_volume,num_buyers,num_sellers,aggressor_time,";

	char buffer[80];
	uint32_t level = 0;
	for (; level < 5 ; level++) {
		::sprintf(buffer,"bidorders[%d],bidquantity[%d],bidpprice[%d],askpprice[%d],askquantity[%d],askorders[%d],",
				level,level,level,level,level,level);
		ostr << buffer;
	}

	ostr << buffer;
}

// buf needs to store 30 characters
int timespec2str(char *buf, uint len, struct timespec *ts) {
	uint ret;
    struct tm t;

    tzset();
    if (localtime_r(&(ts->tv_sec), &t) == NULL)
        return 1;

    ret = strftime(buf, len, "GMT %x %X", &t);
    if (ret == 0)
        return 2;
    len -= ret - 1;

    ret = snprintf(&buf[strlen(buf)], len, ".%09ld", ts->tv_nsec);
    if (ret >= len)
        return 3;

    return 0;
}

// composite
std::ostream & printPRICENULL(std::ostream & ostr,PRICENULL& nullPrice) {
	if (nullPrice.mantissa()!=nullPrice.mantissaNullValue()) {
		std::ios_base::fmtflags originalFlags = ostr.flags();
		ostr << std::fixed;
		ostr << std::setprecision(-nullPrice.exponent());
		ostr << nullPrice.mantissa()*pow(10,nullPrice.exponent());
		ostr.flags( originalFlags );
	}
	else {
		ostr << nullPrice.mantissa();
	}

	return ostr;
}

// composite
std::ostream & printPRICE(std::ostream & ostr,PRICE& price) {
	std::ios_base::fmtflags originalFlags = ostr.flags();
	ostr << std::fixed;
	ostr << std::setprecision(-price.exponent());
	ostr << price.mantissa()*pow(10,price.exponent());
	ostr.flags( originalFlags );

	return ostr;
}

// composite
std::ostream & printFLOAT(std::ostream & ostr,FLOAT& price) {
	std::ios_base::fmtflags originalFlags = ostr.flags();
	ostr << std::fixed;
	ostr << std::setprecision(-price.exponent());
	ostr << price.mantissa()*pow(10,price.exponent());
	ostr.flags( originalFlags );

	return ostr;
}

std::ostream &  printLongTime(std::ostream & ostr,sbe_uint64_t & longTime) {
	struct timespec ts;
	ts.tv_sec=longTime / 1e9;
	ts.tv_nsec=longTime - static_cast<uint64_t>(ts.tv_sec*1e9);

	char buf[30];
	timespec2str(buf, 32, &ts);

	ostr << "(" << longTime << ") ";
	ostr << buf;

	return ostr;
}

std::ostream & printDate(std::ostream & ostr,sbe_uint16_t & shortDate) {
	ostr << shortDate;
	return ostr;
}

// enum
std::ostream & printSecurityTradingStatus(std::ostream & ostr, SecurityTradingStatus::Value & sts) {
	//ostr << "(";
    switch(sts)
    {
    	case SecurityTradingStatus::TradingHalt:
    		ostr << "TradingHalt";
    		break;
    	case SecurityTradingStatus::Close:
    		ostr << "Close";
    		break;
    	case SecurityTradingStatus::NewPriceIndication:
    		ostr << "NewPriceIndication";
    		break;
    	case SecurityTradingStatus::NotAvailableForTrading:
    		ostr << "NotAvailableForTrading";
    		break;
    	case SecurityTradingStatus::UnknownorInvalid:
    		ostr << "UnknownorInvalid";
    		break;
    	case SecurityTradingStatus::PreOpen:
    		ostr << "PreOpen";
    		break;
    	case SecurityTradingStatus::PreCross:
    		ostr << "PreCross";
    		break;
    	case SecurityTradingStatus::Cross:
    		ostr << "Cross";
    		break;
    	case SecurityTradingStatus::PostClose:
    		ostr << "PostClose";
    		break;
    	case SecurityTradingStatus::NoChange:
    		ostr << "NoChange";
    		break;
    	case SecurityTradingStatus::NULL_VALUE:
    		ostr << "NULL_VALUE";
    		break;
    	default:
    		break;
    };
	//ostr << ")";
	return ostr;
}

// enum
std::ostream & printMDEntryType(std::ostream & ostr,MDEntryType::Value & mDEntryType) {
	//ostr << "(";
    switch(mDEntryType)
    {
    	case MDEntryType::Bid:
        	ostr << "Bid";
        	break;
    	case MDEntryType::Offer:
    		ostr << "Offer";
    		break;
    	case MDEntryType::Trade:
    		ostr << "Trade";
    		break;
    	case MDEntryType::OpeningPrice:
    		ostr << "OpeningPrice";
    		break;
    	case MDEntryType::SettlementPrice:
    		ostr << "SettlementPrice";
    		break;
    	case MDEntryType::TradingSessionHighPrice:
    		ostr << "TradingSessionHighPrice";
    		break;
    	case MDEntryType::TradingSessionLowPrice:
    		ostr << "TradingSessionLowPrice";
    		break;
    	case MDEntryType::TradeVolume:
    		ostr << "TradeVolume";
    		break;
    	case MDEntryType::OpenInterest:
    		ostr << "OpenInterest";
    		break;
    	case MDEntryType::ImpliedBid:
    		ostr << "ImpliedBid";
    		break;
    	case MDEntryType::ImpliedOffer:
    		ostr << "ImpliedOffer";
    		break;
    	case MDEntryType::EmptyBook:
    		ostr << "EmptyBook";
    		break;
    	case MDEntryType::SessionHighBid:
    		ostr << "SessionHighBid";
    		break;
    	case MDEntryType::SessionLowOffer:
    		ostr << "SessionLowOffer";
    		break;
    	case MDEntryType::FixingPrice:
    		ostr << "FixingPrice";
    		break;
    	case MDEntryType::ElectronicVolume:
    		ostr << "ElectronicVolume";
    		break;
    	case MDEntryType::ThresholdLimitsandPriceBandVariation:
    		ostr << "ThresholdLimitsandPriceBandVariation";
    		break;
    	case MDEntryType::NULL_VALUE:
    		ostr << "NULL_VALUE";
    		break;
    	default:
    		break;
    };
	//ostr << ")";
	return ostr;
}

// enum
std::ostream & printMDEntryTypeBook(std::ostream & ostr,MDEntryTypeBook::Value & mDEntryType){
	//ostr << "(";
    switch(mDEntryType)
    {
    	case MDEntryTypeBook::Bid:
        	ostr << "Bid";
        	break;
    	case MDEntryTypeBook::Offer:
    		ostr << "Offer";
    		break;
    	case MDEntryTypeBook::ImpliedBid:
    		ostr << "ImpliedBid";
    		break;
    	case MDEntryTypeBook::ImpliedOffer:
    		ostr << "ImpliedOffer";
    		break;
    	case MDEntryTypeBook::BookReset:
    		ostr << "BookReset";
    		break;
    	case MDEntryTypeBook::NULL_VALUE:
    		ostr << "NULL_VALUE";
    		break;
    	default:
    		break;
    };
	//ostr << ")";
	return ostr;
}

// enum
std::ostream & printOpenCloseSettlFlag(std::ostream & ostr,OpenCloseSettlFlag::Value & openCloseSettlFlag) {
	//ostr << "(";
    switch(openCloseSettlFlag)
    {
    	case OpenCloseSettlFlag::DailyOpenPrice:
        	ostr << "DailyOpenPrice";
        	break;
    	case OpenCloseSettlFlag::IndicativeOpeningPrice:
    		ostr << "IndicativeOpeningPrice";
    		break;
    	default:
    		break;
    };
	//ostr << ")";
	return ostr;
}

// enum
std::ostream & printSecurityUpdateAction(std::ostream & ostr,SecurityUpdateAction::Value & securityUpdateAction) {
	//ostr << "(";
    switch(securityUpdateAction)
    {
    	case SecurityUpdateAction::Add:
        	ostr << "Add";
        	break;
    	case SecurityUpdateAction::Delete:
    		ostr << "Delete";
    		break;
    	case SecurityUpdateAction::Modify:
    		ostr << "Modify";
    		break;
    	case SecurityUpdateAction::NULL_VALUE:
    		ostr << "NULL_VALUE";
    		break;
    	default:
    		break;
    };
	//ostr << ")";
	return ostr;
}

// enum
std::ostream & printMDUpdateAction(std::ostream & ostr,MDUpdateAction::Value & mDUpdateAction) {
	//ostr << "(";
    switch(mDUpdateAction)
    {
    	case MDUpdateAction::New:
        	ostr << "New";
        	break;
    	case MDUpdateAction::Change:
    		ostr << "Change";
    		break;
    	case MDUpdateAction::Delete:
    		ostr << "Delete";
    		break;
    	case MDUpdateAction::DeleteThru:
    		ostr << "DeleteThru";
    		break;
    	case MDUpdateAction::DeleteFrom:
    		ostr << "DeleteFrom";
    		break;
       	case MDUpdateAction::Overlay:
        		ostr << "Overlay";
        		break;
      	case MDUpdateAction::NULL_VALUE:
        		ostr << "NULL_VALUE";
        		break;
    	default:
    		break;
    };
	//ostr << ")";

	return ostr;
}

// set
std::ostream & printSettlPriceType(std::ostream & ostr,SettlPriceType & settlPriceType) {
	ostr << "(";
	if (settlPriceType.Final())
		ostr << "Final,";
	if (settlPriceType.Actual())
		ostr << "Actual,";
	if (settlPriceType.Rounded())
		ostr << "Rounded,";
	if (settlPriceType.Intraday())
		ostr << "Intraday,";
	if (settlPriceType.ReservedBits())
		ostr << "ReservedBits,";
	if (settlPriceType.NullValue())
		ostr << "NullValue,";
	ostr << ")";
	return ostr;
}

// set
std::ostream & printMatchEventIndicator(std::ostream & ostr,MatchEventIndicator & matchEventIndicator) {
	ostr << "(";
	if (matchEventIndicator.LastTradeMsg())
		ostr << "LastTradeMsg,";
	if (matchEventIndicator.LastVolumeMsg())
		ostr << "LastVolumeMsg,";
	if (matchEventIndicator.LastQuoteMsg())
		ostr << "LastQuoteMsg,";
	if (matchEventIndicator.LastStatsMsg())
		ostr << "LastStatsMsg,";
	if (matchEventIndicator.LastImpliedMsg())
		ostr << "LastImpliedMsg,";
	if (matchEventIndicator.RecoveryMsg())
		ostr << "RecoveryMsg,";
	if (matchEventIndicator.Reserved())
		ostr << "Reserved,";
	if (matchEventIndicator.EndOfEvent())
		ostr << "EndOfEvent,";
	ostr << ")";
	return ostr;
}

void printMessageSize(std::ostream & ostr,sbe_uint16_t msgSize) {
	ostr << " msgSize:" << msgSize << "\n";
}

void printMessageHeader(std::ostream & ostr,const MessageHeader& hdr) {
	ostr << " messageHeader.blockLength:" << hdr.blockLength() << "\n";
	ostr << " messageHeader.templateId:" << hdr.templateId() << "\n";
	ostr << " messageHeader.schemaId:" << hdr.schemaId() << "\n";
	ostr << " messageHeader.schemaVersion:" << (sbe_uint32_t) (hdr.version()) << "\n";
}

void printPacketHeader(std::ostream & ostr,sbe_uint32_t MsgSeqNum,sbe_uint64_t SendingTime) {
	ostr << "packetheader.MsgSeqNum:" << MsgSeqNum;
	ostr << ",packetheader.SendingTime:";
	printLongTime(ostr,SendingTime) << "\n";
}

std::string to_xml_string(MDIncrementalRefreshBook32 & mdIncrementalRefreshBook32) {
    //<field name="TransactTime" id="60" type="uInt64" description="Start of event processing time in number of nanoseconds since Unix epoch" offset="0" semanticType="UTCTimestamp"/>
    //<field name="MatchEventIndicator" id="5799" type="MatchEventIndicator" description="Bitmap field of eight Boolean type indicators reflecting the end of updates for a given Globex event" offset="8" semanticType="MultipleCharValue"/>
	std::stringstream ss;
	ss << "<MDIncrementalRefreshBook32";

	sbe_uint64_t tt = mdIncrementalRefreshBook32.transactTime();
	ss << " transactTime='";
	printLongTime(ss,tt);
	ss << "'";

	MatchEventIndicator & i = mdIncrementalRefreshBook32.matchEventIndicator();
	ss << " matchEventIndicator='";
	printMatchEventIndicator(ss,i);
	ss << "'";
	ss << ">\n";

	MDIncrementalRefreshBook32::NoMDEntries & noMDEntries = mdIncrementalRefreshBook32.noMDEntries();
	int count = noMDEntries.count();
	int inc=0;
	while (noMDEntries.hasNext() ) {
		MDIncrementalRefreshBook32::NoMDEntries & mdEntry = noMDEntries.next();

		ss << "\t<NoMDEntries i='" << inc << "' ";

		PRICENULL& mDEntryPx=mdEntry.mDEntryPx();
		ss << "mDEntryPx='";
		printPRICENULL(ss,mDEntryPx);
		ss << "' ";
		ss << "mDEntrySize='" << mdEntry.mDEntrySize() << "' ";
		ss << "securityID='" << mdEntry.securityID() << "' ";
		ss << "rptSeq='" << mdEntry.rptSeq() << "' ";
		ss << "numberOfOrders='" << mdEntry.numberOfOrders() << "' ";

		sbe_int32_t mDPriceLevel=mdEntry.mDPriceLevel();
		ss << "mDPriceLevel='" << mDPriceLevel << "' ";

		MDUpdateAction::Value ua = mdEntry.mDUpdateAction();
		ss << "mDUpdateAction='";
		printMDUpdateAction(ss,ua);
		ss << "' ";

		MDEntryTypeBook::Value mDEntryType=mdEntry.mDEntryType();

		ss << "mDEntryType='";
		printMDEntryTypeBook(ss,mDEntryType);
		ss << "' ";

		ss << ">\n";
		inc++;
	}
	ss << "</MDIncrementalRefreshBook32>\n\n";

	return ss.str();
}

std::string to_xml_string(MDIncrementalRefreshTradeSummary42 & mdIncrementalRefreshTradeSummary42) {
	std::stringstream ss;
	ss << "<MDIncrementalRefreshTradeSummary42";

	sbe_uint64_t tt = mdIncrementalRefreshTradeSummary42.transactTime();
	ss << " transactTime='";
	printLongTime(ss,tt);
	ss << "'";

	MatchEventIndicator & i = mdIncrementalRefreshTradeSummary42.matchEventIndicator();
	ss << " matchEventIndicator='";
	printMatchEventIndicator(ss,i);
	ss << "'";
	ss << ">\n";

	MDIncrementalRefreshTradeSummary42::NoMDEntries & noMDEntries = mdIncrementalRefreshTradeSummary42.noMDEntries();

	int count = noMDEntries.count();
	int inc=0;
	while (noMDEntries.hasNext() ) {
		 MDIncrementalRefreshTradeSummary42::NoMDEntries & mdEntry = noMDEntries.next();
			ss << "\t<NoMDEntries i='" << inc << "' ";

			PRICE& mDEntryPx=mdEntry.mDEntryPx();
			ss << "mDEntryPx='";
			printPRICE(ss,mDEntryPx);
			ss << "' ";
			ss << "mDEntrySize='" << mdEntry.mDEntrySize() << "' ";
			ss << "securityID='" << mdEntry.securityID() << "' ";
			ss << "rptSeq='" << mdEntry.rptSeq() << "' ";
			ss << "numberOfOrders='" << mdEntry.numberOfOrders() << "' ";

			MDUpdateAction::Value ua = mdEntry.mDUpdateAction();
			ss << "mDUpdateAction='";
			printMDUpdateAction(ss,ua);
			ss << "' ";

			const char * mDEntryType=mdEntry.mDEntryType();

			ss << "mDEntryType='";
			ss << mDEntryType;
			ss << "' ";

			ss << ">\n";
			inc++;
 	 }

	ss << "</MDIncrementalRefreshTradeSummary42>\n\n";

	 return ss.str();
}

std::string to_xml_string(MDIncrementalRefreshVolume37 & mdIncrementalRefreshVolume37) {
	std::stringstream ss;
	ss << "<MDIncrementalRefreshVolume37";

	sbe_uint64_t tt = mdIncrementalRefreshVolume37.transactTime();
	ss << " transactTime='";
	printLongTime(ss,tt);
	ss << "'";

	MatchEventIndicator & i = mdIncrementalRefreshVolume37.matchEventIndicator();
	ss << " matchEventIndicator='";
	printMatchEventIndicator(ss,i);
	ss << "'";
	ss << ">\n";

	MDIncrementalRefreshVolume37::NoMDEntries & noMDEntries = mdIncrementalRefreshVolume37.noMDEntries();

	int count = noMDEntries.count();
	int inc=0;
	while (noMDEntries.hasNext() ) {
		MDIncrementalRefreshVolume37::NoMDEntries & mdEntry = noMDEntries.next();
			ss << "\t<NoMDEntries i='" << inc << "' ";

			ss << "mDEntrySize='" << mdEntry.mDEntrySize() << "' ";
			ss << "securityID='" << mdEntry.securityID() << "' ";
			ss << "rptSeq='" << mdEntry.rptSeq() << "' ";

			MDUpdateAction::Value ua = mdEntry.mDUpdateAction();
			ss << "mDUpdateAction='";
			printMDUpdateAction(ss,ua);
			ss << "' ";

			ss << ">\n";
			inc++;
 	 }

	ss << "</MDIncrementalRefreshVolume37>\n\n";

	 return ss.str();
}

void printEvent(std::ostream & ostr,SnapshotFullRefresh38 &snapshotFullRefresh38) {
	//<field name="LastMsgSeqNumProcessed" id="369" type="uInt32" description="Sequence number of the last Incremental feed packet processed. This value is used to synchronize the snapshot loop with the real-time feed" offset="0" semanticType="SeqNum"/>
	ostr << "\tlastMsgSeqNumProcessed:" << snapshotFullRefresh38.lastMsgSeqNumProcessed() << "\n";
	//<field name="TotNumReports" id="911" type="uInt32" description="Total number of messages replayed in the loop" offset="4" semanticType="int"/>
	ostr << "\ttotNumReports:" << snapshotFullRefresh38.totNumReports() << "\n";
	//<field name="SecurityID" id="48" type="Int32" description="Security ID" offset="8" semanticType="int"/>
	ostr << "\tsecurityID:" << snapshotFullRefresh38.securityID() << "\n";
	//<field name="RptSeq" id="83" type="uInt32" description="Sequence number of the last Market Data entry processed for the instrument" offset="12" semanticType="SeqNum"/>
	ostr << "\trptSeq:" << snapshotFullRefresh38.rptSeq() << "\n";
	//<field name="TransactTime" id="60" type="uInt64" description="Timestamp of the last event security participated in, sent as number of nanoseconds since Unix epoch" offset="16" semanticType="UTCTimestamp"/>
	sbe_uint64_t tt = snapshotFullRefresh38.transactTime();
	ostr << "\ttransactTime:";
	printLongTime(ostr,tt) << "\n";
	//<field name="LastUpdateTime" id="779" type="uInt64" description="UTC Date and time of last Security Definition add, update or delete on a given Market Data channel" offset="24" semanticType="UTCTimestamp"/>
	sbe_uint64_t ll = snapshotFullRefresh38.lastUpdateTime();
	ostr << "\tlastUpdateTime:" ;
	printLongTime(ostr,ll) << "\n";
	//<field name="TradeDate" id="75" type="LocalMktDate" description="Trade session date sent as number of days since Unix epoch" offset="32" semanticType="LocalMktDate"/>
	sbe_uint16_t td = snapshotFullRefresh38.tradeDate();
	ostr << "\ttradeDate:";
	printDate(ostr,td) << "\n";
	//<field name="MDSecurityTradingStatus" id="1682" type="SecurityTradingStatus" description="Identifies the current trading state of the instrument" offset="34" semanticType="int"/>
	SecurityTradingStatus::Value sts = snapshotFullRefresh38.mDSecurityTradingStatus();
	ostr << "\tmDSecurityTradingStatus:";
	printSecurityTradingStatus(ostr,sts) << "\n";
	//<field name="HighLimitPrice" id="1149" type="PRICENULL" description="Upper price threshold for the instrument" offset="35" semanticType="Price"/>
	ostr << "\thighLimitPrice:";
	printPRICENULL(ostr,snapshotFullRefresh38.highLimitPrice()) << "\n";
	//<field name="LowLimitPrice" id="1148" type="PRICENULL" description="Lower price threshold for the instrument" offset="43" semanticType="Price"/>
	ostr << "\tlowLimitPrice:";
	printPRICENULL(ostr,snapshotFullRefresh38.lowLimitPrice()) << "\n";
	//<field name="MaxPriceVariation" id="1143" type="PRICENULL" description="Differential value for price banding" offset="51" semanticType="Price"/>
	ostr << "\tmaxPriceVariation:";
	printPRICENULL(ostr,snapshotFullRefresh38.maxPriceVariation()) << "\n";

	/*
	<group name="NoMDEntries" id="268" description="Number of entries in Market Data message" blockLength="22" dimensionType="groupSize">
		<field name="MDEntryPx" id="270" type="PRICENULL" description="Market Data entry price" offset="0" semanticType="Price"/>
		<field name="MDEntrySize" id="271" type="Int32NULL" description="Market Data entry quantity" offset="8" semanticType="Qty"/>
		<field name="NumberOfOrders" id="346" type="Int32NULL" description="Aggregate number of orders at the given price level" offset="12" semanticType="int"/>
		<field name="MDPriceLevel" id="1023" type="Int8NULL" description="Aggregate book position" offset="16" semanticType="int"/>
		<field name="TradingReferenceDate" id="5796" type="LocalMktDate" description="Indicates the date of trade session corresponding to a statistic entry" offset="17" semanticType="LocalMktDate"/>
		<field name="OpenCloseSettlFlag" id="286" type="OpenCloseSettlFlag" description="Flag describing  Open Price entry" offset="19" semanticType="int"/>
		<field name="SettlPriceType" id="731" type="SettlPriceType" description="Bitmap field of eight Boolean type indicators representing settlement price type" offset="20" semanticType="MultipleCharValue"/>
		<field name="MDEntryType" id="269" type="MDEntryType" description="Market Data entry type" offset="21" semanticType="char"/>
	</group>
	*/

	SnapshotFullRefresh38::NoMDEntries & noMDEntries = snapshotFullRefresh38.noMDEntries();
	int count = noMDEntries.count();
	for(int i=0;i<count;i++) {
		ostr << "\tSnapshotFullRefresh38::NoMDEntries[" << i << "] { ";
		SnapshotFullRefresh38::NoMDEntries & mdEntry = noMDEntries.next();
		sbe_int32_t mDPriceLevel=mdEntry.mDPriceLevel();
		ostr << "mDPriceLevel:" << mDPriceLevel << " ";
		MDEntryType::Value mDEntryType=mdEntry.mDEntryType();
		ostr << "mDEntryType:";
		printMDEntryType(ostr,mDEntryType) << " ";
		PRICENULL& mDEntryPx=mdEntry.mDEntryPx();
		ostr << "mDEntryPx:";
		printPRICENULL(ostr,mDEntryPx) << " ";
		ostr << "mDEntrySize:" << mdEntry.mDEntrySize() << " ";
		ostr << "numberOfOrders:" << mdEntry.numberOfOrders() << " ";
		sbe_uint16_t tradingReferenceDate=mdEntry.tradingReferenceDate();
		ostr << "tradingReferenceDate:";
		printDate(ostr,tradingReferenceDate) << " ";
		OpenCloseSettlFlag::Value openCloseSettlFlag=mdEntry.openCloseSettlFlag();
		ostr << "openCloseSettlFlag:";
		printOpenCloseSettlFlag(ostr,openCloseSettlFlag) << " ";
		SettlPriceType &settlPriceType = mdEntry.settlPriceType();
		ostr << "settlPriceType:";
		printSettlPriceType(ostr,settlPriceType) << " ";
		ostr << "\t}\n\n";
	}
	ostr << "</MDIncRefresh_103>";
}

void print_xml(std::ostream & ostr,MDInstrumentDefinitionFuture27 &instrumentDefinitionFuture27) {
	ostr << "<MDInstrumentDefinitionFuture27 ";
    //<field name="MatchEventIndicator" id="5799" type="MatchEventIndicator" description="Bitmap field of eight Boolean type indicators reflecting the end of updates for a given Globex event" offset="0" semanticType="MultipleCharValue"/>
	ostr << " MatchEventIndicator=";
	printMatchEventIndicator(ostr,instrumentDefinitionFuture27.matchEventIndicator()) << " ";
    //<field name="TotNumReports" id="911" type="uInt32NULL" description="Total number of instruments in the Replay loop. Used on Replay Feed only " offset="1" semanticType="int"/>
	ostr << " TotNumReports=" << instrumentDefinitionFuture27.totNumReports()  << " ";
	//<field name="SecurityUpdateAction" id="980" type="SecurityUpdateAction" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="5" semanticType="char"/>
	SecurityUpdateAction::Value ua = instrumentDefinitionFuture27.securityUpdateAction();
	ostr << " SecurityUpdateAction=";
	printSecurityUpdateAction(ostr,ua)  << " ";
    //<field name="LastUpdateTime" id="779" type="uInt64" description="Timestamp of when the instrument was last added, modified or deleted" offset="6" semanticType="UTCTimestamp"/>
	ostr << " LastUpdateTime=" << instrumentDefinitionFuture27.lastUpdateTime()  << " ";
	//<field name="MDSecurityTradingStatus" id="1682" type="SecurityTradingStatus" description="Identifies the current state of the instrument. In Security Definition message this tag is available in the Instrument Replay feed only " offset="14" semanticType="int"/>
	ostr << " MDSecurityTradingStatus=" << instrumentDefinitionFuture27.mDSecurityTradingStatus() << " ";
	//<field name="ApplID" id="1180" type="Int16" description="The channel ID as defined in the XML Configuration file" offset="15" semanticType="int"/>
	ostr << " ApplID=" << instrumentDefinitionFuture27.applID() << " ";
	//<field name="MarketSegmentID" id="1300" type="uInt8" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="17" semanticType="int"/>
	ostr << " MarketSegmentID=" << instrumentDefinitionFuture27.marketSegmentID() << " ";
	//<field name="UnderlyingProduct" id="462" type="uInt8" description="Product complex" offset="18" semanticType="int"/>
	ostr << " UnderlyingProduct=" << instrumentDefinitionFuture27.underlyingProduct() << " ";
	//<field name="SecurityExchange" id="207" type="SecurityExchange" description="Exchange used to identify a security" offset="19" semanticType="Exchange"/>
	ostr << " SecurityExchange=" << instrumentDefinitionFuture27.securityExchange() << " ";
    //<field name="SecurityGroup" id="1151" type="SecurityGroup" description="Security Group Code." offset="23" semanticType="String"/>
	ostr << " SecurityGroup=" << instrumentDefinitionFuture27.securityGroup() << " ";
	//<field name="Asset" id="6937" type="Asset" description="The underlying asset code also known as Product Code" offset="29" semanticType="String"/>
	ostr << " Asset=" << instrumentDefinitionFuture27.asset() << " ";
    //<field name="Symbol" id="55" type="Symbol" description="Instrument Name or Symbol " offset="35" semanticType="String"/>
	ostr << " Symbol=" << instrumentDefinitionFuture27.symbol() << " ";
    //<field name="SecurityID" id="48" type="Int32" description="Unique instrument ID" offset="55" semanticType="int"/>
	ostr << " SecurityID=" << instrumentDefinitionFuture27.securityID() << " ";
	//<field name="SecurityIDSource" id="22" type="SecurityIDSource" description="Identifies class or source of tag 48-SecurityID value" semanticType="char"/>
	ostr << " SecurityIDSource=" << instrumentDefinitionFuture27.securityIDSource() << " ";
	//<field name="SecurityType" id="167" type="SecurityType" description="Security Type" offset="59" semanticType="String"/>
	ostr << " SecurityType=" << instrumentDefinitionFuture27.securityType() << " ";
    //<field name="CFICode" id="461" type="CFICode" description="ISO standard instrument categorization code" offset="65" semanticType="String"/>
	ostr << " CFICode=" << instrumentDefinitionFuture27.cFICode() << " ";
    //<field name="MaturityMonthYear" id="200" type="MaturityMonthYear" description="This field provides the actual calendar date for contract maturity" offset="71" semanticType="MonthYear"/>
	MaturityMonthYear maturityMonthYear = instrumentDefinitionFuture27.maturityMonthYear();
	ostr << " MaturityMonthYear=" << maturityMonthYear.year() << maturityMonthYear.month() << " ";
    //<field name="Currency" id="15" type="Currency" description="Identifies currency used for price" offset="76" semanticType="Currency"/>
	ostr << " Currency=" << instrumentDefinitionFuture27.currency() << " ";
    //<field name="SettlCurrency" id="120" type="Currency" description="Identifies currency used for settlement, if different from trading currency" offset="79" semanticType="Currency"/>
	ostr << " SettlCurrency=" << instrumentDefinitionFuture27.settlCurrency() << " ";
    //<field name="MatchAlgorithm" id="1142" type="CHAR" description="Matching algorithm " offset="82" semanticType="char"/>
	ostr << " MatchAlgorithm=" << instrumentDefinitionFuture27.matchAlgorithm() << " ";
    //<field name="MinTradeVol" id="562" type="uInt32" description="The minimum trading volume for a security" offset="83" semanticType="Qty"/>
	ostr << " MinTradeVol=" << instrumentDefinitionFuture27.minTradeVol() << " ";
    //<field name="MaxTradeVol" id="1140" type="uInt32" description="The maximum trading volume for a security" offset="87" semanticType="Qty"/>
	ostr << " MaxTradeVol=" << instrumentDefinitionFuture27.maxTradeVol() << " ";
    //<field name="MinPriceIncrement" id="969" type="PRICE" description="Minimum constant tick for the instrument, sent only if instrument is non-VTT (Variable Tick table) eligible" offset="91" semanticType="Price"/>
	ostr << " MinPriceIncrement=";
	PRICE& minPriceIncrement=instrumentDefinitionFuture27.minPriceIncrement();
	printPRICE(ostr,minPriceIncrement) << " ";
    //<field name="DisplayFactor" id="9787" type="FLOAT" description="Contains the multiplier to convert the CME Globex display price to the conventional price" offset="99" semanticType="float"/>
	ostr << " DisplayFactor=";
	FLOAT& displayFactor=instrumentDefinitionFuture27.displayFactor();
	printFLOAT(ostr,displayFactor) << " ";
    //<field name="MainFraction" id="37702" type="uInt8NULL" description="Price Denominator of Main Fraction" offset="107" semanticType="int"/>
	ostr << " MainFraction=" << instrumentDefinitionFuture27.mainFraction() << " ";
    //<field name="SubFraction" id="37703" type="uInt8NULL" description="Price Denominator of Sub Fraction" offset="108" semanticType="int"/>
	ostr << " SubFraction=" << instrumentDefinitionFuture27.subFraction() << " ";
    //<field name="PriceDisplayFormat" id="9800" type="uInt8NULL" description="Number of decimals in fractional display price" offset="109" semanticType="int"/>
	ostr << " PriceDisplayFormat=" << instrumentDefinitionFuture27.priceDisplayFormat() << " ";
    //<field name="UnitOfMeasure" id="996" type="UnitOfMeasure" description="Unit of measure for the products' original contract size. This will be populated for all products listed on CME Globex" offset="110" semanticType="String"/>
	ostr << " UnitOfMeasure=" << instrumentDefinitionFuture27.unitOfMeasure() << " ";
    //<field name="UnitOfMeasureQty" id="1147" type="PRICENULL" description="This field contains the contract size for each instrument. Used in combination with tag 996-UnitofMeasure" offset="140" semanticType="Qty"/>
	ostr << " UnitOfMeasureQty=";
	PRICENULL& unitOfMeasureQty=instrumentDefinitionFuture27.tradingReferencePrice();
	printPRICENULL(ostr,unitOfMeasureQty) << " ";
    //<field name="TradingReferencePrice" id="1150" type="PRICENULL" description="Reference price for prelisted instruments or the last calculated Settlement whether it be Theoretical, Preliminary or a Final Settle of the session." offset="148" semanticType="Price"/>
	ostr << " TradingReferencePrice=";
	PRICENULL& tradingReferencePrice=instrumentDefinitionFuture27.tradingReferencePrice();
	printPRICENULL(ostr,tradingReferencePrice) << " ";
    //<field name="SettlPriceType" id="731" type="SettlPriceType" description="Bitmap field of eight Boolean type indicators representing settlement price type" offset="156" semanticType="MultipleCharValue"/>
	ostr << " SettlPriceType=" << printSettlPriceType(ostr,instrumentDefinitionFuture27.settlPriceType()) << " ";
    //<field name="OpenInterestQty" id="5792" type="Int32NULL" description="The total open interest for the market at the close of the prior trading session." offset="157" semanticType="int"/>
	ostr << " OpenInterestQty=" << instrumentDefinitionFuture27.openInterestQty() << " ";
    //<field name="ClearedVolume" id="5791" type="Int32NULL" description="The total cleared volume of instrument traded during the prior trading session." offset="161" semanticType="int"/>
	ostr << " ClearedVolume=" << instrumentDefinitionFuture27.clearedVolume() << " ";
    //<field name="HighLimitPrice" id="1149" type="PRICENULL" description="Allowable high limit price for the trading day" offset="165" semanticType="Price"/>
	ostr << " HighLimitPrice=";
	PRICENULL& highLimitPrice=instrumentDefinitionFuture27.highLimitPrice();
	printPRICENULL(ostr,highLimitPrice) << " ";
    //<field name="LowLimitPrice" id="1148" type="PRICENULL" description="Allowable low limit price for the trading day" offset="173" semanticType="Price"/>
	ostr << " LowLimitPrice=";
	PRICENULL& lowLimitPrice=instrumentDefinitionFuture27.lowLimitPrice();
	printPRICENULL(ostr,lowLimitPrice) << " ";
    //<field name="MaxPriceVariation" id="1143" type="PRICENULL" description="Differential value for price banding." offset="181" semanticType="Price"/>
	ostr << " MaxPriceVariation=";
	PRICENULL& maxPriceVariation=instrumentDefinitionFuture27.maxPriceVariation();
	printPRICENULL(ostr,maxPriceVariation) << " ";
    //<field name="DecayQuantity" id="5818" type="Int32NULL" description="Indicates the quantity that a contract will decay daily by once the decay start date is reached" offset="189" semanticType="Qty"/>
	ostr << " DecayQuantity=" << instrumentDefinitionFuture27.decayQuantity() << " ";
    //<field name="DecayStartDate" id="5819" type="LocalMktDate" description="Indicates the date at which a decaying contract will begin to decay" offset="193" semanticType="LocalMktDate"/>
	ostr << " DecayStartDate=" << instrumentDefinitionFuture27.decayStartDate() << " ";
    //<field name="OriginalContractSize" id="5849" type="Int32NULL" description="Fixed contract value assigned to each product" offset="195" semanticType="Qty"/>
	ostr << " OriginalContractSize=" << instrumentDefinitionFuture27.originalContractSize() << " ";
    //<field name="ContractMultiplier" id="231" type="Int32NULL" description="Number of deliverable units per instrument, e.g., peak days in maturity month or number of calendar days in maturity month" offset="199" semanticType="int"/>
	ostr << " ContractMultiplier=" << instrumentDefinitionFuture27.contractMultiplier() << " ";
    //<field name="ContractMultiplierUnit" id="1435" type="Int8NULL" description="Indicates the type of multiplier being applied to the product. Optionally used in combination with tag 231-ContractMultiplier" offset="203" semanticType="int"/>
	ostr << " ContractMultiplierUnit=" << instrumentDefinitionFuture27.contractMultiplierUnit() << " ";
    //<field name="FlowScheduleType" id="1439" type="Int8NULL" description="The schedule according to which the electricity is delivered in a physical contract, or priced in a financial contract. Specifies whether the contract is defined according to the Easter Peak, Eastern Off-Peak, Western Peak or Western Off-Peak." offset="204" semanticType="int"/>
	ostr << " FlowScheduleType=" << instrumentDefinitionFuture27.contractMultiplierUnit() << " ";
    //<field name="MinPriceIncrementAmount" id="1146" type="PRICENULL" description="Monetary value equivalent to the minimum price fluctuation" offset="205" semanticType="Price"/>
	ostr << " MinPriceIncrementAmount=";
	PRICENULL& minPriceIncrementAmount=instrumentDefinitionFuture27.minPriceIncrementAmount();
	printPRICENULL(ostr,minPriceIncrementAmount) << " ";
    //<field name="UserDefinedInstrument" id="9779" type="UserDefinedInstrument" description="User-defined instruments flag" offset="213" sinceVersion="3" semanticType="char"/>
	ostr << " UserDefinedInstrument=" << instrumentDefinitionFuture27.userDefinedInstrument() << " ";
	ostr << " />\n";
}

std::ostream &  delim_header_InstrumentDefinitionFuture27(std::ostream & ostr,char delim='|') {
	ostr << "MsgSeqNum" << delim;
	ostr << "SendingTime" << delim;
    //<field name="MatchEventIndicator" id="5799" type="MatchEventIndicator" description="Bitmap field of eight Boolean type indicators reflecting the end of updates for a given Globex event" offset="0" semanticType="MultipleCharValue"/>
	ostr << "MatchEventIndicator" << delim;
    //<field name="TotNumReports" id="911" type="uInt32NULL" description="Total number of instruments in the Replay loop. Used on Replay Feed only " offset="1" semanticType="int"/>
	ostr << "TotNumReports"<< delim;
	//<field name="SecurityUpdateAction" id="980" type="SecurityUpdateAction" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="5" semanticType="char"/>
	ostr << "SecurityUpdateAction"<< delim;
    //<field name="LastUpdateTime" id="779" type="uInt64" description="Timestamp of when the instrument was last added, modified or deleted" offset="6" semanticType="UTCTimestamp"/>
	ostr << "LastUpdateTime"<< delim;
	//<field name="MDSecurityTradingStatus" id="1682" type="SecurityTradingStatus" description="Identifies the current state of the instrument. In Security Definition message this tag is available in the Instrument Replay feed only " offset="14" semanticType="int"/>
	ostr << "MDSecurityTradingStatus"<< delim;
	//<field name="ApplID" id="1180" type="Int16" description="The channel ID as defined in the XML Configuration file" offset="15" semanticType="int"/>
	ostr << "ApplID"<< delim;
	//<field name="MarketSegmentID" id="1300" type="uInt8" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="17" semanticType="int"/>
	ostr << "MarketSegmentID"<< delim;
	//<field name="UnderlyingProduct" id="462" type="uInt8" description="Product complex" offset="18" semanticType="int"/>
	ostr << "UnderlyingProduct"<< delim;
	//<field name="SecurityExchange" id="207" type="SecurityExchange" description="Exchange used to identify a security" offset="19" semanticType="Exchange"/>
	ostr << "SecurityExchange"<< delim;
    //<field name="SecurityGroup" id="1151" type="SecurityGroup" description="Security Group Code." offset="23" semanticType="String"/>
	ostr << "SecurityGroup"<< delim;
	//<field name="Asset" id="6937" type="Asset" description="The underlying asset code also known as Product Code" offset="29" semanticType="String"/>
	ostr << "Asset"<< delim;
    //<field name="Symbol" id="55" type="Symbol" description="Instrument Name or Symbol " offset="35" semanticType="String"/>
	ostr << "Symbol"<< delim;
    //<field name="SecurityID" id="48" type="Int32" description="Unique instrument ID" offset="55" semanticType="int"/>
	ostr << "SecurityID"<< delim;
	//<field name="SecurityIDSource" id="22" type="SecurityIDSource" description="Identifies class or source of tag 48-SecurityID value" semanticType="char"/>
	ostr << "SecurityIDSource"<< delim;
	//<field name="SecurityType" id="167" type="SecurityType" description="Security Type" offset="59" semanticType="String"/>
	ostr << "SecurityType"<< delim;
    //<field name="CFICode" id="461" type="CFICode" description="ISO standard instrument categorization code" offset="65" semanticType="String"/>
	ostr << "CFICode"<< delim;
    //<field name="MaturityMonthYear" id="200" type="MaturityMonthYear" description="This field provides the actual calendar date for contract maturity" offset="71" semanticType="MonthYear"/>
	ostr << "MaturityMonthYear"<< delim;
    //<field name="Currency" id="15" type="Currency" description="Identifies currency used for price" offset="76" semanticType="Currency"/>
	ostr << "Currency"<< delim;
    //<field name="SettlCurrency" id="120" type="Currency" description="Identifies currency used for settlement, if different from trading currency" offset="79" semanticType="Currency"/>
	ostr << "SettlCurrency"<< delim;
    //<field name="MatchAlgorithm" id="1142" type="CHAR" description="Matching algorithm " offset="82" semanticType="char"/>
	ostr << "MatchAlgorithm"<< delim;
    //<field name="MinTradeVol" id="562" type="uInt32" description="The minimum trading volume for a security" offset="83" semanticType="Qty"/>
	ostr << "MinTradeVol"<< delim;
    //<field name="MaxTradeVol" id="1140" type="uInt32" description="The maximum trading volume for a security" offset="87" semanticType="Qty"/>
	ostr << "MaxTradeVol"<< delim;
    //<field name="MinPriceIncrement" id="969" type="PRICE" description="Minimum constant tick for the instrument, sent only if instrument is non-VTT (Variable Tick table) eligible" offset="91" semanticType="Price"/>
	ostr << "MinPriceIncrement"<< delim;
    //<field name="DisplayFactor" id="9787" type="FLOAT" description="Contains the multiplier to convert the CME Globex display price to the conventional price" offset="99" semanticType="float"/>
	ostr << "DisplayFactor"<< delim;
    //<field name="MainFraction" id="37702" type="uInt8NULL" description="Price Denominator of Main Fraction" offset="107" semanticType="int"/>
	ostr << "MainFraction"<< delim;
    //<field name="SubFraction" id="37703" type="uInt8NULL" description="Price Denominator of Sub Fraction" offset="108" semanticType="int"/>
	ostr << "SubFraction"<< delim;
    //<field name="PriceDisplayFormat" id="9800" type="uInt8NULL" description="Number of decimals in fractional display price" offset="109" semanticType="int"/>
	ostr << "PriceDisplayFormat"<< delim;
    //<field name="UnitOfMeasure" id="996" type="UnitOfMeasure" description="Unit of measure for the products' original contract size. This will be populated for all products listed on CME Globex" offset="110" semanticType="String"/>
	ostr << "UnitOfMeasure"<< delim;
    //<field name="UnitOfMeasureQty" id="1147" type="PRICENULL" description="This field contains the contract size for each instrument. Used in combination with tag 996-UnitofMeasure" offset="140" semanticType="Qty"/>
	ostr << "UnitOfMeasureQty"<< delim;
    //<field name="TradingReferencePrice" id="1150" type="PRICENULL" description="Reference price for prelisted instruments or the last calculated Settlement whether it be Theoretical, Preliminary or a Final Settle of the session." offset="148" semanticType="Price"/>
	ostr << "TradingReferencePrice"<< delim;
    //<field name="SettlPriceType" id="731" type="SettlPriceType" description="Bitmap field of eight Boolean type indicators representing settlement price type" offset="156" semanticType="MultipleCharValue"/>
	ostr << "SettlPriceType"<< delim;
    //<field name="OpenInterestQty" id="5792" type="Int32NULL" description="The total open interest for the market at the close of the prior trading session." offset="157" semanticType="int"/>
	ostr << "OpenInterestQty"<< delim;
    //<field name="ClearedVolume" id="5791" type="Int32NULL" description="The total cleared volume of instrument traded during the prior trading session." offset="161" semanticType="int"/>
	ostr << "ClearedVolume";
    //<field name="HighLimitPrice" id="1149" type="PRICENULL" description="Allowable high limit price for the trading day" offset="165" semanticType="Price"/>
	ostr << "HighLimitPrice"<< delim;
    //<field name="LowLimitPrice" id << delim;="1148" type="PRICENULL" description="Allowable low limit price for the trading day" offset="173" semanticType="Price"/>
	ostr << "LowLimitPrice"<< delim;
    //<field name="MaxPriceVariation" id="1143" type="PRICENULL" description="Differential value for price banding." offset="181" semanticType="Price"/>
	ostr << "MaxPriceVariation"<< delim;
    //<field name="DecayQuantity" id="5818" type="Int32NULL" description="Indicates the quantity that a contract will decay daily by once the decay start date is reached" offset="189" semanticType="Qty"/>
	ostr << "DecayQuantity"<< delim;
    //<field name="DecayStartDate" id="5819" type="LocalMktDate" description="Indicates the date at which a decaying contract will begin to decay" offset="193" semanticType="LocalMktDate"/>
	ostr << "DecayStartDate"<< delim;
    //<field name="OriginalContractSize" id="5849" type="Int32NULL" description="Fixed contract value assigned to each product" offset="195" semanticType="Qty"/>
	ostr << "OriginalContractSize"<< delim;
    //<field name="ContractMultiplier" id="231" type="Int32NULL" description="Number of deliverable units per instrument, e.g., peak days in maturity month or number of calendar days in maturity month" offset="199" semanticType="int"/>
	ostr << "ContractMultiplier"<< delim;
    //<field name="ContractMultiplierUnit" id="1435" type="Int8NULL" description="Indicates the type of multiplier being applied to the product. Optionally used in combination with tag 231-ContractMultiplier" offset="203" semanticType="int"/>
	ostr << "ContractMultiplierUnit"<< delim;
    //<field name="FlowScheduleType" id="1439" type="Int8NULL" description="The schedule according to which the electricity is delivered in a physical contract, or priced in a financial contract. Specifies whether the contract is defined according to the Easter Peak, Eastern Off-Peak, Western Peak or Western Off-Peak." offset="204" semanticType="int"/>
	ostr << "FlowScheduleType"<< delim;
    //<field name="MinPriceIncrementAmount" id="1146" type="PRICENULL" description="Monetary value equivalent to the minimum price fluctuation" offset="205" semanticType="Price"/>
	ostr << "MinPriceIncrementAmount"<< delim;
    //<field name="UserDefinedInstrument" id="9779" type="UserDefinedInstrument" description="User-defined instruments flag" offset="213" sinceVersion="3" semanticType="char"/>
	ostr << "UserDefinedInstrument" << std::endl;

	return ostr;
}


void delim_value(
		std::ostream & ostr,
		MDInstrumentDefinitionFuture27 &instrumentDefinitionFuture27,
		uint32_t msgSeqNum,
		uint64_t sendingTime,
		char delim='|') {
	ostr << msgSeqNum << delim << sendingTime << delim;
	//<field name="MatchEventIndicator" id="5799" type="MatchEventIndicator" description="Bitmap field of eight Boolean type indicators reflecting the end of updates for a given Globex event" offset="0" semanticType="MultipleCharValue"/>
	printMatchEventIndicator(ostr,instrumentDefinitionFuture27.matchEventIndicator()) << delim;

    //<field name="TotNumReports" id="911" type="uInt32NULL" description="Total number of instruments in the Replay loop. Used on Replay Feed only " offset="1" semanticType="int"/>
	ostr << instrumentDefinitionFuture27.totNumReports()  << delim;

	//<field name="SecurityUpdateAction" id="980" type="SecurityUpdateAction" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="5" semanticType="char"/>
	SecurityUpdateAction::Value ua = instrumentDefinitionFuture27.securityUpdateAction();
	printSecurityUpdateAction(ostr,ua)  << delim;

    //<field name="LastUpdateTime" id="779" type="uInt64" description="Timestamp of when the instrument was last added, modified or deleted" offset="6" semanticType="UTCTimestamp"/>
	ostr<< instrumentDefinitionFuture27.lastUpdateTime()  << delim;

	//<field name="MDSecurityTradingStatus" id="1682" type="SecurityTradingStatus" description="Identifies the current state of the instrument. In Security Definition message this tag is available in the Instrument Replay feed only " offset="14" semanticType="int"/>
	SecurityTradingStatus::Value mDSecurityTradingStatus= instrumentDefinitionFuture27.mDSecurityTradingStatus();
	printSecurityTradingStatus(ostr,mDSecurityTradingStatus) << delim;

	//<field name="ApplID" id="1180" type="Int16" description="The channel ID as defined in the XML Configuration file" offset="15" semanticType="int"/>
	ostr<< instrumentDefinitionFuture27.applID() << delim;

	//<field name="MarketSegmentID" id="1300" type="uInt8" description="Last Security update action on Incremental feed, 'D' or 'M' is used when a mid-week deletion or modification (i.e. extension) occurs" offset="17" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.marketSegmentID() << delim;

	//<field name="UnderlyingProduct" id="462" type="uInt8" description="Product complex" offset="18" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.underlyingProduct() << delim;

	//<field name="SecurityExchange" id="207" type="SecurityExchange" description="Exchange used to identify a security" offset="19" semanticType="Exchange"/>
	ostr<< instrumentDefinitionFuture27.securityExchange() << delim;

    //<field name="SecurityGroup" id="1151" type="SecurityGroup" description="Security Group Code." offset="23" semanticType="String"/>
	ostr<< instrumentDefinitionFuture27.securityGroup() << delim;

	//<field name="Asset" id="6937" type="Asset" description="The underlying asset code also known as Product Code" offset="29" semanticType="String"/>
	ostr<< instrumentDefinitionFuture27.asset() << delim;

    //<field name="Symbol" id="55" type="Symbol" description="Instrument Name or Symbol " offset="35" semanticType="String"/>
	ostr<< instrumentDefinitionFuture27.symbol() << delim;

    //<field name="SecurityID" id="48" type="Int32" description="Unique instrument ID" offset="55" semanticType="int"/>
	ostr<< instrumentDefinitionFuture27.securityID() << delim;

	//<field name="SecurityIDSource" id="22" type="SecurityIDSource" description="Identifies class or source of tag 48-SecurityID value" semanticType="char"/>
	ostr<< instrumentDefinitionFuture27.securityIDSource() << delim;

	//<field name="SecurityType" id="167" type="SecurityType" description="Security Type" offset="59" semanticType="String"/>
	ostr<< instrumentDefinitionFuture27.securityType() << delim;

    //<field name="CFICode" id="461" type="CFICode" description="ISO standard instrument categorization code" offset="65" semanticType="String"/>
	ostr<< std::string(instrumentDefinitionFuture27.cFICode(),instrumentDefinitionFuture27.cFICodeLength()) << delim;

	//<field name="MaturityMonthYear" id="200" type="MaturityMonthYear" description="This field provides the actual calendar date for contract maturity" offset="71" semanticType="MonthYear"/>
	MaturityMonthYear maturityMonthYear = instrumentDefinitionFuture27.maturityMonthYear();
	ostr<< (uint32_t)maturityMonthYear.year() << (uint32_t)maturityMonthYear.month() << delim;
	ostr << delim;

    //<field name="Currency" id="15" type="Currency" description="Identifies currency used for price" offset="76" semanticType="Currency"/>
	ostr<< instrumentDefinitionFuture27.currency() << delim;

    //<field name="SettlCurrency" id="120" type="Currency" description="Identifies currency used for settlement, if different from trading currency" offset="79" semanticType="Currency"/>
	ostr<< instrumentDefinitionFuture27.settlCurrency() << delim;

    //<field name="MatchAlgorithm" id="1142" type="CHAR" description="Matching algorithm " offset="82" semanticType="char"/>
	ostr<< instrumentDefinitionFuture27.matchAlgorithm() << delim;

    //<field name="MinTradeVol" id="562" type="uInt32" description="The minimum trading volume for a security" offset="83" semanticType="Qty"/>
	ostr<< instrumentDefinitionFuture27.minTradeVol() << delim;

    //<field name="MaxTradeVol" id="1140" type="uInt32" description="The maximum trading volume for a security" offset="87" semanticType="Qty"/>
	ostr<< instrumentDefinitionFuture27.maxTradeVol() << delim;

    //<field name="MinPriceIncrement" id="969" type="PRICE" description="Minimum constant tick for the instrument, sent only if instrument is non-VTT (Variable Tick table) eligible" offset="91" semanticType="Price"/>
	PRICE& minPriceIncrement=instrumentDefinitionFuture27.minPriceIncrement();
	printPRICE(ostr,minPriceIncrement) << delim;

    //<field name="DisplayFactor" id="9787" type="FLOAT" description="Contains the multiplier to convert the CME Globex display price to the conventional price" offset="99" semanticType="float"/>
	FLOAT& displayFactor=instrumentDefinitionFuture27.displayFactor();
	printFLOAT(ostr,displayFactor) << delim;

    //<field name="MainFraction" id="37702" type="uInt8NULL" description="Price Denominator of Main Fraction" offset="107" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.mainFraction() << delim;

    //<field name="SubFraction" id="37703" type="uInt8NULL" description="Price Denominator of Sub Fraction" offset="108" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.subFraction() << delim;

    //<field name="PriceDisplayFormat" id="9800" type="uInt8NULL" description="Number of decimals in fractional display price" offset="109" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.priceDisplayFormat() << delim;

    //<field name="UnitOfMeasure" id="996" type="UnitOfMeasure" description="Unit of measure for the products' original contract size. This will be populated for all products listed on CME Globex" offset="110" semanticType="String"/>
	ostr<< instrumentDefinitionFuture27.unitOfMeasure() << delim;

    //<field name="UnitOfMeasureQty" id="1147" type="PRICENULL" description="This field contains the contract size for each instrument. Used in combination with tag 996-UnitofMeasure" offset="140" semanticType="Qty"/>
	PRICENULL& unitOfMeasureQty=instrumentDefinitionFuture27.tradingReferencePrice();
	printPRICENULL(ostr,unitOfMeasureQty) << delim;

    //<field name="TradingReferencePrice" id="1150" type="PRICENULL" description="Reference price for prelisted instruments or the last calculated Settlement whether it be Theoretical, Preliminary or a Final Settle of the session." offset="148" semanticType="Price"/>
	PRICENULL& tradingReferencePrice=instrumentDefinitionFuture27.tradingReferencePrice();
	printPRICENULL(ostr,tradingReferencePrice) << delim;

    //<field name="SettlPriceType" id="731" type="SettlPriceType" description="Bitmap field of eight Boolean type indicators representing settlement price type" offset="156" semanticType="MultipleCharValue"/>
	printSettlPriceType(ostr,instrumentDefinitionFuture27.settlPriceType()) << delim;

    //<field name="OpenInterestQty" id="5792" type="Int32NULL" description="The total open interest for the market at the close of the prior trading session." offset="157" semanticType="int"/>
	ostr<< instrumentDefinitionFuture27.openInterestQty() << delim;

    //<field name="ClearedVolume" id="5791" type="Int32NULL" description="The total cleared volume of instrument traded during the prior trading session." offset="161" semanticType="int"/>
	ostr<< instrumentDefinitionFuture27.clearedVolume() << delim;

    //<field name="HighLimitPrice" id="1149" type="PRICENULL" description="Allowable high limit price for the trading day" offset="165" semanticType="Price"/>
	PRICENULL& highLimitPrice=instrumentDefinitionFuture27.highLimitPrice();
	printPRICENULL(ostr,highLimitPrice) << delim;

    //<field name="LowLimitPrice" id="1148" type="PRICENULL" description="Allowable low limit price for the trading day" offset="173" semanticType="Price"/>
	PRICENULL& lowLimitPrice=instrumentDefinitionFuture27.lowLimitPrice();
	printPRICENULL(ostr,lowLimitPrice) << delim;

    //<field name="MaxPriceVariation" id="1143" type="PRICENULL" description="Differential value for price banding." offset="181" semanticType="Price"/>
	PRICENULL& maxPriceVariation=instrumentDefinitionFuture27.maxPriceVariation();
	printPRICENULL(ostr,maxPriceVariation) << delim;

    //<field name="DecayQuantity" id="5818" type="Int32NULL" description="Indicates the quantity that a contract will decay daily by once the decay start date is reached" offset="189" semanticType="Qty"/>
	ostr<< instrumentDefinitionFuture27.decayQuantity() << delim;

    //<field name="DecayStartDate" id="5819" type="LocalMktDate" description="Indicates the date at which a decaying contract will begin to decay" offset="193" semanticType="LocalMktDate"/>
	ostr<< instrumentDefinitionFuture27.decayStartDate() << delim;

    //<field name="OriginalContractSize" id="5849" type="Int32NULL" description="Fixed contract value assigned to each product" offset="195" semanticType="Qty"/>
	ostr<< instrumentDefinitionFuture27.originalContractSize() << delim;

    //<field name="ContractMultiplier" id="231" type="Int32NULL" description="Number of deliverable units per instrument, e.g., peak days in maturity month or number of calendar days in maturity month" offset="199" semanticType="int"/>
	ostr<< instrumentDefinitionFuture27.contractMultiplier() << delim;

    //<field name="ContractMultiplierUnit" id="1435" type="Int8NULL" description="Indicates the type of multiplier being applied to the product. Optionally used in combination with tag 231-ContractMultiplier" offset="203" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.contractMultiplierUnit() << delim;

    //<field name="FlowScheduleType" id="1439" type="Int8NULL" description="The schedule according to which the electricity is delivered in a physical contract, or priced in a financial contract. Specifies whether the contract is defined according to the Easter Peak, Eastern Off-Peak, Western Peak or Western Off-Peak." offset="204" semanticType="int"/>
	ostr<< (uint32_t)instrumentDefinitionFuture27.flowScheduleType() << delim;

    //<field name="MinPriceIncrementAmount" id="1146" type="PRICENULL" description="Monetary value equivalent to the minimum price fluctuation" offset="205" semanticType="Price"/>
	PRICENULL& minPriceIncrementAmount=instrumentDefinitionFuture27.minPriceIncrementAmount();
	printPRICENULL(ostr,minPriceIncrementAmount) << delim;

    //<field name="UserDefinedInstrument" id="9779" type="UserDefinedInstrument" description="User-defined instruments flag" offset="213" sinceVersion="3" semanticType="char"/>
	ostr<< instrumentDefinitionFuture27.userDefinedInstrument();

	ostr << std::endl;
}

#endif
