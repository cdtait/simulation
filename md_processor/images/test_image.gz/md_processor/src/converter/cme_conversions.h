#ifndef cme_conversions_h
#define cme_conversions_h

#include <map>

#include <book/md_order_book.h>
#include <book/md_order_book3.h>
#include <book/md_order_book4.h>

#include "book2_conversions.h"

#include "mktdata/MessageHeader.hpp"
#include "mktdata/SnapshotFullRefresh38.hpp"
#include "mktdata/MDIncrementalRefreshBook32.hpp"
#include "mktdata/MDIncrementalRefreshTrade36.hpp"
#include "mktdata/MDIncrementalRefreshTradeSummary42.hpp"
#include "mktdata/MDInstrumentDefinitionFuture27.hpp"
#include "mktdata/MDInstrumentDefinitionOption41.hpp"
#include "mktdata/MDInstrumentDefinitionSpread29.hpp"

#include "book/stream_state.h"

using namespace mktdata;

template<typename BookContainer>
void book_type_insert(BookContainer& book,
		uint32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders, MDEntryType::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime)
{
	book.set_event(Event::Snapshot);

	switch (mDEntryType) {
	case MDEntryType::Bid: {
		book_bid_insert(book, mDPriceLevel,
				price, quantity,
				orders, rptSeq, transactTime,
				msgSeqNum, sendingTime);
		break;
	}
	case MDEntryType::Offer: {
		book_ask_insert(book, mDPriceLevel,
				price, quantity,
				orders, rptSeq, transactTime,
				msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_insert(BookContainer& book,
		uint32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders, MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Add);

	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_insert(book, mDPriceLevel, price,
				quantity, orders,
				rptSeq, transactTime,
				msgSeqNum, sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_insert(book, mDPriceLevel, price,
				quantity, orders,
				rptSeq, transactTime,
				msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_change(BookContainer& book,
		uint32_t mDPriceLevel, uint32_t quantity,
		uint32_t orders, MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_change(book, mDPriceLevel, quantity,
				orders, rptSeq,
				transactTime, msgSeqNum,
				sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_change(book, mDPriceLevel, quantity,
				orders, rptSeq,
				transactTime, msgSeqNum,
				sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_remove(BookContainer& book,
		uint32_t mDPriceLevel,MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_remove(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_remove(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_removeThru(BookContainer& book,
		uint32_t mDPriceLevel,MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_removeThru(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_removeThru(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_removeFrom(BookContainer& book,
		uint32_t mDPriceLevel,MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_removeThru(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_removeThru(book, mDPriceLevel, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

template<typename BookContainer>
void book_type_overlay(BookContainer& book,
		uint32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders, MDEntryTypeBook::Value mDEntryType,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	switch (mDEntryType) {
	case MDEntryTypeBook::Bid: {
		book_bid_overlay(book, mDPriceLevel, price, quantity, orders, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	case MDEntryTypeBook::Offer: {
		book_ask_overlay(book, mDPriceLevel, price, quantity, orders, rptSeq,
				transactTime,msgSeqNum, sendingTime);
		break;
	}
	default:
		break;
	}
}

#endif
