#ifndef book2_conversions_h
#define book2_conversions_h

#include <map>

#include <book/md_order_book.h>
#include <book/md_order_book2.h>

#include "book/stream_state.h"

using namespace mktdata;

void book_bid_insert(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.bid().insert(mDPriceLevel, price, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_insert(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.ask().insert(mDPriceLevel, price, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_snapshot(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book_bid_insert(book,mDPriceLevel, price, quantity,
			orders,rptSeq,transactTime,
			msgSeqNum,sendingTime);
}

void book_ask_snapshot(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book_ask_insert(book,mDPriceLevel, price, quantity,
			orders,rptSeq,transactTime,
			msgSeqNum,sendingTime);
}

void trade_insert(md_order_book2& book,
		const price_t & price, uint32_t quantity,
		uint32_t orders, AggressorSide::Value aggressorSide,
		int32_t numberOfOrders, int32_t tradeID,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Trade);
	book.set_aggressor_time(transactTime);
	book.set_trade_price(price);
	book.set_trade_quantity(quantity);
	if (AggressorSide::Buy) {
		book.set_trade_side(TradeSide::Ask);
	}
	else if (AggressorSide::Sell) {
		book.set_trade_side(TradeSide::Bid);
	}
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_change(md_order_book2& book,
		int32_t mDPriceLevel,  uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Change);
	book.bid().change(mDPriceLevel, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void trade_volume(md_order_book2& book,
		uint32_t quantity,
		uint32_t rptSeq, uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Volume);
	book.set_trade_volume(quantity);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_change(md_order_book2& book,
		int32_t mDPriceLevel,  uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Change);
	book.ask().change(mDPriceLevel, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_remove(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.bid().remove(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_remove(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.ask().remove(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_removeThru(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.bid().removeThru(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_removeThru(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.ask().removeThru(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_removeFrom(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.bid().removeThru(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_removeFrom(md_order_book2& book,
		int32_t mDPriceLevel,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Delete);
	book.ask().removeThru(mDPriceLevel);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_bid_overlay(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Overlay);
	book.bid().overlay(mDPriceLevel, price, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void book_ask_overlay(md_order_book2& book,
		int32_t mDPriceLevel, const price_t & price, uint32_t quantity,
		uint32_t orders,
		uint32_t rptSeq,uint64_t transactTime,
		uint32_t msgSeqNum, uint64_t sendingTime) {
	book.set_event(Event::Overlay);
	book.ask().overlay(mDPriceLevel, price, quantity, orders);
	book.set_rpt_seqnum(rptSeq);
	book.set_exchange_time(transactTime);
	book.set_packet_seqnum(msgSeqNum);
	book.set_packet_time_stamp(sendingTime);
	book.set_is_valid(true);
}

void set_name(md_order_book2& book, const std::string & name,CntrId securityID) {
	book.set_series_name(name);
	book.set_security_id(securityID);
}

void book_invalid(md_order_book2& book) {
	book.set_is_valid(false);
}

BookData<> book_data(md_order_book2& from) {
	BookData<> to;

	for (int i=0; i < 5; i++) {
		to.bdcontr[i]=from.bid().getLevel(i+1).orders;
		to.bdquantity[i]=from.bid().getLevel(i+1).quantity;
		to.bdprice[i]=from.bid().getLevel(i+1).price;
		to.sdprice[i]=from.ask().getLevel(i+1).price;
		to.sdquantity[i]=from.ask().getLevel(i+1).quantity;
		to.sdcontr[i]=from.ask().getLevel(i+1).orders;
	}

	to.set_event(from.get_event());

	if (from.get_event() == Event::Trade) {
		to.set_trade_price(from.get_trade_price());
		to.set_trade_quantity(from.get_trade_quantity());
		to.set_trade_side(from.get_trade_side());
		to.set_aggressor_time(from.get_aggressor_time());
	}

	to.set_exchange_time(from.get_exchange_time());
	to.set_receive_time(from.get_receive_time());

	to.set_is_valid(from.get_is_valid());
	to.set_packet_seqnum(from.get_is_valid());
	to.set_packet_time_stamp(from.get_packet_time_stamp());

	to.set_series_name(from.get_series_name());
	to.set_security_id(from.get_security_id());

	return to;
}


#endif
